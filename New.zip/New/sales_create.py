"""Order_Creation_Sales_Create task - create ONE sales order in SAP (VA01) and check it in VA03.

A360: 'Order_Creation_Sales_Create' (Order Creation A360 steps.txt:772-1004) and the SAP macros of Macro.xlsm it ran:
subMain, subHeaderSetting, subOptionSetting, subItemSetting, subBlockSetting, subOrderSave, subSearchResult,
subGetResultData, subAttacheEmail, subAttachButton, subPopupsHandler, subReqDelivDate, subResetCell,
funReqDelivDate, funModReqDelivDate (Macro.txt:88-95, 1291-1921, 1988-2054).
Also here: the SAP logon / logoff of the Main Task (steps.txt:61-79, 136).

Only ONE SAP session is ever used (the client monitors the process): no new sessions, no multi-threading.

Run on its own (SAP must already be logged on with exactly one session; without --live the order is NOT saved):
    python sales_create.py "<standardized file in the Template folder>" [<ORDER_ID>] [--live]
"""

import logging
from runtime_support import (RunStopped, cleanup_mode, finish_run, shutdown, business_operation, emit_event,
    message_card, message_card_error,)
from business_progress import creation_outcome
import re
import sys
import time
from datetime import date, datetime, timedelta
from datetime import time as clock
from decimal import ROUND_HALF_EVEN, Decimal
from pathlib import Path

from config import FOLDERS, OTHERS
from exceptions import BotError, LoginFailedException, SapSessionLost
from rpa_core import (RUN, ExcelSession, StdOrder, cell, german_now, kill_processes, network_days,
    notify_status, portal_log, screenshot, send_error_mail, send_mail, setup_logging, step, to_currency,
    vba_cdate, vba_cstr, vba_like,)

# SAP screen element IDs used by the macros (VA01 / VA03)
OVERVIEW = 'wnd[0]/usr/tabsTAXI_TABSTRIP_OVERVIEW/tabpT\\01/ssubSUBSCREEN_BODY:SAPMV45A:4400'
TABLE = OVERVIEW + '/subSUBSCREEN_TC:SAPMV45A:4900/tblSAPMV45ATCTRL_U_ERF_AUFTRAG'
KETDAT = OVERVIEW + '/ssubHEADER_FRAME:SAPMV45A:4440/ctxtRV45A-KETDAT'
LIFSK = OVERVIEW + '/ssubHEADER_FRAME:SAPMV45A:4440/cmbVBAK-LIFSK'
PARTNER = 'wnd[0]/usr/subSUBSCREEN_HEADER:SAPMV45A:4021/subPART-SUB:SAPMV45A:4701'
PO_FIELD = 'wnd[0]/usr/subSUBSCREEN_HEADER:SAPMV45A:4021/txtVBKD-BSTKD'
SALES_TAB = 'wnd[0]/usr/tabsTAXI_TABSTRIP_HEAD/tabpT\\01/ssubSUBSCREEN_BODY:SAPMV45A:4301'
STATUS_TAB = 'wnd[0]/usr/tabsTAXI_TABSTRIP_HEAD/tabpT\\10'
ATTACH_LIST = 'wnd[1]/usr/subSUB:SAPLZTCDA01_FG01:0200/cntlCONTAINER_200/shellcont/shell/shellcont[1]/shell'
POPUP_REMARKS = ("Internal Note (Material)", "Item is not modeled in DF.please check again",
    "Change in invoice date: The billing date is", "HA primary and secondary connections are down and",
    "The header business data does not apply to item", "Delivery due date is outside planning horizon",
    "is marked for deletion", "Enter storage location", "Header note From customer",)

def req_deliv_date_from_week(week_text):
    """Macro funReqDelivDate (Macro.txt:1988-2017): calendar week ('05') -> first working day of that week.
    Like the macro (NOT ISO weeks): 1 January + n weeks, back to Monday; in Nov/Dec the weeks 1-10 mean next year.
    A360-FIX[B28] (Macro.txt:2090-2092 funReqDelivDateFormat_Date): the macro cut the date text by position and only
    worked with a dd-mm-yyyy Windows date format; now the result is always 'yyyy.mm.dd'.
    """
    week, today = (int(week_text[-2:]), date.today())
    if today.month >= 11 and week <= 10:
        monday = date(today.year + 1, 1, 1) + timedelta(weeks=week) - timedelta(days=1)
    else:
        monday = date(today.year, 1, 1) + timedelta(weeks=week)
    monday -= timedelta(days=monday.isoweekday() - 1)
    for _ in range(100):  # macro's holiday check; with no holiday list a Monday is always a working day
        if network_days(monday, monday) != 0:
            break
        monday += timedelta(days=1)
    return monday.strftime('%Y.%m.%d')

def mod_req_deliv_date(sap_date, delay):
    """Macro funModReqDelivDate (Macro.txt:2019-2054): SAP's proposed date moved by 'delay' WORKING days."""
    moved = sap_date + timedelta(days=delay)
    for _ in range(20):
        working = network_days(sap_date, moved)
        if delay < 0:
            moved -= timedelta(days=1) if working > delay - 1 else timedelta(0)
            if working == delay - 1:
                break
        if delay > 0:
            moved += timedelta(days=1) if working < delay + 1 else timedelta(0)
            if working == delay + 1:
                break
    return moved.strftime('%Y.%m.%d')

class Va01:
    """The SAP macros of Macro.xlsm converted to Python. One object per sales order = a fresh copy of the Macro.xlsm
    'Temp' sheet (A360 reopened Macro.xlsm for every order). Temp cells -> attributes:
      B11 sbar_type   C11 sbar_text   E11 information   G11 remark   I11 business_error   L11 item_block
      N11 all_block   B5 sold_to_name   D5 ship_to_name   F5 net_value   B8 so_creation_date   D8 so_status
      B2 req_deliv_date (the macro's funGetCell('ReqDelivDate') finds B1 'File ReqDelivDate' first -> B2).
    """

    def __init__(self, session, template_type):
        self.s, self.template_type = (session, template_type)
        self.sbar_type = self.sbar_text = self.information = self.remark = self.popup_text = ''
        self.sold_to_name = self.ship_to_name = self.net_value = ''
        self.so_creation_date = self.so_status = self.req_deliv_date = ''
        self.business_error, self.item_block, self.all_block = (False, None, None)  # None = empty Temp cell
        self.visible_rows = 0

    # ---- SAP helpers: like VBA 'On Error Resume Next' - do it when possible, never stop the bot ---------------------
    def find(self, element_id):
        """session.findById() that returns None instead of an error."""
        try:
            return self.s.findById(element_id)
        except Exception:
            return None

    def text(self, element_id, attribute="Text", default=""):
        """Text (or another attribute) of an SAP field / window title / status bar; 'default' when it is missing."""
        try:
            return getattr(self.s.findById(element_id), attribute)
        except Exception:
            return default

    def set(self, element_id, value, attribute="Text"):
        """Fill an SAP field (attribute 'Text' or 'Key'). Returns False when the field does not exist."""
        try:
            setattr(self.s.findById(element_id), attribute, value)
            logging.debug(f"SAP set {element_id} = {value!r}")
            return True
        except Exception as ex:
            logging.debug(f"SAP set {element_id} skipped: {ex}")
            return False

    def press(self, element_id, action="press"):
        """Press a button or select a menu / tab (action 'press' or 'select'). Returns False when it is missing."""
        try:
            getattr(self.s.findById(element_id), action)()
            logging.debug(f"SAP {action} {element_id}")
            return True
        except Exception as ex:
            logging.debug(f"SAP {action} {element_id} skipped: {ex}")
            return False

    def key(self, vkey=0, active_window=False):
        """Press a key: 0 = Enter, 12 = Esc/Cancel; in the main window or in the window that is in front."""
        try:
            (self.s.ActiveWindow if active_window else self.s.findById('wnd[0]')).sendVKey(vkey)
        except Exception as ex:
            logging.debug(f"SAP key {vkey} skipped: {ex}")

    def read_sbar(self):
        """Status bar -> Temp B11 'SbarType' and C11 'SbarMessage'."""
        self.sbar_type, self.sbar_text = (self.text('wnd[0]/sbar', 'MessageType'), self.text('wnd[0]/sbar'))
        logging.info(f"SAP status bar: [{self.sbar_type}] {self.sbar_text}")

    def reset(self):
        """Macro subResetCell (Macro.txt:1807-1817). 'ALL Blcok Flag' (N11) is NOT reset - same as the macro."""
        self.sbar_type = self.sbar_text = self.net_value = ''
        self.business_error, self.item_block = (False, None)

    def atp_loop(self):
        """'While wnd[0] = "ATP Change Query Screen": accept + continue' of subItemSetting / subBlockSetting (max 20).
        When the screen does not go away the order is stopped (item error / SYSTEM) - it is never saved like this.
        """
        for _ in range(20):
            if self.text("wnd[0]") != "ATP Change Query Screen":
                return
            self.press('wnd[0]/usr/btnGV_ACCEPT')
            self.press('wnd[0]/tbar[1]/btn[14]')
        self.hardcopy('ATP loop limit.png')
        raise BotError("'ATP Change Query Screen' still open after 20 tries")

    def to_sap_date(self, value):
        """Dates of the bot are 'yyyy.mm.dd'; SAP gets them in the SAP user's format (config 'sap_date_format')."""
        try:
            return datetime.strptime(value, '%Y.%m.%d').strftime(OTHERS.sap_date_format)
        except (TypeError, ValueError):
            return value

    def popups(self):
        """Macro subPopupsHandler(1) (Macro.txt:1819-1856): confirm SAP's information popups and keep important
        texts as Remark. Max 50 popups (the macro allowed 10 000)."""
        for _ in range(50):
            if self.text("wnd[0]") == "I2 ATP Proposal Screen":
                self.press('wnd[0]/usr/btnW_ACCEPT_CM')
            if vba_like(self.text("wnd[1]"), "Internal Note (Material)*"):
                self.press('wnd[1]/tbar[0]/btn[0]')
            message = self.text('wnd[1]/usr/txtMESSTXT1')
            if message == "":
                break
            logging.info(f"SAP popup: {message}")
            if any(remark in message for remark in POPUP_REMARKS):
                self.remark = message
            self.press('wnd[1]/tbar[0]/btn[0]')
        if self.text("wnd[0]") == "I2 ATP Proposal Screen":
            self.press('wnd[0]/usr/btnW_ACCEPT_CM')

    # ---- the macros --------------------------------------------------------------------------------------------------
    def sub_main(self, sales_org, dist_channel, division):
        """Macro subMain (Macro.txt:1292-1341): open VA01 and enter the organisation data."""
        self.reset()
        self.item_block, self.req_deliv_date, self.sold_to_name, self.ship_to_name = (None, '', '', '')
        # A360-FIX[B24] SalesCreate step 6 -> subMain (no A360 check): a popup left over from the previous order (GOS,
        #   VA03 ...) made the next order fail. Fix: close leftovers without saving, check that only ONE session is
        #   open, and stop as system error when the VA01 start screen does not open.
        self.abandon()
        if self.s.Parent.Children.Count != 1:
            raise BotError(f"{self.s.Parent.Children.Count} SAP sessions are open - only ONE is allowed")
        try:
            self.s.findById('wnd[0]').resizeWorkingPane(0, 0, False)
            self.s.findById('wnd[0]').maximize()
        except Exception as ex:
            logging.debug(f"SAP maximize skipped: {ex}")
        self.set('wnd[0]/tbar[0]/okcd', '/nva01')
        self.key(0)
        if not self.text("wnd[0]").startswith("Create Sales Order: Initial Screen"):
            raise BotError(f"VA01 did not open (window '{self.text('wnd[0]')}')")
        for field_id, value in (("ctxtVBAK-AUART", "yn01"), ("ctxtVBAK-VKORG", sales_org),
            ("ctxtVBAK-VTWEG", dist_channel), ("ctxtVBAK-SPART", division), ("ctxtVBAK-VKBUR", ""),
            ("ctxtVBAK-VKGRP", ""),):
            self.set(f"wnd[0]/usr/{field_id}", value)
        self.key(0)
        self.read_sbar()

    def po_exists_check(self):
        """Part of subHeaderSetting: 'Purchase order number ... already exists' -> confirm with Enter."""
        text = self.text('wnd[0]/sbar')
        if vba_like(text, "Purchase order number in document number: * already exists"):
            # A360-KEPT[K03] (Macro.txt:1393-1397): dispo / shop orders of one file share the PO number, so A360 goes on.
            notify_status("PO already used", f"{text} - the order is created anyway (A360 behaviour)",)
            portal_log(f"PO number already used: {text} - order created anyway")
            self.key(0)

    def header_setting(self, sold_to, ship_to, po_number):
        """Macro subHeaderSetting (Macro.txt:1344-1420): sold-to, ship-to, PO number and the popups that follow."""
        self.set(PARTNER + '/ctxtKUAGV-KUNNR', sold_to)
        self.set(PARTNER + '/ctxtKUWEV-KUNNR', ship_to)
        self.set(PO_FIELD, po_number.strip(' ')[:35])
        self.key(0)
        # A360-FIX[B04] SalesCreate step 6 -> subHeaderSetting (Macro.txt:1360)
        #   Bug: 'marked for deletion' was tested on the OLD status bar text of subMain, so it never matched.
        #   Fix: read the status bar after Enter.
        if vba_like(self.text("wnd[0]/sbar"), "Select another Customer,* is marked for deletion"):
            self.sbar_type, self.sbar_text = ('E', self.text('wnd[0]/sbar'))
            return
        for _ in range(10):
            title = self.text('wnd[1]')
            if title == "":
                break
            # A360-FIX[B03] SalesCreate step 6 -> subHeaderSetting (Macro.txt:1375)
            #   Bug: InStr(popupTitle, "*Information*") searched for the stars literally -> never true, so the A360
            #        check 'is not permitted as sold-to party' (steps.txt:843) could never work. Fix: real text search.
            if "Information" in title:
                self.popup_text = f"{self.text('wnd[1]/usr/txtMESSTXT1')} {self.text('wnd[1]/usr/txtMESSTXT2')}"
                if "is not permitted as sold-to party and is" in self.popup_text:
                    self.information = self.popup_text
                    return
            editor = self.text('wnd[1]/usr/cntlZ_TEXT_EDIT_CONTROL/shellcont/shell', default=None)
            if editor is not None:
                self.popup_text = re.sub('[\\x00-\\x1f]', '', editor)  # WorksheetFunction.Clean
            logging.info(f"SAP popup '{title}': {self.popup_text[:200]}")
            # these presses had no error protection in the macro -> an error here is a system error (A360 Catch)
            if title in ("Partner selection", "Partner Selection", "Sales information",
                "Header note From customer",):
                self.s.findById('wnd[1]/tbar[0]/btn[0]').press()
            if title == "Sales area for customer":
                self.s.findById('wnd[1]/tbar[0]/btn[12]').press()
        self.po_exists_check()
        if self.popup_text == "AVANTGARDE":
            self.information = self.popup_text
        self.po_exists_check()
        self.read_sbar()
        if "No pricing procedure could be determined" in self.sbar_text:
            self.business_error = True
            for button in ("wnd[0]/tbar[0]/btn[3]", "wnd[1]/usr/btnSPOP-OPTION2", "wnd[0]/tbar[0]/btn[3]",):
                self.press(button)

    def req_deliv_date_rule(self, rdd):
        """Macro subReqDelivDate (Macro.txt:1858-1921): which requested delivery date goes into SAP.
        Result in self.req_deliv_date ('' = keep the date SAP proposes). An error stops only this rule (as in VBA).
        """
        sap_text = self.text(KETDAT)
        try:
            sap_date = datetime.strptime(sap_text, OTHERS.sap_date_format).date()
            delay = -1 if self.template_type == 'IM adhoc' else 0  # mapSht 'Delay before 12'
            after_one_pm = german_now().time() >= clock(13, 0)  # 'funDateTime >= #1:00:00 PM#'
            if "dispo" in self.template_type:
                wanted_text = (req_deliv_date_from_week(rdd[3:].strip()) if "white" in self.template_type
                    else rdd)
                wanted = vba_cdate(wanted_text.replace('.', '-'))
                if wanted is None:
                    raise ValueError(f"'{wanted_text}' is no date")
                if wanted < sap_date:
                    delay += 1 if after_one_pm else 0
                    self.req_deliv_date = mod_req_deliv_date(sap_date, delay) if delay else ''
                else:
                    self.req_deliv_date = wanted_text
            else:
                wanted = vba_cdate(rdd.replace('.', '-'))
                if (
                    wanted is None or wanted < sap_date
                ):  # sofort / asap / text / date in the past
                    delay += 1 if after_one_pm else 0
                    if delay and self.template_type != "IM adhoc":
                        self.req_deliv_date = mod_req_deliv_date(sap_date, delay)
                else:
                    self.req_deliv_date = rdd  # put delivery date from template
        except Exception as ex:
            logging.warning(f"Delivery date rule stopped ({ex}) - SAP keeps its proposed date")
        logging.info(
            f"Requested delivery date: file '{rdd}' | SAP '{sap_text}' | entered '{self.req_deliv_date}'")

    def option_setting(self, usage_code, rdd):
        """Macro subOptionSetting (Macro.txt:1423-1511): sold-to / ship-to names, usage code, delivery date."""
        self.reset()
        self.popups()
        self.sold_to_name = self.text(PARTNER + '/txtKUAGV-TXTPA')
        self.ship_to_name = self.text(PARTNER + '/txtKUWEV-TXTPA')
        try:
            usage_valid = float(usage_code).is_integer() and 99 < float(usage_code) < 1000
        except ValueError:
            usage_valid = False
        if usage_valid:  # Goto > Header > Sales, field 'Usage'
            self.press('wnd[0]/mbar/menu[2]/menu[1]/menu[0]', 'select')
            self.set(SALES_TAB + '/cmbVBAK-ABRVW', usage_code, 'Key')
            self.press('wnd[0]/mbar/menu[2]/menu[0]', 'select')
        elif usage_code:
            logging.warning(
                f"Usage code '{usage_code}' is not a 3-digit number - not entered (macro behaviour)")
        self.req_deliv_date_rule(rdd)
        if self.req_deliv_date and self.template_type not in ("IM adhoc", "Shop Order"):
            self.set(KETDAT, self.to_sap_date(self.req_deliv_date))
        self.key(0)
        for pattern in ("*is B2B material. Please check D.channel*", "*is not defined for sales org.*",):
            if vba_like(self.text("wnd[0]/sbar"), pattern):
                try:
                    self.s.findById('wnd[0]/usr').selectContextMenuItem('POLO')
                except Exception as ex:
                    logging.debug(f"Context menu POLO skipped: {ex}")
        if vba_like(self.text("wnd[0]/sbar"), "Select another Customer,* is marked for deletion"):
            self.sbar_type, self.sbar_text = ('E', self.text('wnd[0]/sbar'))
            return
        self.popups()
        self.read_sbar()

    @step
    def item_setting(self, first_date, material, quantity, net_price, row_index):
        """Macro subItemSetting (Macro.txt:1513-1617): enter one item line and compare SAP's net price with the file.
        Any unexpected error -> SbarType 'E' 'SO Item creation error. Check the system environment.' (as the macro).
        """
        try:
            self.reset()
            self.remark = ''
            self.popups()
            if not self.visible_rows:
                self.visible_rows = int(self.s.findById(TABLE).VisibleRowCount) or 13
            # A360-FIX[B12] SalesCreate item loop (steps.txt:885) -> subItemSetting (Macro.txt:1531-1547)
            #   Bug: 13 visible table rows were hard coded (depends on the screen size); another size put items in the
            #   wrong line. Fix: SAP tells how many rows are visible, and the line must be empty before writing.
            scroll = max(0, row_index - (self.visible_rows - 1))
            line = row_index - scroll
            if scroll:
                self.s.findById(TABLE).verticalScrollbar.Position = scroll
            ids = {name: f"{TABLE}/{name}[{column},{line}]" for name, column in (("ctxtRV45A-MABNR", 1),
                    ("txtRV45A-KWMENG", 2), ("ctxtRV45A-ETDAT", 18), ("txtVBAP-NETWR", 9),
                    ("txtVBAP-NETPR", 19),)}
            if self.s.findById(ids["ctxtRV45A-MABNR"]).Text.strip():
                raise BotError(f"item line {line} already contains a material")
            self.s.findById(ids['ctxtRV45A-MABNR']).Text = material
            self.s.findById(ids['txtRV45A-KWMENG']).Text = quantity
            if self.template_type in ("IM adhoc", "Shop Order"):
                self.s.findById(ids["ctxtRV45A-ETDAT"]).Text = self.to_sap_date(self.req_deliv_date
                    if self.template_type == "IM adhoc" else first_date)
            self.key(0)  # 'On Error Resume Next' part of the macro
            self.press('wnd[1]/tbar[0]/btn[0]')
            self.atp_loop()
            self.popups()
            self.sbar_type, self.sbar_text = (self.s.findById("wnd[0]/sbar").MessageType,
                self.s.findById("wnd[0]/sbar").Text,)
            logging.info(f"Item {material} x {quantity}: [{self.sbar_type}] {self.sbar_text}")
            if vba_like(self.sbar_text, "*is B2B material. Please check D.channel*"):
                self.remark = 'is B2B material. Please check D.channel'
            if vba_like(self.sbar_text, "*is not defined for sales org.*"):
                self.remark = 'is not defined for sales org'
            title = self.s.findById('wnd[0]').Text
            if title in ("Normal Sales Order: One-time delivery", "Normal Sales Order: Availability Control",
            ):
                self.s.findById("wnd[0]/tbar[1]/btn[5]" if "One-time" in title else "wnd[0]/tbar[1]/btn[18]"
                ).press()
                self.remark = f"{self.remark} / {title}" if self.remark else title
            if self.sbar_type != "E":  # 'SbarType Check'
                self.net_value = self.s.findById(ids['txtVBAP-NETWR']).Text
                self.all_block = True if self.all_block is None else self.all_block
                sap_price = to_currency(self.s.findById(ids['txtVBAP-NETPR']).Text, sap=True)
                file_price = to_currency(net_price).quantize(Decimal('0.01'), ROUND_HALF_EVEN)
                price_ok = sap_price - Decimal('0.01') <= file_price <= sap_price + Decimal('0.01')
                logging.info(
                    f"Net price SAP {sap_price} / file {file_price} -> {'equal' if price_ok else 'NOT equal'}"
                )
                if price_ok:
                    self.all_block = False
                else:
                    self.item_block = False
                    self.s.findById(TABLE).getAbsoluteRow(row_index).Selected = True
        except Exception as ex:
            logging.warning(f"Item {material}: {type(ex).__name__}: {ex}")
            self.sbar_type, self.sbar_text = ('E', 'SO Item creation error. Check the system environment.')

    def block_setting(self):
        """Macro subBlockSetting (Macro.txt:1619-1654): delivery block 'Y5'.
        A360-KEPT[K09]: header block only when EVERY item had another price; otherwise the item 'fast change' path
        always runs (even with no line selected) - exactly like the macro, because the real orders go this way.
        """
        if self.all_block is True:
            logging.info('All items have another net price -> header delivery block Y5')
            self.set(LIFSK, 'Y5', 'Key')
            return
        logging.info('Delivery block y5 for the selected items (fast change)')
        self.press('wnd[0]/mbar/menu[1]/menu[1]/menu[1]', 'select')
        self.set('wnd[1]/usr/ctxtRV45A-S_LIFSP', 'y5')
        self.press('wnd[1]/tbar[0]/btn[7]')
        self.popups()
        self.press('wnd[0]/usr/tabsTAXI_TABSTRIP_OVERVIEW/tabpT\\01', 'select')
        self.press('wnd[0]/usr/btnGV_ACPT_QUAN')
        self.atp_loop()

    def order_save(self):
        """Macro subOrderSave (Macro.txt:1656-1687): Save + the 2 confirmation popups. The macro's fixed 3 s wait is
        not needed: search_result() waits until the order really exists."""
        self.reset()
        self.press('wnd[0]/tbar[0]/btn[11]')
        self.press('wnd[1]/tbar[0]/btn[0]')  # popup 'Create Normal Sales Order: Overview'
        self.press('wnd[1]/usr/btnSPOP-VAROPTION1')  # popup 'Save Incomplete Document'
        self.read_sbar()

    def search_result(self, so_number):
        """Macro subSearchResult + A360 'Loop 10 times' (Macro.txt:1689-1720, steps.txt:927-929): open the new order
        in VA03. Returns True as soon as 'Display Normal Sales Order' is shown.
        A360-FIX[B27] SalesCreate step 6 'Else if vSbarText includes Normal Sales Order' (steps.txt:925-929)
          Bug: fixed waits (10 s per try, up to 10 tries) and no defined result when the order never showed up.
          Fix: try again every second while SAP says 'not in the database' (max config 'va03_timeout' seconds).
        """
        started = time.monotonic()
        self.set('wnd[0]/tbar[0]/okcd', '/nva03')
        self.key(0)
        self.set('wnd[0]/usr/ctxtVBAK-VBELN', so_number)
        self.press('wnd[0]/tbar[0]/btn[0]')
        while time.monotonic() - started < OTHERS.va03_timeout:
            if self.text("wnd[0]").startswith("Display Normal Sales Order"):
                logging.info(f"SO {so_number} shown in VA03 after {time.monotonic() - started:.0f}s")
                return True
            time.sleep(1)
            if self.text("wnd[0]").startswith(
                "Display Sales Order: Initial Screen"
            ):  # 'is not in the database'
                self.set('wnd[0]/usr/ctxtVBAK-VBELN', so_number)
                self.key(0)
        return False

    def get_result_data(self):
        """Macro subGetResultData (Macro.txt:1722-1753): creation date (Sales tab) and credit / block status."""
        self.press('wnd[0]/mbar/menu[2]/menu[1]/menu[0]', 'select')
        self.so_creation_date = self.text(SALES_TAB + '/ctxtVBKD-PRSDT')
        self.press(STATUS_TAB, 'select')
        credit = self.text(STATUS_TAB + '/ssubSUBSCREEN_BODY:SAPMV45A:4305/txtVBSTT-CMGST_BEZ')
        blocked = self.text(STATUS_TAB + '/ssubSUBSCREEN_BODY:SAPMV45A:4305/txtVBSTT-SPSTG_BEZ')
        self.so_status = f"Credit Status: {credit} / Overall blkd status: {blocked}"
        logging.info(f"SO creation date {self.so_creation_date} | {self.so_status}")

    def attach_email(self, order_id):
        """Macro subAttacheEmail + subAttachButton + A360 steps 934-975: attach the order e-mail (.eml) to the order
        (Services for Object -> Attach Box). A problem only gives a warning (A360: 'Catch: pass').
        Needs a SAP GUI security rule that allows reading config 'eml_dir' (else SAP shows a blocking question).
        """
        # A360-FIX[sap-5] SalesCreate steps 934-975 -> subAttacheEmail / subAttachButton (Macro.txt:1755-1805)
        #   Bug: one error in the loop ended all 5 tries, and 'Order e-mail attached' was logged even when nothing was
        #        attached. Fix: check the .eml file exists first, give every try its own try/except, and log success
        #        only after the file dialog was confirmed.
        eml = Path(OTHERS.eml_dir) / f"{order_id}_Email.eml"
        if not eml.is_file():
            logging.warning(f"Order e-mail not attached: {eml} not found")
            return
        try:
            shell = self.s.findById('wnd[0]/titl/shellcont/shell')
            shell.pressContextButton('%GOS_TOOLBOX')
            shell.selectContextMenuItem('%GOS_ZABOXA')
            filed = False
            for _ in range(5):  # A360 'Loop 5 times': New -> file
                try:
                    box = self.find(ATTACH_LIST)
                    if box is not None:
                        box.pressToolbarContextButton('NEW')
                        try:
                            box.selectContextMenuItem('FILE2')
                        except Exception:  # A360 typed the keys s, Right, Down, Enter
                            from pywinauto.keyboard import send_keys

                            send_keys('s{RIGHT}{DOWN}{ENTER}')
                            time.sleep(1)
                    if self.find("wnd[2]") is not None:  # window 'Open multiple files'
                        message_card(940, email_name=eml.name)
                        self.set('wnd[2]/usr/txtDY_PATH', str(OTHERS.eml_dir))
                        self.set("wnd[2]/usr/txtDY_FILENAME", f"{order_id}_Email.eml")
                        self.press('wnd[2]/tbar[0]/btn[0]')
                        filed = True
                        break
                except Exception as ex:
                    logging.debug(f"Attach file try failed: {ex}")
            if not filed:
                logging.warning('Order e-mail not attached: the file dialog never opened')
                return
            for _ in range(5):  # A360 'Loop 5 times': Attach button
                try:
                    if self.find("wnd[1]") is None:
                        break
                    from pywinauto import Desktop

                    for dialog in Desktop(backend="win32").windows(title_re="SAP GUI Security.*"):
                        from pywinauto.keyboard import send_keys

                        dialog.set_focus()
                        send_keys('{LEFT}{ENTER}')  # 'Allow'
                    self.press('wnd[1]/tbar[0]/btn[0]')  # macro subAttachButton
                except Exception as ex:
                    logging.debug(f"Attach button try failed: {ex}")
            logging.info('Order e-mail attached to the sales order')
        except Exception as ex:
            logging.warning(f"Order e-mail could not be attached (the order itself is fine): {ex}")

    def hardcopy(self, file_name):
        """Picture of the SAP window into the Output folder (A360 'Capture screenshot of window ...').
        A360-FIX[B22] SalesCreate step 6 (steps.txt:821,834,844,859,892,920)
          Bug: A360 captured a window titled 'Create Sales Order: Initial Screen*' while SAP showed the Overview, so
               the capture could fail and turn a normal business error into a SYSTEM error. Fix: SAP's own HardCopy.
        """
        path = Path(FOLDERS.OUTPUT) / file_name
        try:
            self.s.findById('wnd[0]').HardCopy(str(path), 2)  # 2 = PNG
            logging.info(f"SAP screenshot saved: {path}")
        except Exception:
            screenshot(path)
        return str(path)

    def abandon(self):
        """Leave the current transaction WITHOUT saving: answer 'No' to any question, then /n.
        A360-FIX[B23] Main Task Finally step 6 (steps.txt:136) / provided sap_logon.SAPLogin.close()
          Bug: close() presses Back and then 'Yes' on any popup - on an unfinished VA01 order that could SAVE it.
          Fix: always leave the transaction like this first."""
        for _ in range(3):
            if self.find("wnd[1]") is None:
                break
            if not self.press("wnd[1]/usr/btnSPOP-OPTION2"):
                self.key(12, active_window=True)
        self.set('wnd[0]/tbar[0]/okcd', '/n')
        self.key(0)
        if self.find("wnd[1]") is not None:
            self.press('wnd[1]/usr/btnSPOP-OPTION2')

# SAP logon / logoff (Main Task) and the stand-alone session
@step
def sap_login():
    """Main Task step 26: log on to SAP system SEP with the provided sap_logon.SAPLogin - exactly ONE session."""
    from sap_logon import SAPLogin

    # A360-FIX[sap-8] Main Task step 26 (stand-alone re-logon, steps.txt:61-79)
    #   Bug: RUN.creds["sap_id"] raised KeyError when the bot was started without the .bat arguments (stand-alone
    #        mode), so the error message was cryptic and SAP was killed for nothing. Fix: a clear error first.
    if not RUN.creds.get("sap_id") or not RUN.creds.get("sap_pw"):
        raise LoginFailedException('SAP ID / password not provided - start the bot with the .bat arguments')
    kill_processes('saplogon.exe,saplgpad.exe,sapgui.exe')  # start clean: no old connection / session
    RUN.sap = SAPLogin(OTHERS.saplogon_path)
    session = RUN.sap.login(OTHERS.sap_connection, RUN.creds['sap_id'], RUN.creds['sap_pw'])
    connection = session.Parent
    if connection.Parent.Children.Count != 1 or connection.Children.Count != 1:
        raise BotError('More than one SAP connection / session is open - only ONE is allowed')
    info = session.Info
    logging.info(
        f"SAP logon OK: system {info.SystemName} client {info.Client} user {info.User} language {info.Language}"
    )
    if info.IsLowSpeedConnection:
        notify_status("SAP",
            "the SAP Logon entry uses 'low speed connection'; readiness follows the actual SAP busy state",)
    if (
        "SAP Easy Access" not in session.findById("wnd[0]").Text
    ):  # A360: If "SAP Easy Access" does not exist
        raise LoginFailedException(
            f"'SAP Easy Access' not shown (window '{session.findById('wnd[0]').Text}')")
    RUN.session = session
    return session

def sap_logout():
    """Main Task Finally step 6: leave SAP without saving anything, then the provided SAPLogin.close()."""
    try:
        if RUN.session is not None:
            Va01(RUN.session, '').abandon()
        if RUN.sap is not None:
            RUN.sap.close(RUN.session)
    except Exception as ex:
        logging.warning(f"SAP logoff: {ex}")
    RUN.session = RUN.sap = None

def attach_session():
    """Stand-alone runs: use the SAP session that is already logged on (exactly ONE must be open)."""
    import pythoncom
    import win32com.client

    pythoncom.CoInitialize()
    application = win32com.client.GetObject('SAPGUI').GetScriptingEngine
    if application.Children.Count != 1 or application.Children(0).Children.Count != 1:
        raise BotError('Please open exactly ONE logged-on SAP session before starting this task')
    return application.Children(0).Children(0)

def check_session(session):
    """SalesCreate step 2 (steps.txt:776-786): is SAP still logged on? If not: screenshot + mail + SapSessionLost
    (Task 02 then logs on again once)."""
    try:
        if session.Info.User and session.findById("wnd[0]"):
            return
    except Exception:
        pass
    shot = screenshot(Path(FOLDERS.SCREENSHOTS) / f"SAP logged out {datetime.now():%Y%m%d%H%M%S}.png")
    message_card(775)
    portal_log('SAP has logged out automatically')
    send_mail(f"Order Creation SAP Window Issue - {RUN.order_id}",
        f"<P>Message from RPA Bot.</P><P> </P><P>Task Name : Order_Creation_SalesCreate</P><P>Error occurred on: "
        f"{datetime.now():%Y-%m-%d %H:%M:%S}</P><P>SAP window not available for processing on {RUN.user}</P>"
        f"<P>Error message: SAP has been logged out automatically. Please have a look at it.</P>",
        to=OTHERS.sap_window_mail_receivers, attachments=[shot],)
    raise SapSessionLost('SAP has logged out automatically')

# The task
def _business_error(va, order, screenshot_name):
    """A360 pattern 'screenshot + set A2 = No + set B2 = status bar text + vBusinessErrorHandlingFlag = true + break'."""
    shot = va.hardcopy(screenshot_name)
    order.rows[1][0], order.rows[1][1] = ('No', va.sbar_text)
    order.business_error = True
    return shot

def _fill_and_save(va, order):
    """SalesCreate step 6 'Loop 1 time' (steps.txt:793-975). Every A360 'break' is a 'return' here."""
    rows = order.rows
    po_number, sales_org, dist_channel, division = (cell(rows, "C2"), cell(rows, "E2"), cell(rows, "F2"),
        cell(rows, "G2"),)
    sold_to, ship_to, rdd, usage = (cell(rows, 'H2'), cell(rows, 'I2'), cell(rows, 'M2'), cell(rows, 'CQ2'))
    screen = f"{sold_to}_{rdd}".replace("/", "")  # vScreenName
    # A360-FIX[B29] steps.txt:797/806: the A360 text reads F2 into 'vDstributonChannel' but passes
    #   'vDistributionChannel' to subMain (typo). Fix: the distribution channel of F2 is used.
    va.sub_main(sales_org, dist_channel, division)
    if va.sbar_type == "E":
        return _business_error(va, order, f"{screen}_Header Error.png")
    va.header_setting(sold_to, ship_to, po_number)
    message_card(816, status_type=va.sbar_type, status_text=va.sbar_text)
    if va.sbar_type == "E":
        shot = _business_error(va, order, f"{screen}_Party Error.png")
        if "has been assigned order block: Overall block" in va.sbar_text:
            send_mail(f"[Error] - {OTHERS.vRPAName} - {RUN.order_id}",
                f"<P>Error details: {va.sbar_text}</P>", attachments=[shot],)
        return
    if ship_to and ship_to in va.sbar_text:
        return _business_error(va, order, f"{screen}_Ship To Party Error.png")
    if va.business_error:  # I11 'No pricing procedure'
        order.business_error = True
        return
    message_card(839, information=va.information or '(blank)')
    if "is not permitted as sold-to party and is" in va.information:
        va.sbar_text = va.information
        _business_error(va, order, f"{screen}_Sold To Party Error.png")
        for _ in range(3):
            va.key(12, active_window=True)  # Esc Esc Esc
        return
    if va.information == "AVANTGARDE" and usage == "":
        usage = '501'
    va.option_setting(usage, rdd)
    message_card(852, status_type=va.sbar_type, status_text=va.sbar_text)
    if va.sbar_type == "E":
        if "marked for deletion" in va.sbar_text:
            va.hardcopy(f"{screen}_Header Error.png")
            order.business_error = True
        else:
            va.sbar_text = 'Header Setting Script Error'
            order.system_error = True
        return
    row_index = 0  # vRowIndex = SAP item line (only entered items)
    for number, row in enumerate(
        rows, start=1
    ):  # 'Loop for each row' of the standardized sheet
        remark, material, quantity = (vba_cstr(row[1]), vba_cstr(row[9]), vba_cstr(row[10]))
        if material == "Material":  # header row
            continue
        if remark:  # e.g. 'Zero Quantity' -> not entered
            row[0] = 'No'
            continue
        if material == "":
            # A360-FIX[B25] SalesCreate item loop (steps.txt:882-896) after macro SEG_IM_adhoc (Macro.txt:1077)
            #   Bug: IM adhoc files leave blank lines in the standard sheet; A360 sent a blank item to SAP and the whole
            #   order failed with 'SO Item creation error'. Fix: blank lines are skipped.
            logging.warning(f"Row {number} has no material - skipped")
            continue
        first_date = vba_cstr(row[12]) if va.template_type == 'Shop Order' else ''
        # A360-FIX[sap-10] SalesCreate item loop (steps.txt:886) -> subItemSetting (Macro.txt:1531)
        #   Bug: a #N/A net price cell came back as the number -2146826246, so to_currency() treated it as a real
        #        price and the item got 'Net Value Not Equal' instead of item error E. Fix: vba_cstr() turns an Excel
        #        error cell into '' (VBA CStr behaviour) -> to_currency('') fails -> item error E, like the macro.
        emit_event("item_started", current=row_index + 1, row=number, material=material,
            name=Path(order.path).name,)
        message_card(884, first_date=first_date, material=material, quantity=quantity,
            net_price=vba_cstr(row[92]), row_index=row_index, scroll_count=max(0, row_index - 12),
            sheet_row=number, template_type=va.template_type,)
        va.item_setting(first_date, material, quantity, vba_cstr(row[92]), row_index)  # row[92] = CO net price
        if va.sbar_type == "E":
            va.hardcopy(f"{screen}_Item Error.png")
            row[0], row[1] = ('No', va.sbar_text)
            order.business_error = True
            break
        row[1] = va.remark or row[1]
        # A360-FIX[B05] SalesCreate item loop (steps.txt:900-903)
        #   Bug: 'If vItemBlockFlag not equals true' was always true (the cell is only empty or FALSE), so EVERY item
        #   got the remark 'Net Value Not Equal'. Fix: only items whose SAP net price differs from the file.
        if va.item_block is False:
            row[1] = (f"{va.remark} / Net Value Not Equal" if va.remark else "Net Value Not Equal")
        row[36], row[15], row[93], row[0] = (va.sold_to_name, va.ship_to_name, va.net_value, 'Yes')  # AK, P, CP, A
        row_index += 1
        emit_event('item_finished', current=row_index, row=number, material=material)
    if (
        order.business_error
    ):  # A360 still ran subBlockSetting here, but nothing is saved -> skipped
        return
    va.block_setting()
    if RUN.dry_run:
        logging.warning('DRY RUN - the sales order is NOT saved')
        return
    va.order_save()
    portal_log(f"SbarMessageType: {va.sbar_type} | SbarText: {va.sbar_text}")
    message_card(915, status_type=va.sbar_type, status_text=va.sbar_text)
    if va.sbar_type == "E":
        return _business_error(va, order, f"{screen}_Order Save Error.png")
    found = re.search('Normal Sales Order (\\d+)', va.sbar_text)  # A360-FIX[B20]: was 'substring from 20, length 10'
    if not found:
        return
    order.so_number = found.group(1)
    emit_event('sap_saved', so_number=order.so_number, name=Path(order.path).name)
    if not va.search_result(order.so_number):
        raise BotError(f"SO {order.so_number} saved but not shown in VA03 after {OTHERS.va03_timeout}s")
    va.hardcopy(f"{screen}_Create SO Number.png")
    va.get_result_data()
    order.so_creation_date, order.so_status = (va.so_creation_date, va.so_status)
    if va.template_type != "Shop Order" and OTHERS.gos_attach:
        va.attach_email(RUN.order_id)

@step
def write_back(order):
    """SalesCreate step 7 'Save and close excel PO': write Processed (A), Remark (B), Sold-to name (AK), Ship-to
    name (P) and Net value (CP) into the standardized file - one write for the whole sheet.
    """
    workbook = RUN.excel.open(order.path)
    try:
        body = order.rows[1:]
        if body:
            workbook.Sheets(1).Range('A2').Resize(len(body), len(body[0])).Value = body
        workbook.Save()
    finally:
        workbook.Close(False)

@business_operation("create", outcome=lambda result, args, kwargs: creation_outcome(
        args[1] if len(args) > 1 else kwargs["order"], RUN.dry_run),)
@step
def create_order(session, order):
    """Order_Creation_Sales_Create task (steps.txt:772-1004): create the sales order of one standardized file.
    Results go into 'order' (so_number, so_creation_date, so_status, so_result, business / system error).
    Raises SapSessionLost when SAP is no longer logged on (step 2)."""
    portal_log('Start Sub SalesCreate Task')  # step 1
    check_session(session)  # step 2
    va = Va01(session, cell(order.rows, 'CR2'))
    try:
        try:
            _fill_and_save(va, order)  # steps 3-6
        except Exception as ex:  # step 6 Catch
            message_card_error(974, ex)
            logging.exception(f"SAP error: {ex}")
            screenshot(Path(FOLDERS.SCREENSHOTS) / f"{datetime.now():%Y%m%d%H%M%S}.png")
            order.system_error = True
            if order.so_number:
                portal_log(f"SO {order.so_number}: {ex}", error=True)
        finally:
            if not order.so_number:
                va.abandon()  # A360-FIX[B23]
        # A360-FIX[sap-1] SalesCreate step 7 (steps.txt:980)
        #   Bug: write_back ran even in a dry run, so the standardized file got Yes/No in column A. A later live run
        #        on the same file then skipped every item already marked Yes -> items were lost. Fix: no write-back
        #        in a dry run (the order was never saved in SAP either).
        if not RUN.dry_run:
            write_back(order)  # step 7
    except Exception as ex:  # outer Catch
        message_card_error(980, ex)
        order.system_error = True
        portal_log(f"Order_Creation_SalesCreate error: {ex}", error=True)
        send_error_mail('Order_Creation_SalesCreate', ex, screenshot(Path(FOLDERS.SCREENSHOTS) / 'Error.png'))
    finally:
        portal_log('End sub task 2')  # Finally
        if order.system_error:
            order.so_result = 'SYSTEM'
        elif order.business_error:
            order.so_result = 'Fail'
        elif not order.so_number:
            screenshot(Path(FOLDERS.SCREENSHOTS) / 'SO Create Exception.png')
            order.business_error, order.so_result = (True, 'Fail')
        else:
            order.so_result = 'Success'
        message_card(1001, so_result=order.so_result, so_number=order.so_number or '-')
        logging.info(f"SO Result: {order.so_result} | SO {order.so_number or '-'}")

if (
    __name__ == "__main__"
):  # stand-alone: create the order of one standardized file in the open SAP session
    arguments = [a for a in sys.argv[1:] if a != '--live']
    if not arguments:
        sys.exit(__doc__)
    RUN.order_id, RUN.dry_run = (arguments[1] if len(arguments) > 1 else 'manual', '--live' not in sys.argv)
    setup_logging(RUN.order_id)
    RUN.excel = ExcelSession()
    try:
        book = RUN.excel.open(arguments[0], read_only=True)
        sheet_rows = RUN.excel.read(book.Sheets(1))
        book.Close(False)
        result = StdOrder('manual', Path(arguments[0]).name, arguments[0], sheet_rows)
        create_order(attach_session(), result)
        print(
            f"SO Result: {result.so_result} | SO number: {result.so_number or '-'} | dry run: {RUN.dry_run}")
    except RunStopped:
        logging.info('Sales creation stopped by the operator')
        sys.exit(130)
    finally:
        with cleanup_mode():
            RUN.excel.quit()
        finish_run(130 if sys.exc_info()[0] is SystemExit else 1 if sys.exc_info()[0] else 0)
        shutdown()
