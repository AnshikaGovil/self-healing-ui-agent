"""Knox portal logout, including the native SSO / Knox Portal dialogs."""

import logging
import time

from pywinauto import Application, findwindows
from selenium.webdriver.common.by import By

from helpers import close_application, wait_for_element_to_be_clickable
from rpa_core import step

KNOX_URL = 'https://w1.samsung.net'
PROFILE_BUTTON = '//div[@class="profile"]/button[@class="user-profile"]'
LOGOUT_BUTTON = '//div[@class= "profile-container"]//li/button/span[contains(text(), "Log out")]'
ERROR_POPUP = "//div[@class='popup-container popup--massege ']//div[@class='popup-body scroll-show']"

MAX_ATTEMPTS = 3

@step(portal=False)
def click_dialog_button(window_title, button_labels, timeout=5):
    """Click the first matching button of a native window. Never raises."""
    try:
        # PY-CHANGE: look for the dialog for max 2 s first - before, every missing dialog cost the full 5 s connect
        # timeout (A360: Main Task steps 16 + Finally 7 'Knox Logout').
        deadline = time.monotonic() + min(timeout, 2)
        while not findwindows.find_elements(title=window_title, backend="uia"):
            if time.monotonic() > deadline:
                logging.info(f"'{window_title}' dialog not shown.")
                return False
            time.sleep(0.3)
        app = Application(backend='uia').connect(title=window_title, timeout=timeout)
        dialog = app.window(title=window_title)
        if not (dialog.exists() and dialog.is_visible()):
            logging.info(f"'{window_title}' dialog not visible.")
            return False

        dialog.set_focus()
        for button in dialog.children(control_type="Button"):
            text = button.window_text()
            if any(label.lower() in text.lower() for label in button_labels):
                button.click()
                logging.info(f"Clicked '{text}' in the '{window_title}' dialog.")
                return True
        logging.info(f"No {button_labels} button found in '{window_title}'.")
    except Exception as ex:
        logging.info(f"'{window_title}' dialog not available: {ex}")
    return False

class Knox_Logout:

    def __init__(self, driver):
        self.driver = driver

    @step
    def logout(self):
        """Log out of the Knox portal. Returns True on success."""
        for attempt in range(1, MAX_ATTEMPTS + 1):
            try:
                logging.info(f"Knox logout attempt {attempt}/{MAX_ATTEMPTS}.")
                if not click_dialog_button("Timeout - Knox Portal", ("OK",)):
                    close_application('EpTray.exe')

                self.driver.get(KNOX_URL)

                if self._already_logged_out():
                    logging.info('Knox is already logged out.')
                    return True

                self._dismiss_error_popup()
                self.driver.find_element(By.XPATH, PROFILE_BUTTON).click()
                time.sleep(1)
                self.driver.find_element(By.XPATH, LOGOUT_BUTTON).click()
                time.sleep(3)

                click_dialog_button('Knox Portal', ('Yes',))
                if not click_dialog_button("SSO", ("Yes", "OK")):
                    close_application('EpTray.exe')

                logging.info('Knox logout completed successfully.')
                return True

            except Exception as ex:
                logging.warning(f"Knox logout attempt {attempt} failed: {ex}")

        logging.error('Knox logout failed after the maximum number of attempts.')
        return False

    @step(portal=False)
    def _already_logged_out(self):
        """True when the login form (instead of the profile button) is shown."""
        for _ in range(3):
            try:
                if wait_for_element_to_be_clickable(self.driver, By.XPATH, PROFILE_BUTTON, 5):
                    return False
            except Exception:
                logging.info('User profile not loaded.')
            try:
                if wait_for_element_to_be_clickable(self.driver, By.ID, "id", 5):
                    return True
            except Exception:
                logging.info('Login form not shown either - retrying.')
        return False

    @step(portal=False)
    def _dismiss_error_popup(self):
        """Close the Knox error popup when it is displayed."""
        try:
            popup = wait_for_element_to_be_clickable(self.driver, By.XPATH, ERROR_POPUP, 1)
            if popup:
                popup.click()
                close_application('EpTray.exe')
        except Exception:
            logging.info('No Knox error popup displayed.')
