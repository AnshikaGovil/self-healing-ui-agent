"""Order Creation Main Task - the whole bot (A360 'Order Creation Main Task', Order Creation A360 steps.txt:1-137).

Started by the orchestrator .bat file:
    .venv\\Scripts\\python.exe main.py <knox_id> <knox_pw> <mail_id> <mail_pw> <sap_id> <sap_pw> <ORDER_ID> <MAIL_RECEIVED_DT>
(the order of the arguments is config.json 'argv_layout').   Exit code: 0 = Completed, 1 = Failed, 2 = wrong arguments.

Flow: start log -> portal step 4 -> parallel headless Knox logout/login, downloads and SAP logon ->
      Task 01 (only after Knox is ready) -> Task 02 -> portal step 7 -> cleanup -> Knox logout -> end log.
"""

import logging
from concurrent.futures import ThreadPoolExecutor
from runtime_support import (RunStopped, cleanup_mode, control_operation, join_control_operation,
    business_event, business_operation, emit_event, message_card, message_card_error, finish_run,
    set_business_plan, shutdown,)
from business_progress import boolean_outcome, FULL_PLAN
import sys
from pathlib import Path

import config
import portal_api
import sales_create
import task01_standardize
import task02_create
from config import FOLDERS, OTHERS
from exceptions import BotError
from rpa_core import (RUN, SECRETS, kill_processes, log_timings, portal_end, portal_log, portal_start,
    screenshot, send_error_mail, setup_logging, step, wait_for_process,)

ALL_PROGRAMS = OTHERS.vTaskList + ',saplgpad.exe,sapgui.exe,chromedriver.exe'  # 'vTaskList' + SAP GUI + web driver

def read_arguments(argv):
    """Main Task step 2 and steps 17 / 26: the workitem (ORDER_ID, MAIL_RECEIVED_DT) and the credentials of this VDI
    come from the .bat arguments. (A360 picked the credentials by Windows user, e.g. SEG_RUN01_SAP_ID - now the
    orchestrator writes the right ones into the .bat.)"""
    layout = OTHERS.argv_layout
    if len(argv) != len(layout):
        print(f"Expected {len(layout)} arguments ({' '.join(layout)}), got {len(argv)}")
        sys.exit(2)
    values = dict(zip(layout, argv))
    order_id = values.get('order_id', '').strip()
    RUN.order_id = str(int(float(order_id))) if order_id.replace('.', '', 1).isdigit() else order_id  # .Number:toString
    RUN.mail_received_dt = values.get('mail_received_dt', '')
    RUN.creds = {key: value for key, value in values.items() if key not in ('order_id', 'mail_received_dt')}
    SECRETS.update((value for value in RUN.creds.values() if len(value) >= 3))  # never written into any log
    pilots = [str(order) for order in OTHERS.pilot_order_ids]
    RUN.dry_run = bool(OTHERS.dry_run) or (bool(pilots) and RUN.order_id not in pilots)

def knox_logout():
    """Main Task step 16 and Finally step 7: Knox logout with a fresh headless browser."""
    from knox_logout import Knox_Logout
    from knox_browser import create_knox_webdriver, quit_knox_webdriver

    driver = None
    try:
        driver = create_knox_webdriver()
        Knox_Logout(driver).logout()
    except Exception as ex:
        logging.warning(f"Knox logout: {ex}")
    finally:
        quit_knox_webdriver(driver)

@business_operation("knox", outcome=boolean_outcome)
@step
def knox_login():
    """Main Task steps 16-18: headless Knox logout/login, then wait for EpTray.

    Returns True only when login succeeded and the SSO agent is running.
    """
    from knox_login import Knox_Login
    from knox_browser import quit_knox_webdriver

    knox_logout()  # step 16
    knox = Knox_Login(None)  # step 17 (own browser)
    try:
        ok = knox.login(RUN.creds['knox_id'], RUN.creds['knox_pw'])
    finally:
        quit_knox_webdriver(knox.driver)
    # A360-FIX[B16] Main Task steps 18 + 27 (steps.txt:40, 104-112)
    #   Bug: EpTray.exe was checked once right after the login; when it was not (yet) running, Task 02 was skipped
    #        silently and the run was still reported as Success. Fix: wait up to 'eptray_wait' s, else a failed run.
    ok = ok and wait_for_process('EpTray.exe', OTHERS.eptray_wait)
    if ok:
        portal_log('Knox Login successful')  # step 18
    return ok

@business_operation("sap", outcome=boolean_outcome)
def sap_logon():
    """Main Task step 26: SAP logon for system SEP. Returns True when SAP is ready."""
    try:
        sales_create.sap_login()
        return True
    except RunStopped:
        raise
    except Exception as ex:
        logging.error(f"SAP logon failed: {ex}")
        send_error_mail('SAP Logon', ex, screenshot(Path(FOLDERS.SCREENSHOTS) / 'SAP Logon Error.png'))
        portal_log('SAP Logon Error')
        # A360-KEPT[K02] Main Task step 26 (steps.txt:74-101, 112): vSOResult = vSOStatus = 'Validation', message
        #   'SAP Logon Error', and the run still ends as Success (A360 rule for 'Validation'). The A360 loop that reports
        #   every file stays switched off, as in A360 (source of lstFileIdx unknown):
        # for order in std_orders:
        #     portal_api.result_status(order.file_idx, "Validation", "Validation", "SAP Logon Error")
        #     portal_log(f"Standard Order({order.file_idx}_Fail)")
        return False

def _startup_worker(action, *, com=False):
    """Keep worker controls inside the startup boundary; own native-dialog COM."""
    with join_control_operation():
        if not com:
            return action()
        import pythoncom

        pythoncom.CoInitialize()
        try:
            return action()
        finally:
            pythoncom.CoUninitialize()

def prepare_services():
    """Overlap Knox and downloads with SAP, joining all work before cleanup.

    SAP stays on the calling thread so Task 02 and logout use its COM session
    on the same thread. Startup is one complete operation for execution controls.
    """
    with control_operation("Download files and sign in to Knox and SAP"):
        with ThreadPoolExecutor(max_workers=2, thread_name_prefix="order-startup") as pool:
            knox_ready = pool.submit(_startup_worker, knox_login, com=True)
            downloaded = pool.submit(_startup_worker, portal_api.get_order_files)
            sap_ok = sap_logon()
            try:
                files = downloaded.result()
                download_ok = True
            except RunStopped:
                raise
            except Exception as ex:
                files, download_ok = ([], False)
                portal_log(f"Order File Download Error: {ex}", error=True)
                send_error_mail('GetOrderFileByAPI', ex)
            knox_ok = knox_ready.result()
    return (files, download_ok, knox_ok, sap_ok)

@step
def main(argv):
    read_arguments(argv)
    setup_logging(RUN.order_id)
    set_business_plan(FULL_PLAN)
    logging.info(
        f"Order {RUN.order_id} | mail received {RUN.mail_received_dt} | user {RUN.user} | dry run {RUN.dry_run}"
    )
    try:
        kill_processes(ALL_PROGRAMS)  # step 1: close browser/SAP/Excel
        config.ensure_folders(OTHERS.eml_dir)  # step 1: initialize directories
        portal_start()  # steps 3, 5, 6
    except Exception as ex:
        message_card_error(115, ex)
        logging.critical(f"The run could not start: {ex}", exc_info=True)
        send_error_mail('Order Creation Main Task', ex)
        portal_api.common_api(7, 'status', 'Fail')
        portal_end(False)  # closes the portal run when its header was already created (else nothing)
        return 1
    run_ok, knox_used = (True, False)
    try:  # Try
        with control_operation("Start order processing"):
            portal_log(f"{RUN.order_id} Execution started")  # step 3
            message_card(8, order_id=RUN.order_id)
            message_card(15, header_id=RUN.inf_idx, device=RUN.device, user=RUN.user)
            api_ok = portal_api.common_api(
                4,
                "logHeaderId;device;userName",  # steps 7-12 (step 4 'start')
                f"{RUN.inf_idx};{RUN.device};{RUN.user}",
            )
            portal_log(f"API Call (Start) : {api_ok}")  # step 13
        knox_used = True  # cleanup must logout even after a partial/failed login
        files, run_ok, knox_ok, sap_ok = prepare_services()
        message_card(36, file_ids=[item[0] for item in files[:20]], count=len(files))
        if not knox_ok:
            run_ok = False
            portal_log('Knox Login failed - Task 01 and Task 02 skipped', error=True)
            business_event('standardize', 'skipped', 'Knox login is required by NASCA')
            send_error_mail("Knox Login", BotError(f"Knox login failed or EpTray.exe not running after "
                    f"{OTHERS.eptray_wait}s"),
                screenshot(Path(FOLDERS.SCREENSHOTS) / "Knox Login Error.png"),)
        # steps 19-20 (copy the templates to Temp) are not needed: the templates are opened from the project folder
        std_orders = task01_standardize.run(files)[1] if run_ok else []  # step 21: Task 01
        message_card(55, file_ids=[order.file_idx for order in std_orders[:20]])
        message_card(59, file_names=[Path(order.path).name for order in std_orders[:20]])
        if std_orders and sap_ok:
            run_ok = task02_create.run(std_orders)  # step 27: Task 02
    except RunStopped:
        run_ok = False
        logging.info('Order run stopped by the operator')
        raise
    except Exception as ex:  # Catch
        message_card_error(115, ex)
        run_ok = False
        logging.exception('Main Task failed')
        screenshot(Path(FOLDERS.SCREENSHOTS) / 'Error.png')
        portal_log(f"Error in Main Task: {ex}", error=True)
    finally:
        with cleanup_mode():
            emit_event('progress', phase='Clean-up', name='Closing programs and final reporting')
            portal_log('End Main Task')  # Finally step 1
            step7_ok = portal_api.common_api(7, 'status', 'Success' if run_ok else 'Fail')  # Finally steps 2-5
            # Finally steps 6-7: each clean-up step on its own, so one problem can never skip the END log
            # Startup workers have joined before any program is closed here.
            business_event('cleanup', 'running')
            for name, action in (("SAP logout", sales_create.sap_logout),
                ("Excel quit", lambda: RUN.excel.quit() if RUN.excel else None),
                ("close programs", lambda: kill_processes(ALL_PROGRAMS)),
                ("Knox logout", knox_logout if knox_used else lambda: None), ("timing table", log_timings),):
                try:
                    action()
                except Exception as ex:
                    logging.warning(f"Finally - {name}: {ex}")
                    business_event("cleanup", "issue", f"{name}: {ex}")
            end_ok = portal_end(run_ok and step7_ok)  # Finally step 7: end log
            business_event('cleanup', 'success')
    return 0 if run_ok and step7_ok and end_ok else 1

if __name__ == "__main__":
    exit_code = None
    try:
        exit_code = main(sys.argv[1:])
    except RunStopped:
        exit_code = 130
        logging.info('Stopped by the operator; cleanup finished')
    finally:
        finish_run(exit_code)
        if exit_code is not None:
            shutdown()
    sys.exit(exit_code)
