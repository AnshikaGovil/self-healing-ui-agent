"""Bounded debug messages and non-modal floating cards for the local monitor."""

from collections import deque
import json
import logging
import math
import os
import re
import string
import time

from business_progress import LABELS
from a360_message_catalog import MESSAGES, API_RESPONSE_SOURCES

CARD_SECONDS = 3.0
API_CARD_SECONDS = 12.0
MAX_CARD_SECONDS = 45.0
HISTORY_LIMIT = 20
VISIBLE_LIMIT = 3
MAX_EVENT_AGE = 5
TITLE_LIMIT, TEXT_LIMIT, ID_LIMIT = (80, 1200, 64)
API_TEXT_LIMIT = 4096
# Card rows: [[label, value, style], ...] per line, shown as label/value columns.
ROW_LIMIT, PAIR_LIMIT, LABEL_LIMIT = (40, 4, 28)
# mono: technical values such as IDs, payloads, locations; hot: the highlighted result
ROW_STYLES = {'', 'mono', 'hot'}
# Card width: this share of the screen's usable width, kept between readable
# limits given in pixels at 100% Windows scaling (multiplied by the DPI scale).
CARD_SHARE, CARD_MIN_WIDTH, CARD_MAX_WIDTH = (0.34, 380, 920)
PRIORITY = {'info': 0, 'success': 0, 'warning': 1, 'error': 2}
# Within one tone, the category that survives a burst longest has the highest rank.
CATEGORY_RANK = {'order_type': 2, 'api_response': 2, 'a360_message': 1}
# Only the values a template shows are formatted (e.g. not the 20 Outlook results).
TEMPLATE_FIELDS = {line: {name for _, name, _, _ in string.Formatter().parse(spec["template"]) if name}
    for line, spec in MESSAGES.items()}
# "Label: {field}" parts of a template line become a labelled pair.
TEMPLATE_PAIR = re.compile('([A-Za-z][^:{}|\\n]{0,30}): (.*)', re.S)

def _style(value_template):
    names = {name for _, name, _, _ in string.Formatter().parse(value_template) if name}
    technical = {'payload', 'response', 'location'}
    return 'mono' if any((n in technical or n.endswith(('_id', '_ids')) for n in names)) else ''

def _template_rows(template):
    """One row per template line: labelled pairs split at ' | ', or one plain part."""
    rows = []
    for line in template.split("\n"):
        pairs = [TEMPLATE_PAIR.fullmatch(part) for part in line.split(' | ')]
        if all(pairs):
            rows.append([(pair[1], pair[2], _style(pair[2])) for pair in pairs])
        else:
            rows.append([('', line, _style(line))])
    return rows

TEMPLATE_ROWS = {line: _template_rows(spec['template']) for line, spec in MESSAGES.items()}
STEP_STATES = {"running": ("Started", "info"), "success": ("Completed", "success"),
    "failed": ("Failed; check the log", "error"), "issue": ("An issue was recorded", "warning"),
    "unconfirmed": ("Result not confirmed; check the log", "warning"),
    "preview": ("Preview completed; no SAP order saved", "info"),
    "skipped": ("Skipped by the workflow", "info"),}
CONTROL_MODES = {"pause_requested": "Pausing after the current operation",
    "paused": "Paused at an operation boundary", "stepping": "Running one operation, then pausing again",
    "running": "Execution resumed", "stopping": "Stopping pending work; cleanup will follow",}

def relative_width(available, scale, share, minimum, maximum):
    """A share of the available pixels, within DPI-scaled limits and never wider than the screen."""
    width = min(max(available * share, minimum * scale), maximum * scale)
    return max(1, round(min(width, available)))

def is_api_card(card):
    sources = card.get('source_lines', [])
    return card.get("category") == "api_response" or (isinstance(sources, list)
        and any(source in API_RESPONSE_SOURCES.values() for source in sources))

def text_limit(card):
    return API_TEXT_LIMIT if is_api_card(card) else TEXT_LIMIT

def display_seconds(card):
    """Allow time to read longer cards without blocking the automation."""
    minimum = API_CARD_SECONDS if is_api_card(card) else CARD_SECONDS
    reading = 3 + len(card.get('text', '')) / 24
    return min(MAX_CARD_SECONDS, max(minimum, reading))

def clip(value, limit=180):
    text = ' '.join(str(value if value is not None else '').split())
    return text if len(text) <= limit else text[:max(0, limit - 3)] + '.' * min(3, limit)

def clip_lines(value, limit=TEXT_LIMIT):
    """clip() that keeps line breaks; blank lines are dropped."""
    lines = (' '.join(line.split()) for line in str(value).split('\n'))
    text = '\n'.join((line for line in lines if line))
    return text if len(text) <= limit else text[:max(0, limit - 3)] + '.' * min(3, limit)

def highlight(rows, label):
    """Move the pair with this label into its own 'hot' row, keeping the order."""
    result = []
    for row in rows:
        current = []
        for pair in row:
            if pair[0] == label:
                if current:
                    result.append(current)
                result.append([[pair[0], pair[1], 'hot']])
                current = []
            else:
                current.append(pair)
        if current:
            result.append(current)
    return result

def plain_rows(text):
    return [[['', line, '']] for line in str(text).split('\n')]

def bound_rows(rows, limit=TEXT_LIMIT):
    """Preserve line breaks within the card's text budget; None when empty."""
    bounded, budget = ([], limit)
    for row in rows[:ROW_LIMIT]:
        if budget <= 0:
            break
        pairs = []
        for label, value, style in row[:PAIR_LIMIT]:
            if budget <= 0:
                break
            label = clip(label, LABEL_LIMIT)
            value = clip_lines(value, budget) or ('-' if label else '')
            budget -= len(value)
            pairs.append([label, value, style if style in ROW_STYLES else ''])
        if any(value for _, value, _ in pairs):
            bounded.append(pairs)
    return bounded or None

def clean_rows(rows, limit=TEXT_LIMIT):
    """Rows read back from the status file, or None to show the card's plain text."""
    if not isinstance(rows, list):
        return None
    for row in rows:
        if not isinstance(row, list) or not row:
            return None
        for pair in row:
            if not (isinstance(pair, list) and len(pair) == 3 and all(isinstance(part, str) for part in pair)
            ):
                return None
    return bound_rows(rows, limit)

def _readable(value):
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False)
    return str(value if value is not None else '')

def _a360_card(event):
    line = event.get('source_line')
    spec = MESSAGES.get(line)
    if spec is None:
        return None
    values = event.get('values', {})
    report = values.get('report')
    combined = {**report, **values} if isinstance(report, dict) else values
    fields = {name: _readable(combined[name]) if name in combined else '-' for name in TEMPLATE_FIELDS[line]}
    detail = spec['template'].format(**fields)
    rows = []
    for template_row in TEMPLATE_ROWS[line]:
        label, value_template, style = template_row[0]
        if label:
            rows.append([[name, value.format(**fields), kind] for name, value, kind in template_row])
        else:
            rows.extend(([['', part, style]] for part in value_template.format(**fields).split('\n')))
    tone = spec['tone']
    if spec.get("payload"):
        sent = 'Preview; request not sent' if values.get('dry_run') else 'Prepared payload'
        detail = sent + '\n' + detail
        rows.insert(0, [['', sent, '']])
    if spec.get("status_tone"):
        status = values.get('status_type')
        tone = 'error' if status == 'E' else 'warning' if status == 'W' else 'info'
    if spec.get("hot"):
        rows = highlight(rows, spec['hot'])
    if line in API_RESPONSE_SOURCES.values():
        rows = [[['', detail, 'mono']]]
    return (tone, spec['title'], detail, event.get('source_lines', [line]), rows)

def _order_type_card(event):
    detail = clip(event.get('layout') or 'Unknown order type', 80)
    if event.get("name"):
        detail += '\n' + clip(event['name'], 90)
    rows = [[['Layout', clip(event.get('layout') or 'Unknown order type', 80), '']]]
    if event.get("name"):
        rows.append([['File', clip(event['name'], 90), '']])
    return ('info', 'Order type detected', detail, [], rows)

def _api_card(event):
    http, status = (event.get('http_status'), event.get('status'))
    http_text = http if http not in (None, '') else 'unavailable'
    status_text = status if status not in (None, '') else 'unavailable'
    detail = f"HTTP {http_text} | API {status_text} | Try {event.get('attempt', '?')}"
    summary, response = (event.get('summary'), event.get('response'))
    summary = clip_lines(summary, API_TEXT_LIMIT) if summary else ''
    response = clip_lines(response, API_TEXT_LIMIT) if response else ''
    # Show the captured body as well as a useful summary. API responses often
    # contain important fields beyond the short portal message.
    details = []
    if summary and response and not response.startswith(summary):
        details.append((summary, ''))
    if response:
        details.append((response, 'mono'))
    elif summary:
        details.append((summary, ''))
    if details:
        detail += '\n' + '\n'.join((text for text, _ in details))
    if not event.get("acknowledged"):
        tone = 'error'
    else:
        tone = 'warning' if isinstance(http, int) and http >= 400 else 'success'
    source_line = API_RESPONSE_SOURCES.get(event.get('resource'))
    source_lines = [source_line] if source_line is not None else []
    title = 'API response: ' + clip(event.get('resource', ''), 48)
    rows = [[["HTTP", str(http_text), ""], ["API", str(status_text), ""],
            ["Try", str(event.get("attempt", "?")), ""],]]
    rows.extend(([['', text, style]] for text, style in details))
    return (tone, title, detail, source_lines, rows)

def _business_card(event):
    detail, tone = STEP_STATES.get(event.get('state'), ('', 'info'))
    if event.get("message"):
        detail += '\n' + clip_lines(event['message'], TEXT_LIMIT)
    return (tone, LABELS.get(event.get('key')), detail, [], None)

def _finished_card(event):
    if event.get("reason") == "stopped":
        return ('info', 'Execution stopped', 'Cleanup completed', [], None)
    code = event.get('exit_code')
    if code is None:
        rows = [[['Exit code', 'not recorded', '']]]
        return ('info', 'Execution finished', 'Exit code: not recorded', [], rows)
    tone = 'success' if code == 0 else 'error'
    rows = [[['Exit code', str(code), '']]]
    return tone, "Execution finished", f"Exit code: {code}", [], rows

def _log_card(event, level, text):
    if level >= logging.ERROR:
        tone, title = ('error', 'Error')
    elif level >= logging.WARNING:
        tone, title = ('warning', 'Warning')
    else:
        tone, title = ('info', 'Run message')
    return (tone, title, clip_lines(event.get('message') or text, TEXT_LIMIT), [], None)

DESCRIBE = {"a360_message": _a360_card, "run_started": lambda event: ("info", "Order run started",
        "Monitoring is connected", [], None,), "order_type": _order_type_card, "api_response": _api_card,
    "business_step": _business_card, "run_finished": _finished_card,}

class MessageHistory:
    """Collect already redacted observations on the existing logging thread."""

    def __init__(self):
        self.messages = deque(maxlen=HISTORY_LIMIT)
        self.last_signature = None
        self.last_timestamp = 0
        self.last_control = None

    def add(self, event, level=logging.INFO, text=""):
        """Record a card for this event; True only when one was added."""
        kind = event.get('event')
        if kind == "control_status":
            card = self._control_card(event)
        elif kind in DESCRIBE:
            card = DESCRIBE[kind](event)
        elif kind in {"notification", "monitor_message"} or level >= logging.WARNING:
            card = _log_card(event, level, text)
        else:
            return False
        if card is None:
            return False
        tone, title, detail, source_lines, rows = card
        limit = text_limit({'category': kind, 'source_lines': source_lines})
        title, detail = (clip(title, TITLE_LIMIT), clip_lines(detail, limit))
        if not title or not detail:
            return False
        rows = bound_rows(rows or plain_rows(detail), limit)
        signature = (tone, title, detail, event.get('order_id'), event.get('file_id'))
        timestamp = event.get('timestamp', 0)
        if (signature == self.last_signature and 0 <= timestamp - self.last_timestamp < CARD_SECONDS):
            return False
        self.last_signature, self.last_timestamp = (signature, timestamp)
        self.messages.append({"id": event["sequence"], "run_id": event["run_id"], "timestamp": timestamp,
                "tone": tone, "category": kind, "source_lines": source_lines, "title": title, "text": detail,
                "rows": rows, "order_id": clip(event.get("order_id", "-"), ID_LIMIT),
                "file_id": clip(event.get("file_id", "-"), ID_LIMIT),})
        return True

    def _control_card(self, event):
        control = event.get('control', {})
        identity = (control.get('last_sequence', 0), control.get('mode'))
        if not identity[0] or identity == self.last_control:
            return None  # heartbeats repeat the same control state
        self.last_control = identity
        mode = CONTROL_MODES.get(control.get('mode'), '')
        return ('info', 'Execution control', mode, [], None)

    def snapshot(self):
        return [dict(message) for message in self.messages]

class CardTimeline:
    """Expire from first display, without restarting timers on repeated snapshots."""

    def __init__(self):
        self.run_id = None
        self.last_id = 0
        self.active = {}

    def feed(self, state, now=None, wall_now=None):
        now = time.monotonic() if now is None else now
        wall_now = time.time() if wall_now is None else wall_now
        if not state:
            return self.expire(now)
        run_id = state.get('run_id')
        if run_id != self.run_id:
            self.run_id, self.last_id, self.active = (run_id, 0, {})
        messages = state.get('message_cards', [])
        if "message_cards" not in state and state.get("notification"):
            notice = state['notification']
            if not isinstance(notice, dict):
                notice = {}
            messages = [{"id": notice.get("sequence"), "run_id": run_id,
                    "timestamp": notice.get("timestamp"), "tone": "warning", "title": "Run message",
                    "text": notice.get("text"), "order_id": state.get("order_id", "-"),
                    "file_id": state.get("file_id", "-"),}]
        if not isinstance(messages, list):
            messages = []
        self.expire(now)
        for message in messages[-HISTORY_LIMIT:]:
            if not isinstance(message, dict) or message.get("run_id") != run_id:
                continue
            identifier, timestamp = (message.get('id'), message.get('timestamp'))
            if (not isinstance(identifier, int) or isinstance(identifier, bool) or identifier <= self.last_id
            ):
                continue
            self.last_id = identifier
            if (not isinstance(timestamp, (int, float)) or not math.isfinite(timestamp)
                or not 0 <= wall_now - timestamp <= MAX_EVENT_AGE):
                continue
            tone = message.get('tone')
            if (not isinstance(tone, str) or tone not in PRIORITY
                or not isinstance(message.get("title"), str) or not isinstance(message.get("text"), str)):
                continue
            # The status file is read from disk: bound it again before display.
            limit = text_limit(message)
            card = dict(message, title=clip(message["title"], TITLE_LIMIT),
                text=clip_lines(message["text"], limit), rows=clean_rows(message.get("rows"), limit),
                order_id=clip(message.get("order_id", "-"), ID_LIMIT),
                file_id=clip(message.get("file_id", "-"), ID_LIMIT),)
            self.active[identifier] = (card, now + display_seconds(card))
            if len(self.active) > VISIBLE_LIMIT:
                del self.active[min(self.active, key=self._rank)]
        return self.current()

    def _rank(self, identifier):
        """Lowest rank is evicted first: routine info, then older cards."""
        card = self.active[identifier][0]
        category = card.get('category')
        category_rank = CATEGORY_RANK.get(category, 0) if isinstance(category, str) else 0
        return (PRIORITY[card['tone']], category_rank, identifier)

    def expire(self, now=None):
        if not self.active:
            return []
        now = time.monotonic() if now is None else now
        self.active = {key: item for key, item in self.active.items() if item[1] > now}
        return self.current()

    def dismiss(self, identifier):
        self.active.pop(identifier, None)

    def remaining(self, now=None):
        """Time left on the visible cards, for the monitor's completion timer."""
        now = time.monotonic() if now is None else now
        return max(0, max((expiry - now for _, expiry in self.active.values()), default=0))

    def current(self):
        return [self.active[key][0] for key in sorted(self.active)]

# The report card as sample.mp4 shows it (the hud.py reference overlay rendered):
# a slate body with a light 1 px border, a saturated accent bar, a letter-spaced
# uppercase heading in the card's colour, label/value rows, an amber band for the
# result and a plain footer sentence under a divider. Colours sampled from the video.
CARD_BACKGROUND, CARD_BORDER, CARD_DIVIDER = ('#4a4e5a', '#677289', '#5a6072')
LABEL_COLOUR, VALUE_COLOUR, MONO_COLOUR = ('#c9d8f2', '#f4f8ff', '#d6e4ff')
FOOT_COLOUR = '#dce6f7'
HOT_BACKGROUND, HOT_EDGE, HOT_LABEL, HOT_VALUE = ('#6a5a4a', '#f79009', '#ffc978', '#ffd9a0')
CARD_ALPHA = 0.95  # solid enough that text behind does not show through
TONE_COLOURS = {# tone: (accent bar, heading)
    "info": ("#7fa6ff", "#8db0ff"),
    "success": ("#17b26a", "#7be3b0"),
    "warning": ("#f79009", "#ffc978"),
    "error": ("#e5484d", "#ff9a9a"),
}
CARD_FONTS = {"head": ("Segoe UI", 11, "bold"), "close": ("Segoe UI", 15), "label": ("Segoe UI", 10),
    "value": ("Segoe UI Semibold", 12), "plain": ("Segoe UI", 12), "mono": ("Consolas", 11),
    "hot": ("Segoe UI", 14, "bold"), "foot": ("Segoe UI", 10),}

def spaced(text):
    """Letter-spaced capitals as in the reference; Tk has no letter-spacing, so hair spaces."""
    return '\u200a'.join(text.upper())

def move_order(moves):
    """Order card moves so no card passes over another on screen.

    moves: (key, old (x, y) or None, new (x, y)). Rising cards go top first and
    falling cards bottom first, so each moves into space already vacated, like a
    memmove. Unmoved cards are skipped; new cards, still invisible, come last.
    """
    moved = [move for move in moves if move[1] is not None and move[1] != move[2]]
    rising = sorted((m for m in moved if m[2][1] < m[1][1]), key=lambda m: m[2][1])
    falling = sorted((m for m in moved if m[2][1] >= m[1][1]), key=lambda m: -m[2][1])
    new = [move for move in moves if move[1] is None]
    return [move[0] for move in rising + falling + new]

def card_x(area, width, top, height, monitor, gap):
    """Left edge of a card centred at the bottom of the screen, moved aside if it would cover the monitor."""
    left, _, right, _ = area
    x = left + (right - left - width) // 2
    monitor_left, monitor_top, monitor_right, monitor_bottom = monitor
    covers = (x < monitor_right + gap and x + width + gap > monitor_left and top < monitor_bottom + gap
        and top + height + gap > monitor_top)
    if covers:
        x = monitor_left - gap - width  # left of the monitor
        if x < left + gap:
            x = monitor_right + gap  # no room: right of it
    return max(left + gap, min(x, right - width - gap))

class MessageCards:
    """Independent tool windows: no grab, wait_window, messagebox or bot controls."""

    def __init__(self, root, scale, work_area, prevent_focus):
        from tkinter import font as tkfont

        self.root, self.scale = (root, scale)
        self.work_area, self.prevent_focus = (work_area, prevent_focus)
        self.fonts = {name: tkfont.Font(root=root, font=spec) for name, spec in CARD_FONTS.items()}
        self.gap, self.row_pad = (round(10 * scale), max(1, round(scale)))
        self.timeline = CardTimeline()
        self.views = {}
        self.closed = False
        root.bind('<Destroy>', self._destroyed, add='+')
        root.bind('<Configure>', self._moved, add='+')
        self.timer = root.after(100, self._tick)

    def feed(self, state):
        self.timeline.feed(state)
        self._sync()

    def _tick(self):
        if self.closed:
            return
        self.timeline.expire()
        self._sync()
        self.timer = self.root.after(100, self._tick)

    def _destroyed(self, event):
        if event.widget == self.root:
            self.closed = True
            self.root.after_cancel(self.timer)
            self.views.clear()

    def _moved(self, event):
        if event.widget == self.root and self.views:
            self._position()

    def _sync(self):
        active = {card['id']: card for card in self.timeline.current()}
        changed = False
        for identifier in list(self.views):
            if identifier not in active:
                self.views.pop(identifier).destroy()
                changed = True
        for identifier, card in active.items():
            if identifier not in self.views:
                self.views[identifier] = self._create(card)
                changed = True
        if changed:
            self._position()

    def _card_width(self, card):
        """Fit measured content, growing for long messages within the work area."""
        left, _, right, _ = self.work_area(self.root)
        available = max(1, right - left - self.root.winfo_width() - 3 * self.gap)
        rows = card.get('rows') or plain_rows(card['text'])
        widths = []
        for row in rows:
            for label, value, style in row:
                label_width = self.fonts['label'].measure(spaced(label)) + self.gap if label else 0
                font = self.fonts[self._value_style(style)[0]]
                widths.extend((label_width + font.measure(line) for line in value.split('\n')))
            if all("\n" not in value for _, value, _ in row):
                widths.append(self._line_width(row))
        widths.append(self.fonts['head'].measure(spaced(card['title'])) + 3 * self.gap)
        # More content benefits from a wider card, even when each line is short.
        content_width = max(max(widths, default=0),
            math.sqrt(sum(widths) * self.fonts["plain"].metrics("linespace") * 2.4),)
        wanted = content_width + round(34 * self.scale)
        return max(1, round(min(available, CARD_MAX_WIDTH * self.scale,
                      max(CARD_MIN_WIDTH * self.scale, wanted))),)

    def _create(self, card):
        import tkinter as tk

        accent, heading = TONE_COLOURS[card['tone']]
        width = self._card_width(card)
        bar = max(3, round(4 * self.scale))
        pad_x, pad_y = (round(14 * self.scale), round(10 * self.scale))
        content = max(1, width - bar - 2 - 2 * pad_x)
        window = tk.Toplevel(self.root, bg=CARD_BORDER)  # the border shows around the body
        window.withdraw()
        window.overrideredirect(True)
        window.attributes('-topmost', True)
        window.attributes('-alpha', 0.0)  # invisible until drawn; see _reveal()
        tk.Frame(window, bg=accent, width=bar).pack(side='left', fill='y', padx=(1, 0), pady=1)
        body = tk.Frame(window, bg=CARD_BACKGROUND, padx=pad_x, pady=pad_y)
        body.pack(fill='both', expand=True, padx=(0, 1), pady=1)
        top = tk.Frame(body, bg=CARD_BACKGROUND)
        top.pack(fill='x')
        close = self._text(top, '×', 'close', LABEL_COLOUR, cursor='hand2')
        close.pack(side='right', anchor='n')
        close.bind('<Button-1>', lambda event: self._dismiss(card['id']))
        self._text(top, spaced(card["title"]), "head", heading, wrap=max(1, content - 3 * self.gap)
        ).pack(side="left", fill="x", expand=True)
        rows = card.get('rows') or plain_rows(card['text'])
        self._scrollable_rows(body, rows, content).pack(fill='x', pady=(round(5 * self.scale), 0))
        tk.Frame(body, bg=CARD_DIVIDER, height=1).pack(
            fill="x", pady=(round(6 * self.scale), round(5 * self.scale)))
        foot = 'Order ' + card['order_id']
        if card["file_id"] not in {"", "-"}:
            foot += '  ·  File ' + card['file_id']
        self._text(body, foot, 'foot', FOOT_COLOUR, wrap=content).pack(fill='x')
        window.drawn = window.revealed = False
        window.placed = None  # (x, y) once positioned
        # Tk labels get no <Expose> on Windows; the body frame does once it is painted.
        body.bind('<Expose>', lambda event: setattr(window, 'drawn', True))
        window.update_idletasks()
        self.prevent_focus(window)
        self._window_style(window)
        window.geometry(f"{width}x{window.winfo_reqheight()}")
        window.card_width = width  # text was wrapped for this width
        return window

    def _scrollable_rows(self, parent, rows, width):
        """Grow vertically for wrapped text; scroll when it would dominate the screen."""
        import tkinter as tk

        _, top, _, bottom = self.work_area(self.root)
        maximum = max(1, round((bottom - top) * 0.4))
        container = tk.Frame(parent, bg=CARD_BACKGROUND)
        canvas = tk.Canvas(container, bg=CARD_BACKGROUND, highlightthickness=0, borderwidth=0, width=width)
        canvas.pack(side='left', fill='both', expand=True)
        grid = self._rows(canvas, rows, width)
        item = canvas.create_window(0, 0, window=grid, anchor='nw', width=width)
        grid.update_idletasks()
        if grid.winfo_reqheight() > maximum:
            scrollbar = tk.Scrollbar(container, orient='vertical', command=canvas.yview)
            scrollbar.pack(side='right', fill='y')
            scrollbar.update_idletasks()
            width = max(1, width - scrollbar.winfo_reqwidth())
            grid.destroy()
            grid = self._rows(canvas, rows, width)
            canvas.itemconfigure(item, window=grid, width=width)
            canvas.configure(width=width, yscrollcommand=scrollbar.set)
            grid.update_idletasks()

            def scroll(event):
                canvas.yview_scroll(-1 if event.delta > 0 or event.num == 4 else 1, 'units')
                return 'break'

            def bind_scroll(widget):
                widget.bind('<MouseWheel>', scroll)
                widget.bind('<Button-4>', scroll)
                widget.bind('<Button-5>', scroll)
                for child in widget.winfo_children():
                    bind_scroll(child)

            bind_scroll(container)
        height = min(maximum, grid.winfo_reqheight())
        canvas.configure(height=height, scrollregion=(0, 0, width, grid.winfo_reqheight()))
        return container

    def _text(self, parent, text, font, colour, wrap=0, background=CARD_BACKGROUND, **options):
        import tkinter as tk

        return tk.Label(parent, text=text, font=self.fonts[font], fg=colour, bg=background, anchor="w",
            justify="left", wraplength=max(1, wrap) if wrap else 0, padx=0, pady=0, borderwidth=0, **options,
        )

    @staticmethod
    def _value_style(style):
        if style == "mono":
            return ('mono', MONO_COLOUR)
        return ('hot', HOT_VALUE) if style == 'hot' else ('value', VALUE_COLOUR)

    def _offset(self, label_font, value_font):
        """Top padding that puts a smaller label on the value's baseline."""
        ascent = self.fonts[value_font].metrics('ascent')
        return max(0, ascent - self.fonts[label_font].metrics('ascent'))

    def _line_width(self, pairs):
        """Pixel width of pairs drawn side by side by _pair_line()."""
        width = 0
        for index, (label, value, style) in enumerate(pairs):
            if label:
                width += self.gap if index else 0
                width += self.fonts['label'].measure(spaced(label)) + self.gap // 2
            width += self.fonts[self._value_style(style)[0]].measure(value)
        return width

    def _pair_line(self, parent, pairs):
        """LABEL value   LABEL value on one line."""
        import tkinter as tk

        line = tk.Frame(parent, bg=CARD_BACKGROUND)
        for index, (label, value, style) in enumerate(pairs):
            font, colour = self._value_style(style)
            if label:
                self._text(line, spaced(label), "label", LABEL_COLOUR).pack(side="left", anchor="n",
                    padx=(self.gap if index else 0, self.gap // 2), pady=(self._offset("label", font), 0),)
            self._text(line, value, font, colour).pack(side='left', anchor='n')
        return line

    def _hot_row(self, parent, label, value, column, width):
        """The amber band the reference gives the one result the card is about."""
        import tkinter as tk

        edge, pad = (max(2, round(3 * self.scale)), round(8 * self.scale))
        band = tk.Frame(parent, bg=HOT_BACKGROUND)
        tk.Frame(band, bg=HOT_EDGE, width=edge).pack(side='left', fill='y')
        inner = tk.Frame(band, bg=HOT_BACKGROUND, pady=round(4 * self.scale))
        inner.pack(side='left', fill='both', expand=True, padx=pad)
        inner.columnconfigure(0, minsize=max(column - edge - pad, 0))  # values stay aligned
        self._text(inner, spaced(label), "label", HOT_LABEL,
            wrap=max(1, column - edge - pad), background=HOT_BACKGROUND,).grid(
            row=0, column=0, sticky="nw", pady=(self._offset("label", "hot"), 0))
        self._text(inner, value, "hot", HOT_VALUE, wrap=width - column - pad, background=HOT_BACKGROUND,
        ).grid(row=0, column=1, sticky="nw")
        return band

    def _rows(self, parent, rows, width):
        """Labels in one column, values beside them; wrapped values stay in their column."""
        import tkinter as tk

        grid = tk.Frame(parent, bg=CARD_BACKGROUND)
        band = max(2, round(3 * self.scale)) + round(8 * self.scale)  # hot row edge + padding
        labels = [self.fonts["label"].measure(spaced(row[0][0])) + (band if row[0][2] == "hot" else 0)
            for row in rows if row[0][0]]
        column = 0
        if labels:
            column = min(max(labels) + self.gap, round(width * 0.38))
            grid.columnconfigure(0, minsize=column)
        grid.columnconfigure(1, weight=1)
        value_width = width - column
        line = 0
        for row in rows:
            label, value, style = row[0]
            if label and style == "hot":
                self._hot_row(grid, label, value, column, width).grid(row=line, column=0, columnspan=2,
                    sticky="ew", pady=(round(4 * self.scale), round(3 * self.scale)),)
                line += 1
                continue
            if not label:  # plain text uses the full width
                font = 'mono' if style == 'mono' else 'plain'
                text = '   '.join((value for _, value, _ in row))
                self._text(grid, text, font, VALUE_COLOUR, wrap=width).grid(
                    row=line, column=0, columnspan=2, sticky="w", pady=self.row_pad)
                line += 1
                continue
            inline = [['', value, style]] + row[1:]
            # Several pairs share a line when they fit; otherwise one pair per line.
            pieces = [row] if self._line_width(inline) <= value_width else [[p] for p in row]
            for piece in pieces:
                (label, value, style), rest = (piece[0], piece[1:])
                font, colour = self._value_style(style)
                self._text(grid, spaced(label), "label", LABEL_COLOUR, wrap=column - self.gap).grid(
                    row=line, column=0, sticky="nw",
                    pady=(self.row_pad + self._offset("label", font), self.row_pad),)
                if rest:
                    cell = self._pair_line(grid, [['', value, style]] + rest)
                else:
                    cell = self._text(grid, value, font, colour, wrap=value_width)
                cell.grid(row=line, column=1, sticky='nw', pady=self.row_pad)
                line += 1
        return grid

    @staticmethod
    def _window_style(window):
        """Windows 11 rounded corners and shadow; shown at once, without the fade-in.
        Older Windows keeps square corners."""
        if os.name != "nt":
            return
        try:
            import ctypes

            user32, dwmapi = (ctypes.windll.user32, ctypes.windll.dwmapi)
            user32.GetParent.argtypes = [ctypes.c_void_p]
            user32.GetParent.restype = ctypes.c_void_p
            hwnd = user32.GetParent(window.winfo_id()) or window.winfo_id()
            # DWMWA_TRANSITIONS_FORCEDISABLED, DWMWA_WINDOW_CORNER_PREFERENCE = round,
            # DWMWA_BORDER_COLOR = none (the card draws its own border)
            for attribute, value in ((3, 1), (33, 2), (34, 0xFFFFFFFE)):
                data = ctypes.c_uint(value)
                dwmapi.DwmSetWindowAttribute(ctypes.c_void_p(hwnd), attribute, ctypes.byref(data),
                    ctypes.sizeof(data),)
        except (AttributeError, OSError):
            pass

    def _reveal(self, window, attempt=0):
        """Make a card visible only once Tk has drawn it, so it never shows as an empty box."""
        if self.closed or not window.winfo_exists():
            return
        if window.drawn or attempt >= 30:  # 30 x 10 ms: show it anyway
            window.update_idletasks()
            window.attributes('-alpha', CARD_ALPHA)
        else:
            window.after(10, self._reveal, window, attempt + 1)

    def _dismiss(self, identifier):
        self.timeline.dismiss(identifier)
        self._sync()

    def _position(self):
        """Bottom centre of the screen as in the reference, newest lowest, clear of the monitor."""
        area = self.work_area(self.root)
        left, top, right, bottom = area
        # Large responses can take more room than three short cards. Keep the
        # highest-priority cards that fit instead of overlapping their content.
        available_height = bottom - top - round(18 * self.scale) - self.gap
        while len(self.views) > 1 and sum(
            window.winfo_reqheight() + self.gap for window in self.views.values()) > available_height:
            identifier = min(self.views, key=self.timeline._rank)
            self.timeline.dismiss(identifier)
            self.views.pop(identifier).destroy()
        root_x, root_y = (self.root.winfo_x(), self.root.winfo_y())
        monitor = (root_x, root_y, root_x + self.root.winfo_width(), root_y + self.root.winfo_height())
        y = bottom - round(18 * self.scale)
        targets, moves = ({}, [])
        for identifier in reversed(sorted(self.views)):
            window = self.views[identifier]
            width, height = (window.card_width, window.winfo_reqheight())
            y -= height
            card_top = max(top + self.gap, y)
            place = (card_x(area, width, card_top, height, monitor, self.gap), card_top)
            targets[identifier] = (width, height, place)
            moves.append((identifier, window.placed, place))
            y -= self.gap
        for identifier in move_order(moves):
            window = self.views[identifier]
            width, height, (x, card_top) = targets[identifier]
            window.geometry(f"{width}x{height}+{x}+{card_top}")
            window.placed = (x, card_top)
            if not window.revealed:  # shown once: re-showing would re-raise it over newer cards
                window.revealed = True
                window.deiconify()
                window.after(10, self._reveal, window)
