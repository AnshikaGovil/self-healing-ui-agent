"""Shared building blocks of the R1904002-001 Order Creation bot (used by every task).
What is inside (A360 reference = 'Order Creation A360 steps.txt'):
    RUN / StdOrder ..... the variables A360 passed between its tasks (vOrderIdx, vFileIdxs, vFileNames, vSOResult ...)
    Logging ............ local log files + RPA portal logs through the HQ scripts python_Start/Detail/End_log.py
    E-mail ............. SMTP relay (replaces the A360 'Send email' actions)
    Processes .......... close Excel/SAP/browser, wait for EpTray.exe, screenshots
    ExcelSession ....... ONE Excel for the whole run (the files are NASCA DRM protected -> Excel COM only)
    VBA helpers ........ CStr, IsDate/CDate, Like, CCur, NETWORKDAYS ... so the converted Macro.xlsm code behaves the same
The HQ files CommonModule.py, PortalCommunicationAPI.py, python_Start_log.py, python_Detail_log.py and
python_End_log.py are used exactly as they are.
"""

import faulthandler
import functools
import getpass
import logging
import os
import re
import smtplib
import sys
import threading
import time
import traceback
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from decimal import ROUND_HALF_EVEN, Decimal
from email.message import EmailMessage
from pathlib import Path
import psutil
import pythoncom
import requests
import win32com.client
import win32process
from config import FOLDERS, OTHERS
from exceptions import BotError
from runtime_support import configure_logging, emit_event, shutdown

# CommonModule.py (HQ file, not changed) calls requests.post() WITHOUT a timeout. In a single-threaded bot a hanging
# portal would block forever, so every requests call that has no timeout gets one here.
_original_request = requests.Session.request

def _request_with_timeout(self, method, url, **kwargs):
    kwargs.setdefault('timeout', (5, 60))
    return _original_request(self, method, url, **kwargs)

requests.Session.request = _request_with_timeout

# Run variables (A360 variables that were passed between the tasks)
@dataclass
class StdOrder:
    """One standardized order file = one sales order (A360: one entry of vFileIdxs / vFileNames after Task 01)."""

    file_idx: str  # portal file id (vFileIdx)
    orig_name: str  # original attachment name (vFileName)
    path: str = ''  # standardized file in the Template folder
    rows: list = field(default_factory=list)  # the standardized sheet: rows[0] = Excel row 1, rows[r][0] = column A
    report: dict = field(default_factory=dict)  # values for the portal (sales org, sold-to, ship-to, RDD, counts)
    result_idx: str = ''  # vResultIdx (SetOrderResultStartByAPI)
    retry_flag: str = ''  # vRetryFlag = processableYn
    so_number: str = ''
    so_creation_date: str = ''
    so_result: str = ''  # Success / Fail / Validation / SYSTEM
    so_status: str = ''
    result_message: str = ''
    business_error: bool = False  # vBusinessErrorHandlingFlag
    system_error: bool = False  # vErrorHandlingFlag = False
    validation_flag: bool = False  # vValidationFlag
    status_sent: bool = False  # a final status was sent to the portal for this order

@dataclass
class RunContext:
    """Values of the whole run (A360 Main Task variables)."""

    order_id: str = ''  # vOrderIdx / vREF_ID
    mail_received_dt: str = ''  # vReceiveDate
    creds: dict = field(default_factory=dict)  # Knox / mail / SAP IDs and passwords from the .bat arguments
    user: str = field(default_factory=getpass.getuser)
    inf_idx: str = ''  # vInfldxForPortal (logHeaderId)
    device: str = ''  # vDevice
    dry_run: bool = False  # True = no SAP save, no portal status/API POST, no mails
    portal_started: bool = False
    portal_ended: bool = False
    excel: object = None  # ExcelSession
    sap: object = None  # sap_logon.SAPLogin
    session: object = None  # the ONE SAP GUI session

RUN = RunContext()

# Logging
LOG_CONTEXT = {'order': '-', 'file_idx': '-'}
SECRETS = set()  # passwords / IDs that must never appear in a log line
TIMINGS = []  # (step, seconds) -> timing table at the end of the run
NOTICES = []  # warnings repeated in the end-of-run summary
_CRASH_FILE = None
_STEP_CONTEXT = threading.local()

class _ContextFilter(logging.Filter):
    """Adds order id / file id to every log line (also to the lines of other libraries)."""

    def filter(self, record):
        record.order, record.file_idx = (LOG_CONTEXT['order'], LOG_CONTEXT['file_idx'])
        return True

class _SecretFormatter(logging.Formatter):
    """Writes the log line and replaces every password / ID from the .bat by \*\*\* - also inside error tracebacks."""

    def format(self, record):
        text = super().format(record)
        for secret in sorted(SECRETS, key=len, reverse=True):
            text = text.replace(secret, '***')
        return text

def setup_logging(order_id="manual"):
    """Start the local log files - every task calls this first.
    INFO log  = what happened (for operators).   DEBUG log = every SAP / Excel / API detail (developers, kept local).
    """
    global _CRASH_FILE
    shutdown()
    LOG_CONTEXT['order'] = str(order_id)
    log_dir = Path(FOLDERS.LOGS) / 'Python'
    log_dir.mkdir(parents=True, exist_ok=True)
    for old in log_dir.glob(
        "*_DEBUG.log"
    ):  # DEBUG logs contain order data -> keep them only a few days
        if time.time() - old.stat().st_mtime > OTHERS.debug_log_days * 86400:
            old.unlink(missing_ok=True)
    name = f"{OTHERS.vScenarioID}_{datetime.now():%Y%m%d}_{order_id}"
    formatter = _SecretFormatter(
        "%(asctime)s.%(msecs)03d | %(levelname)-7s | order=%(order)s file=%(file_idx)s | "
        "%(module)s.%(funcName)s:%(lineno)d | %(message)s", "%Y-%m-%d %H:%M:%S",)
    root = logging.getLogger()
    root.setLevel(logging.DEBUG)
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(errors='replace')  # umlauts (Stück) must not break the console
    handlers = []
    for handler, level in ((logging.FileHandler(log_dir / f"{name}.log", encoding="utf-8"), logging.INFO), (
            logging.FileHandler(log_dir / f"{name}_DEBUG.log", encoding="utf-8"), logging.DEBUG,),
        (logging.StreamHandler(sys.stdout), logging.INFO),):
        handler.setLevel(level)
        handler.setFormatter(formatter)
        handlers.append(handler)
    status_path = configure_logging(handlers, _ContextFilter(), SECRETS, log_dir, name,
        monitor_window=bool(OTHERS.get("monitor_window", False)),)
    if status_path:
        logging.info('Progress status: %s', status_path)
    for noisy in ("urllib3", "selenium", "comtypes", "pywinauto", "PIL"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
    _CRASH_FILE = open(log_dir / 'crash_trace.log', 'a', encoding='utf-8')
    faulthandler.enable(_CRASH_FILE)  # a trace is written even when a COM call crashes Python itself
    sys.excepthook = lambda kind, error, trace: logging.critical(
        "Unexpected error", exc_info=(kind, error, trace))
    logging.info(f"Log started: {log_dir / name}.log")
    return log_dir / f"{name}.log"

def step(func=None, *, portal=False):
    """Time each step, including failures, without changing its return/exception."""
    if func is None:
        return functools.partial(step, portal=portal)

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        started = time.perf_counter()
        stack = getattr(_STEP_CONTEXT, 'stack', ())
        parent = stack[-1] if stack else ''
        _STEP_CONTEXT.stack = (*stack, func.__qualname__)
        outcome = 'raised'
        emit_event('step_started', step=func.__qualname__, active_step=func.__qualname__, parent=parent)
        logging.debug('START %s', func.__qualname__)
        try:
            result = func(*args, **kwargs)
            outcome = 'returned'
            return result
        except Exception as ex:
            logging.error("FAILED %s after %.1fs: %s: %s", func.__qualname__, time.perf_counter() - started,
                type(ex).__name__, ex, exc_info=True,)
            raise
        finally:
            seconds = time.perf_counter() - started
            TIMINGS.append((func.__qualname__, seconds))
            emit_event("step_finished", step=func.__qualname__, active_step=parent, parent=parent,
                seconds=seconds, outcome=outcome,)
            _STEP_CONTEXT.stack = stack
            logging.debug('END %s (%.1fs; %s)', func.__qualname__, seconds, outcome)

    return wrapper

def notify_status(kind, message):
    """Used by sap_logon.py (e.g. 'the other SAP logon of the user was terminated'): local warning + end summary."""
    logging.warning(f"[{kind}] {message}")
    NOTICES.append(f"{kind}: {message}")
    emit_event("notification", message=f"{kind}: {message}")

def log_timings():
    """End of run: table of the slowest steps (to compare with the A360 run time) and the collected notices."""
    totals = {}
    for name, seconds in TIMINGS:
        totals[name] = totals.get(name, 0) + seconds
    for name, seconds in sorted(totals.items(), key=lambda item: -item[1])[:25]:
        logging.info(f"TIMING {seconds:8.1f}s  {name}")
    for notice in NOTICES:
        logging.warning(f"NOTICE {notice}")

# RPA portal logs (HQ scripts python_Start_log.py / python_Detail_log.py / python_End_log.py, unchanged)
PORTAL_ARGS = (OTHERS.vCompanyName, OTHERS.vBusinessName, OTHERS.vScenarioID, OTHERS.vRPAName)

def portal_start():
    """Main Task step 3 + steps 5-6: send the portal START log and read logHeaderId (vInfldxForPortal) and the
    device from LogStartConfig.txt. Must be the first portal call. Raises BotError when it fails (the run stops).
    """
    if RUN.dry_run:
        logging.info('[portal] DRY RUN - no portal logs are sent')
        return
    for name in ("COMPUTERNAME", "USERDNSDOMAIN"):  # CommonModule.py:94 needs both
        if not os.environ.get(name):
            raise BotError(f"Windows variable {name} is missing - the portal start log cannot be sent")
    import python_Start_log
    from CommonModule import CommonModule

    started = datetime.now().strftime('%Y%m%d%H%M%S')

    def header_of_this_run():
        """LogStartConfig.txt values when THIS run wrote them (CommonModule writes the file just before the header)."""
        try:
            header = CommonModule(OTHERS.vCompanyName, OTHERS.vBusinessName, OTHERS.vRPAName,
                "Run from Control Room(Run bot)", False, "BW",)
            mine = header.infIdx.startswith(os.environ['COMPUTERNAME'] + '-') and header.startTime >= started
            return header if mine else None
        except Exception:
            return None

    for attempt in (1, 2):
        try:
            python_Start_log.send_start_log(*PORTAL_ARGS)
            break
        except Exception as ex:
            header = header_of_this_run()
            if (
                header
            ):  # the portal header of this run exists: never send a 2nd one, let the END log close it
                RUN.inf_idx, RUN.device, RUN.portal_started = (header.infIdx, header.device, True)
                raise
            if attempt == 2 or not isinstance(
                ex, OSError
            ):  # 2nd try only for a locked folder during the clean-up
                raise
            logging.warning(f"[portal] start log failed while cleaning folders ({ex}) - retry in 5 s")
            time.sleep(5)
    header = header_of_this_run()
    if header is None:
        raise BotError('LogStartConfig.txt has no valid vInfldxForPortal of this run')
    RUN.inf_idx, RUN.device, RUN.portal_started = (header.infIdx, header.device, True)
    logging.info(f"[portal] start log sent - logHeaderId={RUN.inf_idx} device={RUN.device}")

def portal_log(text, error=False):
    """Send one portal detail log with the exact A360 text. Never stops the bot.
    error=True sends an 'E' log; CommonModule then also saves a desktop screenshot in the ScreenShot folder.
    """
    (logging.error if error else logging.info)(f"[portal] {text}")
    if not RUN.portal_started or RUN.portal_ended:
        return
    try:
        import python_Detail_log

        python_Detail_log.send_detail_log(
            *PORTAL_ARGS, "E" if error else "I", str(text), str(FOLDERS.SCREENSHOTS))
    except KeyboardInterrupt:
        raise
    except (
        BaseException
    ) as ex:  # CommonModule may even call sys.exit() - never let that stop the bot
        logging.warning(f"[portal] detail log not sent: {ex}")

def portal_end(run_ok):
    """Main Task Finally step 7: send the portal END log. Returns False only when the END log could not be sent.
    Careful: python_End_log marks the run FAILED when it gets the text 'True' (opposite of A360 vErrorHandlingFlag).
    """
    sent = True
    if RUN.portal_started and not RUN.portal_ended:
        try:
            import python_End_log

            python_End_log.send_end_log(*PORTAL_ARGS, 'False' if run_ok else 'True')
            logging.info(f"[portal] end log sent - {'Completed' if run_ok else 'Failed'}")
        except KeyboardInterrupt:
            raise
        except BaseException as ex:
            logging.critical(f"[portal] END log not sent: {ex}")
            sent = False
    RUN.portal_ended = True
    return sent

# E-mail (SMTP relay)
def send_mail(subject, body_html, to=None, attachments=(), sender=None, debug=False):
    """Send an e-mail through the SMTP relay (replaces the A360 'Send email' actions). Never stops the bot.
    debug=True marks the A360 developer info mails: they are only sent when config 'debug_mails' is true.
    """
    receivers = [address.strip() for address in re.split("[;,]", to or OTHERS.vSendMailReceivers)
        if address.strip()]
    reason = ("debug_mails is false" if debug and not OTHERS.debug_mails else ("dry run" if RUN.dry_run
            else "smtp_host is empty in config.json" if not OTHERS.smtp_host else ""))
    if reason:
        logging.info(
            f"[mail] NOT sent ({reason}): '{subject}' to {receivers} | {re.sub(r'<[^>]+>', ' ', body_html)}")
        return False
    try:
        message = EmailMessage()
        message["Subject"], message["From"], message["To"] = (subject, sender or OTHERS.vSendMailSender,
            ", ".join(receivers),)
        message.set_content(re.sub('<[^>]+>', ' ', body_html))
        message.add_alternative(body_html, subtype='html')
        for path in attachments:
            if path and Path(path).is_file():
                message.add_attachment(Path(path).read_bytes(), maintype="application",
                    subtype="octet-stream", filename=Path(path).name,)
        with smtplib.SMTP(OTHERS.smtp_host, OTHERS.smtp_port, timeout=OTHERS.smtp_timeout) as smtp:
            if OTHERS.smtp_starttls:
                smtp.starttls()
            if OTHERS.smtp_use_login:
                smtp.login(RUN.creds.get('mail_id', ''), RUN.creds.get('mail_pw', ''))
            smtp.send_message(message)
        logging.info(f"[mail] sent '{subject}' to {receivers}")
        return True
    except Exception as ex:
        logging.warning(f"[mail] could not send '{subject}': {ex}")
        return False

def send_error_mail(task_name, error, attachment=None):
    """The A360 error mail 'RPA finished executing the TaskBot' (steps.txt:986-991, 1064-1069 and the task Catches)."""
    trace = traceback.extract_tb(error.__traceback__) if error.__traceback__ else []
    body = (f"\<P>Message from RPA Bot.\</P>\<P> \</P>\<P>Task Name : {task_name}\</P>"
        f"\<P>Error occurred on: {datetime.now():%Y-%m-%d %H:%M:%S}\</P>"
        f"\<P>Error line number: {trace[-1].lineno if trace else ''}\</P>\<P>Error message: {error}\</P>")
    return send_mail("RPA finished executing the TaskBot", body,
        attachments=[attachment] if attachment else (),)

# Processes and screenshots
def kill_processes(names):
    """Main Task step 1 / Finally step 6: close the programs of 'vTaskList' (browser, SAP, Excel, Outlook) and wait
    until they are really gone, so that no file stays locked."""
    wanted = {name.strip().lower() for name in re.split('[,;]', names) if name.strip()}
    found = [p for p in psutil.process_iter(['name']) if (p.info['name'] or '').lower() in wanted]
    for process in found:
        try:
            process.kill()
        except psutil.Error:
            pass
    psutil.wait_procs(found, timeout=10)
    logging.info(f"Closed {len(found)} process(es) of: {', '.join(sorted(wanted))}")

def wait_for_process(name, timeout):
    """Main Task step 18: wait (max 'timeout' seconds) until a program, e.g. the Knox SSO agent EpTray.exe, runs."""
    started = time.monotonic()
    while time.monotonic() - started <= timeout:
        if any((p.info["name"] or "").lower() == name.lower() for p in psutil.process_iter(["name"])):
            logging.info(f"{name} is running (waited {time.monotonic() - started:.1f}s)")
            return True
        time.sleep(0.5)
    logging.warning(f"{name} is not running after {timeout}s")
    return False

def screenshot(path):
    """Save a picture of the whole screen (A360 'Capture screenshot'). Never stops the bot. Returns the path."""
    try:
        from PIL import ImageGrab

        Path(path).parent.mkdir(parents=True, exist_ok=True)
        ImageGrab.grab().save(str(path))
        logging.info(f"Screenshot saved: {path}")
    except Exception as ex:
        logging.warning(f"Screenshot failed ({path}): {ex}")
    return str(path)

# Excel - one session for the whole run
class ExcelSession:
    """ONE Excel program for the whole run (A360 opened and closed Excel many times per file).
    The order files and templates are NASCA DRM protected, so they are only ever opened through Excel itself.
    """

    def __init__(self):
        self.app = None

    @step
    def start(self):
        """Start Excel once: no alerts, no macros, no events."""
        if self.app is None:
            pythoncom.CoInitialize()
            self.app = win32com.client.DispatchEx('Excel.Application')
            self.app.Visible = bool(OTHERS.excel_visible)  # visible, so a NASCA DRM prompt could be seen
            self.app.DisplayAlerts = False
            self.app.AskToUpdateLinks = False
            self.app.EnableEvents = False
            self.app.AutomationSecurity = 3  # never run macros of the opened files
            logging.info('Excel started')
        return self.app

    @step
    def open(self, path, read_only=False):
        """Open a workbook. When Excel fails, restart only OUR Excel and try again (max 3 times).
        A360: Task 02 step 9 'Loop 3 times: open Order File.xlsx, on error kill excel.exe and open again'.
        """
        for attempt in (1, 2, 3):
            emit_event('excel_open_attempt', path=str(path), attempt=attempt, total=3)
            try:
                workbook = self.start().Workbooks.Open(str(path), 0, read_only)
                logging.debug(f"Excel opened {path}")
                return workbook
            except Exception as ex:
                logging.warning(f"Excel could not open {path} (attempt {attempt}/3): {ex}")
                self.quit(force=True)
        raise BotError(f"Excel could not open {path}")

    @staticmethod
    @step
    def read(sheet):
        """Read a whole sheet (A1 to the last used cell) in ONE call. Result: list of rows, rows[0][0] = cell A1.
        Date cells come back as datetime, error cells (#N/A) as numbers such as -2146826246 (see vba_cstr).
        """
        values = sheet.Range('A1', sheet.Cells.SpecialCells(11)).Value  # 11 = xlCellTypeLastCell
        return [list(row) for row in values] if isinstance(values, tuple) else [[values]]

    @step
    def quit(self, force=False):
        """Close Excel. force=True kills our own Excel process (never the Excel of somebody else)."""
        if self.app is None:
            return
        try:
            pid = win32process.GetWindowThreadProcessId(self.app.Hwnd)[1]
        except Exception:
            pid = None
        try:
            if not force:
                while self.app.Workbooks.Count:
                    self.app.Workbooks(1).Close(False)
                self.app.Quit()
        except Exception as ex:
            logging.warning(f"Excel did not close normally: {ex}")
            force = True
        self.app = None
        if force and pid:
            try:
                psutil.Process(pid).kill()
            except psutil.Error:  # already gone
                pass
        logging.info('Excel closed' + (' (killed)' if force else ''))

# VBA helpers - make the converted Macro.xlsm code behave exactly like VBA
@functools.lru_cache(maxsize=128)
def _column_number(letters):
    number = 0
    for letter in letters:
        number = number * 26 + ord(letter) - 64
    return number

_CELL_REFERENCE = re.compile('([A-Za-z]+)([0-9]+)')

@functools.lru_cache(maxsize=2048)
def _cell_coordinates(reference):
    letters, number = _CELL_REFERENCE.fullmatch(reference).groups()
    return (int(number) - 1, col_number(letters) - 1)

def col_number(letters):
    """Excel column letters -> number, cached independently of workbook data."""
    return _column_number(letters.upper())

def cell(rows, ref, previous="", raw=False):
    """Text of a cell such as 'A9' from a sheet read with ExcelSession.read(), converted like VBA CStr().
    'previous' is returned for an Excel error cell (VBA 'On Error Resume Next' keeps the old value).
    raw=True returns the value as Excel gave it (number, date, text or None)."""
    row, col = _cell_coordinates(ref.strip())
    value = rows[row][col] if row < len(rows) and col < len(rows[row]) else None
    return value if raw else vba_cstr(value, previous)

def vba_cstr(value, previous=""):
    """VBA CStr(): the text VBA gets when it stores a cell value in a String variable (all macros do this)."""
    if value is None:
        return ''
    if isinstance(value, bool):
        return 'True' if value else 'False'
    if isinstance(
        value, int
    ):  # Excel error cell (#N/A, #VALUE! ...) -> keep the previous value
        return previous
    if isinstance(
        value, datetime
    ):  # date cell -> Windows short date (+ time when there is one)
        text = value.strftime(OTHERS.short_date_format)
        return (text if value.time() == datetime.min.time() else f"{text} {value:%H:%M:%S}")
    if isinstance(value, (float, Decimal)):
        value = float(value)
        text = (str(int(value)) if value.is_integer() and abs(value) < 1e15
            else format(value, ".15g").upper())
        return text.replace('.', OTHERS.decimal_separator)
    return str(value)

_MONTHS = {"jan": 1, "feb": 2, "mar": 3, "mär": 3, "apr": 4, "may": 5, "mai": 5, "jun": 6, "jul": 7,
    "aug": 8, "sep": 9, "oct": 10, "okt": 10, "nov": 11, "dec": 12, "dez": 12,}

def vba_cdate(text):
    """VBA IsDate()/CDate() for the date texts of the order files. Returns a date, or None when it is no date.
    Day/month order of numeric dates comes from config 'date_order' (DMY = German 05.01.2026 = 5 January 2026).
    A360-FIX[B28] Task 01 step 5 -> macro funReqDelivDateFormat_String (Macro.txt:2075-2081)
      Bug: VBA IsDate/Format depend on the Windows regional settings of the VDI, so the same file gave different
           delivery dates on VDIs with different settings. Fix: the order is fixed in config.json.
    A360-FIX[task01-1] Task 01 step 5 -> macro funReqDelivDateFormat_String (Macro.txt:2075-2081)
      Bug: VBA IsDate accepts month-name dates ('05-Jan-2026', '5. Januar 2026') but the digit-only check rejected
           them, so brown/WG adhoc stopped with 'Incorrect date format'. Fix: map German/English month names first.
    """
    text = re.sub('\\s+\\d{1,2}:\\d{2}(:\\d{2})?(\\s\\*[AP]M)?$', '', str(text or '').strip(), flags=re.I)  # time part
    parts = [part for part in re.split('[./**\\\\-** ]+', text) if part]
    month_word = next((p for p in parts if p[:3].lower() in _MONTHS), None)  # month-name date (VBA IsDate accepts it)
    if month_word:
        month = _MONTHS[month_word[:3].lower()]
        nums = [int(p) for p in parts if p.isdigit()]
        if not nums:
            return None
        if len(nums) == 2:  # day + year  ('05-Jan-2026', '5. Januar 2026')
            day, year = (nums[0], nums[1]) if nums[0] <= 31 else (nums[1], nums[0])
        elif nums[0] > 31:  # year only   ('Januar 2026' -> 1st of the month)
            day, year = (1, nums[0])
        else:  # day only    ('05-Jan' -> current year)
            day, year = (nums[0], date.today().year)
        if year < 100:
            year += 2000 if year < 30 else 1900
        try:
            return date(year, month, day)
        except ValueError:
            return None
    if not 2 <= len(parts) <= 3 or not all(part.isdigit() and len(part) <= 4 for part in parts):
        return None
    if len(parts[0]) == 4:  # 2026.01.05 / 2026-01-05 (year first)
        year, month, day = (int(part) for part in (parts + ['1'])[:3])
    elif len(parts) == 2 and len(parts[1]) == 4:  # 01/2026 -> first day of the month
        year, month, day = (int(parts[1]), int(parts[0]), 1)
    else:  # 05.01.2026 / 05.01. (current year)
        first, second = (int(parts[0]), int(parts[1]))
        year = int(parts[2]) if len(parts) == 3 else date.today().year
        day, month = (second, first) if OTHERS.date_order == 'MDY' else (first, second)
    if year < 100:
        year += 2000 if year < 30 else 1900
    for day_try, month_try in (
        (day, month),
        (month, day),
    ):  # like VBA: swap day/month if the first try is impossible
        try:
            return date(year, month_try, day_try)
        except ValueError:
            pass
    return None

def fmt_rdd(rdd):
    """Macro funReqDelivDateFormat_String (Macro.txt:2071-2087): delivery date text -> 'yyyy.mm.dd'.
    Returns (text, error_flag). A text that is no date (also 'sofort' / 'asap') comes back unchanged with
    error_flag=True (= Macro.xlsm Temp!O2 'Error Flag', see A360-KEPT[K01] in task01_standardize.py).
    """
    parsed = vba_cdate(rdd)
    return (parsed.strftime('%Y.%m.%d'), False) if parsed else (rdd, True)

def vba_like(text, pattern):
    """VBA 'Like' (case-sensitive): \* = any text, ? = one character, # = one digit."""
    regex = "".join((".\*" if c == "\*" else "." if c == "?" else "[0-9]" if c == "#" else re.escape(c))
        for c in pattern)
    return re.fullmatch(regex, str(text or ''), re.S) is not None

def to_currency(value, sap=False):
    """VBA CCur(): number or text -> Decimal with 4 decimals (banker's rounding). Raises ValueError for 'no number'.
    sap=True: text uses the SAP user's decimal notation (config 'sap_decimal_notation'); a trailing '-' = negative.
    """
    if isinstance(value, (int, float, Decimal)) and not isinstance(value, bool):
        number = Decimal(str(value))
    else:
        text = str(value).strip().replace(' ', '')
        negative, text = (text.endswith('-'), text.rstrip('-'))
        comma_decimal = (OTHERS.sap_decimal_notation.startswith("1.") if sap
            else OTHERS.decimal_separator == ",")
        text = text.replace('.', '').replace(',', '.') if comma_decimal else text.replace(',', '')
        if not re.fullmatch(r"-?[0-9]+(**\\.**[0-9]+)?", text):
            raise ValueError(f"'{value}' is not a number")
        number = -Decimal(text) if negative else Decimal(text)
    return number.quantize(Decimal('0.0001'), ROUND_HALF_EVEN)

def network_days(start, end):
    """Excel NETWORKDAYS(start, end): working days Mon-Fri, negative when start > end.
    The macro also passed its 'Holidays' sheet; the business confirmed no holiday list is used, so public
    holidays on weekdays count as working days."""
    low, high = (min(start, end), max(start, end))
    days = (low + timedelta(n) for n in range((high - low).days + 1))
    count = sum((1 for day in days if day.weekday() < 5))
    return -count if start > end else count

def german_now():
    """Macro funDateTime / Macro.xlsm Temp!J14 'Corporation Time': the current time in Germany.
    A360-FIX[B08] SalesCreate step 6 -> subOptionSetting -> subReqDelivDate (Macro.txt:1887,1907; Temp!H14,J14)
      Bug: German time was 'VDI time - 7 h (summer) / 8 h (winter)': right only on a KST VDI and wrong for some
           hours around the summer-time switch. Fix: the real Europe/Berlin time zone.
    """
    from zoneinfo import ZoneInfo

    return datetime.now(ZoneInfo('Europe/Berlin'))
