"""SAP GUI logon / logoff handling.
The bot logs on to SAP exactly once at the beginning of the run and calls
\:meth:\`SAPLogin.close\` after the last SAP related step.
"""

import logging
import subprocess
import time
from pathlib import Path
import pythoncom
import win32com.client
from config import OTHERS
from exceptions import LoginFailedException
from rpa_core import notify_status, step

SAP_PROCESSES = ('saplogon.exe', 'saplgpad.exe', 'sapgui.exe')
# Status bar keywords that indicate a credential problem - retrying those would
# only lock the SAP user, so they are treated as non retryable.
CREDENTIAL_KEYWORDS = ("password", "incorrect", "invalid", "expired", "locked", "logon", "authentication",
    "user name", "name or password", "userid", "user id",)

class RetryableSAPException(Exception):
    """Technical problem - a fresh logon attempt may succeed."""

class NonRetryableSAPException(Exception):
    """Credential / account problem - retrying must be avoided."""

class SAPLogin:
    MAX_RETRIES = 3
    APPLICATION_TIMEOUT = 60
    SESSION_TIMEOUT = 60
    LOGIN_SCREEN_TIMEOUT = 60
    IDLE_TIMEOUT = 60
    RETRY_WAIT = 5

    def __init__(self, saplogon_path=OTHERS.saplogon_path):
        self.saplogon_path = saplogon_path
        self.session = None

    # Process / application handling
    @staticmethod
    def _poll(timeout, probe, error, interval=1):
        """Call \`\`probe\`\` until it returns something truthy or \`\`timeout\`\` expires."""
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            try:
                result = probe()
                if result:
                    return result
            except Exception:
                pass
            time.sleep(interval)
        raise RetryableSAPException(error)

    @step(portal=False)
    def kill_sap_processes(self):
        """Force close every SAP GUI process."""
        for process in SAP_PROCESSES:
            subprocess.run(["taskkill", "/F", "/IM", process], check=False, stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,)
        time.sleep(3)

    @step(portal=False)
    def _launch_sap(self):
        """Start SAP Logon, falling back to the 32-bit installation path."""
        if not Path(self.saplogon_path).exists():
            self.saplogon_path = 'C:**\\P**rogram Files (x86)\\SAP**\\F**rontEnd\\SapGui\\saplogon.exe'
        logging.info(f"SAP logon path: {self.saplogon_path}")
        subprocess.Popen(self.saplogon_path)

    @staticmethod
    def _connect_scripting_engine():
        """Return the SAP scripting engine of a running SAP GUI, or None."""
        try:
            pythoncom.CoInitialize()
            return win32com.client.GetObject('SAPGUI').GetScriptingEngine
        except Exception:
            return None

    @step(portal=False)
    def _get_application(self):
        """Return the SAP scripting engine, launching SAP Logon if required."""
        application = self._connect_scripting_engine()
        if application:
            logging.info('Using the already running SAP GUI.')
            return application
        self._launch_sap()
        application = self._poll(self.APPLICATION_TIMEOUT, self._connect_scripting_engine,
            "SAP GUI scripting engine not available.",)
        logging.info('SAP GUI scripting engine is available.')
        return application

    @step(portal=False)
    def _open_connection(self, application, connection_name):
        """Open the named SAP connection."""
        try:
            return application.OpenConnection(connection_name, False)
        except Exception as ex:
            raise RetryableSAPException(f"Unable to open SAP connection '{connection_name}': {ex}")

    @step(portal=False)
    def _wait_for_session(self, connection):
        """Wait until the connection exposes a session object."""
        return self._poll(self.SESSION_TIMEOUT,
            lambda: connection.Children(0) if connection.Children.Count else None,
            "SAP session was not created.",)

    @step(portal=False)
    def _wait_for_login_screen(self, session):
        """Wait until the SAP logon screen accepts credentials."""
        self._poll(self.LOGIN_SCREEN_TIMEOUT, lambda: session.findById("wnd[0]/usr/txtRSYST-BNAME"),
            "SAP login screen not found.",)

    def _wait_until_idle(self, session):
        """Block while the SAP session is busy (best effort, never raises)."""
        deadline = time.monotonic() + self.IDLE_TIMEOUT
        while time.monotonic() < deadline:
            try:
                if not session.Busy:
                    return
            except Exception:
                pass
            time.sleep(0.5)
        logging.warning('Timeout while waiting for the SAP session to become idle.')

    # Login flow
    @step(portal=False)
    def _check_login_status(self, session):
        """Raise when the SAP status bar reports a logon error."""
        try:
            status = session.findById('wnd[0]/sbar')
        except Exception:
            return
        if status.MessageType != "E":
            return
        message = status.Text.strip()
        logging.error(f"SAP error: {message}")
        if any(keyword in message.lower() for keyword in CREDENTIAL_KEYWORDS):
            raise NonRetryableSAPException(message)
        raise RetryableSAPException(message)

    @step(portal=False)
    def _handle_popups(self, session, username):
        """Acknowledge the popups shown right after the logon."""
        while True:
            try:
                if session.Children.Count <= 1:
                    return
                popup = session.findById('wnd[1]')
            except Exception:
                return
            logging.info(f"SAP popup detected: {popup.Text}")
            handled = self._handle_multi_logon(popup, username)
            for control in ("usr/btnSPOP-OPTION1", "tbar[0]/btn[0]"):
                if handled:
                    break
                try:
                    popup.findById(control).press()
                    handled = True
                except Exception:
                    pass
            if not handled:
                logging.warning(f"Unknown SAP popup: {popup.Text}")
                try:
                    popup.sendVKey(0)
                except Exception:
                    raise RetryableSAPException(f"Unknown SAP popup: {popup.Text}")
            self._wait_until_idle(session)

    @staticmethod
    def _handle_multi_logon(popup, username):
        """End the other session of the user when SAP shows the multi logon popup."""
        try:
            popup.findById('usr/radMULTI_LOGON_OPT3')
            logging.info('Multiple logon popup detected - terminating the other session.')
            popup.findById('usr/radMULTI_LOGON_OPT1').select()
            popup.findById('tbar[0]/btn[0]').press()
            notify_status("RPA", f"The SAP logon of user {username} on another system was terminated "
                "because the user was already logged on and the RPA bot needs the session.",)
            return True
        except Exception:
            return False

    @step
    def login(self, connection_name, username, password, language="EN"):
        """Log on to SAP and return the session. Raises \`\`LoginFailedException\`\`."""
        logging.info(f"SAP login started for user: {username}")
        for attempt in range(1, self.MAX_RETRIES + 1):
            credentials_submitted = False
            try:
                logging.info(f"===== SAP login attempt {attempt}/{self.MAX_RETRIES} =====")
                if attempt > 1:
                    self.kill_sap_processes()
                application = self._get_application()
                connection = self._open_connection(application, connection_name)
                session = self._wait_for_session(connection)
                self._wait_for_login_screen(session)
                logging.info('Entering SAP credentials.')
                session.findById('wnd[0]/usr/txtRSYST-BNAME').text = username
                session.findById('wnd[0]/usr/pwdRSYST-BCODE').text = password
                session.findById('wnd[0]/usr/txtRSYST-LANGU').text = language
                credentials_submitted = True
                session.findById('wnd[0]').sendVKey(0)
                self._wait_until_idle(session)
                self._check_login_status(session)
                self._handle_popups(session, username)
                try:
                    session.findById('wnd[0]/tbar[0]')
                except Exception:
                    raise RetryableSAPException('SAP main window not available after login.')
                logging.info(f"SAP login successful for {username}.")
                self.session = session
                return session
            except NonRetryableSAPException as ex:
                raise LoginFailedException(f"SAP credential error: {ex}")
            except Exception as ex:
                if credentials_submitted:
                    raise LoginFailedException(f"SAP login failed after the credentials were submitted "
                        f"(retry skipped to avoid a user lock): {ex}")
                if attempt == self.MAX_RETRIES:
                    raise LoginFailedException(f"SAP login failed after {self.MAX_RETRIES} attempts: {ex}")
                logging.warning(f"SAP login attempt {attempt} failed ({ex}). "
                    f"Retrying in {self.RETRY_WAIT}s.")
                time.sleep(self.RETRY_WAIT)
        raise LoginFailedException('SAP login failed after the maximum number of retries.')

    # Logoff
    @step
    def close(self, session=None):
        """Close the SAP session and every SAP process. Never raises."""
        session = session or self.session
        try:
            if session is not None:
                connection = session.Parent
                for _ in range(2):
                    self._press(session, 'wnd[0]/tbar[0]/btn[3]')
                while connection.Children.Count > 0:
                    child = connection.Children(0)
                    self._press(child, 'wnd[1]/usr/btnSPOP-OPTION1')
                    try:
                        child.findById('wnd[0]').close()
                    except Exception:
                        break
        except Exception as ex:
            logging.warning(f"Unable to close the SAP session gracefully: {ex}")
        finally:
            self.session = None
            self.kill_sap_processes()
            logging.info('SAP closed.')

    @staticmethod
    def _press(session, element_id):
        """Press a SAP control if it exists, ignoring anything that goes wrong."""
        try:
            session.findById(element_id).press()
            time.sleep(0.5)
            return True
        except Exception:
            return False
