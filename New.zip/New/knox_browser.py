"""Headless Chrome sessions owned by the Knox startup/cleanup steps."""

import logging
import shutil
import tempfile
from pathlib import Path

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service

from config import Config, FOLDERS, OTHERS

def create_knox_webdriver():
    """Use the configured driver and preferences with a separate temporary profile."""
    Path(FOLDERS.TEMP).mkdir(parents=True, exist_ok=True)
    profile = tempfile.mkdtemp(prefix='knox-chrome-', dir=FOLDERS.TEMP)
    try:
        options = Options()
        options.add_argument('--headless=new')
        options.add_argument('--window-size=1920,1080')
        options.add_argument(f"--user-data-dir={profile}")
        options.add_experimental_option('prefs', dict(Config.BROWSER_OPTIONS))
        if OTHERS.get("chrome_binary_path"):
            options.binary_location = OTHERS.chrome_binary_path
        driver = webdriver.Chrome(service=Service(executable_path=Config.chrome_driver_path), options=options)
        # Capabilities usually include this path; keep our own copy for failures.
        driver.knox_profile = profile
        return driver
    except BaseException:
        shutil.rmtree(profile, ignore_errors=True)
        raise

def quit_knox_webdriver(driver, *, log_closed=False):
    """Close a driver and its temporary profile, even if Chrome already exited."""
    if driver is None:
        return
    profile = None
    try:
        profile = getattr(driver, "knox_profile", None) or (
            (driver.capabilities or {}).get("chrome", {}).get("userDataDir"))
    except Exception:
        pass
    try:
        driver.quit()
    except Exception:
        if log_closed:
            logging.info('Web driver already closed.')
    if profile:
        shutil.rmtree(profile, ignore_errors=True)
