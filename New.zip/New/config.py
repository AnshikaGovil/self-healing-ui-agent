"""Configuration loader for the R1904002-001 Order Creation bot.
All environment specific values live in \`\`config.json\`\` next to this module;
nothing here may be hard coded per VDI / per environment.
A360: 'Order Creation Main Task' step 1 "Read config" (the A360 file was 'R1904002-001_Order Creation.txt').
"""

import json
import os
import shutil
from datetime import datetime
from pathlib import Path

CONFIG_FILE = Path(__file__).resolve().parent / 'config.json'
# Keys grouped into the three public maps exposed by this module.
_FOLDER_KEYS = ('INPUT', 'OUTPUT', 'TEMP', 'TEMPLATE', 'SCREENSHOTS', 'LOGS')
_FILE_KEYS = ()  # PY-CHANGE: the ClaimDoc keys (password_filepath, approvalpath_filepath) were removed
RUN_DATE = datetime.now()

class Map(dict):
    """Dictionary that also supports attribute access (\`\`cfg.projectName\`\`)."""

    def __getattr__(self, key):
        try:
            return self[key]
        except KeyError as ex:
            raise AttributeError(key) from ex

    def __setattr__(self, key, value):
        self[key] = value

def parse_config_file(file_path=CONFIG_FILE):
    """Read and return the raw JSON configuration as a dict."""
    with open(file_path, "r", encoding="utf-8") as file:
        return json.load(file)

def create_maps_from_config(config):
    """Split the raw config into the FOLDERS / FILES / OTHERS maps."""
    return (Map({k: v for k, v in config.items() if k in _FOLDER_KEYS}),
        Map({k: v for k, v in config.items() if k in _FILE_KEYS}),
        Map({k: v for k, v in config.items() if k not in _FOLDER_KEYS + _FILE_KEYS}),)

configParsed = parse_config_file()
FOLDERS, FILES, OTHERS = create_maps_from_config(configParsed)

def ensure_folders(*extra):
    """Clean and recreate the working folders, preserving the LOGS directory.
    A360: Main Task step 1 "initialize directories"."""
    for folder in set(list(FOLDERS.values()) + list(extra)):
        if folder != FOLDERS.get("LOGS"):
            shutil.rmtree(folder, ignore_errors=True)
        os.makedirs(folder, exist_ok=True)

class Config:
    """Static, non environment specific settings."""

    # PY-CHANGE: the driver path now comes from config.json (old hard coded value kept as default)
    chrome_driver_path = OTHERS.get('chrome_driver_path', 'C:\\Drivers\\chromedriver-win64\\chromedriver.exe')
    TIMEOUT = 10
    BROWSER_OPTIONS = {"download.default_directory": FOLDERS.TEMP, "download.prompt_for_download": False,
        "download.directory_upgrade": True, "safebrowsing.enabled": True,
        "safebrowsing.disable_download_protection": True, "useAutomationExtension": False,}
