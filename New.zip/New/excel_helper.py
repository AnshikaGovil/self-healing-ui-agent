"""Shared Excel/COM plumbing used by the Excel and Claims Upload steps."""

import logging
import time
from contextlib import contextmanager

import win32com.client

# Excel enumeration values (avoids magic numbers in the business code).
XL_UP = -4162
XL_PASTE_VALUES = -4163
XL_PASTE_FORMULAS = -4123
XL_CELL_TYPE_VISIBLE = 12

@contextmanager
def excel_app(visible=True):
    """Start a dedicated Excel instance and always close it again."""
    excel = win32com.client.DispatchEx('Excel.Application')
    excel.Visible = visible
    excel.DisplayAlerts = False
    excel.AskToUpdateLinks = False
    excel.EnableEvents = False
    try:
        yield excel
    finally:
        while True:
            try:
                if excel.Workbooks.Count == 0:
                    break
                excel.Workbooks(1).Close(SaveChanges=False)
            except Exception as ex:
                logging.warning(f"Unable to close all workbooks: {ex}")
                break
        try:
            excel.Quit()
        except Exception as ex:
            logging.warning(f"Unable to quit Excel: {ex}")
        time.sleep(2)

@contextmanager
def open_workbook(path, save=True, visible=True):
    """Open a workbook, save it when the block completes without error, and
    always close Excel afterwards."""
    with excel_app(visible) as excel:
        workbook = excel.Workbooks.Open(str(path))
        logging.info(f"Workbook opened: {path}")
        yield (excel, workbook)
        if save:
            workbook.Save()
            logging.info(f"Workbook saved: {path}")