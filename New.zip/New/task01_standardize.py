"""Order Creation Task 01 - standardize the customer order Excel files.

A360: 'Order Creation Task 01' (Order Creation A360 steps.txt:231-337) and the Macro.xlsm macros it ran:
SEG_Type, SEG_Brown_Adhoc, SEG_Brown_Dispo, SEG_White_Adhoc, SEG_White_Dispo, SEG_IM_adhoc, SEG_Shop_Order,
SEG_WG_Adhoc, SEG_WG_Dispo, funMapping, funItemValidation, CreateLogFile/WriteLog (Macro.txt:37-1288, 1954-1982).
Macro.xlsm itself is no longer opened - the macros are converted to Python below.

Every customer file becomes one or more 'Standard Order Sheet' files (one per sales order) in the Template
folder, named '<delivery date or number>_<original file name>' exactly like the A360 renames did.

Run on its own (uses the files already in the Input folder; without --live nothing is sent to the portal):
    python task01_standardize.py <ORDER_ID> <fileId>=<file name> [<fileId>=<file name> ...] [--live]
"""

import json
import logging
import os
import shutil
import sys
from pathlib import Path

import portal_api
from runtime_support import (RunStopped, cleanup_mode, finish_run, shutdown, business_event, business_batch,
    business_operation, emit_event, message_card, message_card_error, template_path,)
from business_progress import file_standardization_outcome
from config import FOLDERS, OTHERS
from exceptions import StandardizationError
from rpa_core import (LOG_CONTEXT, RUN, ExcelSession, StdOrder, cell, col_number, fmt_rdd, portal_end,
    portal_log, portal_start, screenshot, send_error_mail, send_mail, setup_logging, step, vba_like,)

MAP = OTHERS.TemplateMapping  # Macro.xlsm sheet 'mapSht' (funMapping)
STANDARD_TEMPLATE = template_path(__file__, 'Standard Order Sheet.xlsx')
LAST_COLUMN = col_number('CS')  # CS2 holds the number of items
BAD_NAME_CHARACTERS = set('\\/:*?"<>|')

def detect_type(grid):
    """Macro SEG_Type (Macro.txt:98-231): find which of the 8 customer layouts the file uses ('' = unknown).
    Same order as the macro: WG first; brown, white, IM and Shop only when B1 is not 30; a later match wins.
    """
    layout = ''
    wg = MAP['WG adhoc']['Identification'].split(';')  # B1;30;A9;Modell;Q9;Stück
    if cell(grid, wg[2]) == wg[3]:
        layout = 'WG adhoc' if cell(grid, wg[4]) == wg[5] else 'WG dispo'
    if cell(grid, "B1") != "30":  # 20200907: only WG files carry Division 30 in B1
        for name in ("brown adhoc", "white adhoc", "IM adhoc", "Shop Order"):
            parts = MAP[name]['Identification'].split(';')  # e.g. A9;Modell;Q9;Stück  or  A1;Seq
            if cell(grid, parts[0]) == parts[1]:
                layout = (name if len(parts) == 2 or cell(grid, parts[2]) == parts[3]
                    else name.replace("adhoc", "dispo"))
    return layout

def collect_items(grid, layout, header, quantity_column, end_row):
    """The item loop of the SEG_* macros: read Material / Quantity / Net price row by row from the customer file.
    Stop rule per layout, as in the macros:
      brown + WG ... incomplete row AND row below Range(Material).End(xlDown)   white ... Material is empty
      IM ........... column A = 'SUMME' (IM keeps a blank output row for every skipped input row)
    Returns ({excel row of the standard sheet: {column: value}}, number of items without zero quantity).
    """
    m = MAP[layout]
    material_column, price_column, row = (m['Material'][0], m['Net price'][0], int(m['Material'][1:]))
    family, out_row, items, count = (layout.split()[0], 2, {}, 0)
    material = quantity = price = ''
    while True:
        if layout == "IM adhoc" and row > len(grid) + 1:
            # A360-FIX[B09] Task 01 step 5 -> macro SEG_IM_adhoc (Macro.txt:1036-1079)
            #   Bug: without a 'SUMME' row the macro looped for ever (Integer overflow + 'Resume Next').
            #   Fix: stop at the end of the sheet with a clear error.
            raise StandardizationError("IM adhoc file has no 'SUMME' row")
        material = cell(grid, f"{material_column}{row}", material)
        quantity = cell(grid, f"{quantity_column}{row}", quantity)
        price = (
            cell(grid, f"{price_column}{row}", price) or "0"
        )  # 'If NetPrice = "" Then NetPrice = "0"'
        if layout == "IM adhoc" and cell(grid, f"A{row}").upper() == "SUMME":
            break
        if material.strip(" ") and quantity.strip(" ") and price.strip(" "):
            items[out_row] = dict(header, J=material, K=quantity, CO=price)
            if quantity == "0":  # macro funItemValidation
                items[out_row]['B'] = 'Zero Quantity'
            else:
                count += 1
            out_row += 0 if layout == 'IM adhoc' else 1
        elif (family == "white" and material == "") or (family in ("brown", "WG") and end_row < row):
            break
        out_row += 1 if layout == 'IM adhoc' else 0
        row += 1
    return (items, count)

def convert(sheet, grid, layout):
    """Macros SEG_Brown_*, SEG_White_*, SEG_WG_*, SEG_IM_adhoc (Macro.txt:291-1098).
    Returns (outputs, error_flag, date_error): outputs = [(name token, items, item count)] - one entry per order.
    """
    m, error_flag = (MAP[layout], False)
    end_row = sheet.Range(m['Material']).End(-4121).Row  # orderRowCount = Range(Material).End(xlDown).Row
    end_row = end_row if end_row <= 32767 else 0  # VBA 'Integer' overflow -> error -> stays 0
    header = {"BK": "yn01", "E": "4601", "F": "10", "G": m["Division"], "H": cell(grid, m["Sold-To Party"]),
        "I": cell(grid, m["Ship-To Party"]), "C": cell(grid, m["PO Number"]),
        "CQ": cell(grid, m["Usage Code"]), "CR": layout,}
    if (
        "dispo" in layout
    ):  # SEG_Brown_Dispo / SEG_White_Dispo / SEG_WG_Dispo: one order per delivery-date column
        outputs = []
        for bucket in m["Req. deliv.date"].split(";"):
            rdd = cell(grid, bucket)
            if layout != "white dispo" and rdd != "":
                rdd, flag = fmt_rdd(rdd.replace('.', '/'))
                error_flag = error_flag or flag
            items, count = collect_items(grid, layout, dict(header, M=rdd), bucket[0], end_row)
            if count > 0:  # 'If ItemCount > 0 Then SaveAs ...'
                outputs.append((rdd.replace('.', ''), items, count))
        return (outputs, error_flag, False)
    rdd = cell(grid, m['Req. deliv.date'])  # adhoc layouts: one order per file
    if ((layout in ("brown adhoc", "WG adhoc") and rdd != "" and rdd.lower() != "sofort")
        or (layout == "white adhoc" and rdd not in ("", "asap")) or (layout == "IM adhoc" and rdd != "")):
        rdd, error_flag = fmt_rdd(rdd.replace('.', '/'))
        if (layout in ("brown adhoc", "WG adhoc") and rdd not in ("sofort", "asap")
            and not vba_like(rdd, "####.*.*")):
            return ([], error_flag, True)  # Temp!Z2 'Req. deliv.date format Incorrect'
    items, count = collect_items(grid, layout, dict(header, M=rdd), m['Order Quantity'][0], end_row)
    return ([(rdd.replace('.', ''), items, count)], error_flag, False)

def convert_shop(excel, workbook, sheet):
    """Macro SEG_Shop_Order (Macro.txt:1102-1288): one order per 'Seq' group. Excel itself sorts the rows, so the
    grouping and numbering are identical to the macro. The customer file is closed without saving.
    Returns (outputs, error_flag)."""
    m, error_flag = (MAP['Shop Order'], False)
    end_row = sheet.Range(m['Material']).End(-4121).Row
    end_row = end_row if end_row <= 32767 else 0
    grid = excel.read(sheet)
    # Pre work: key column Z = Division & Dist.channel & PO & Sold-to & Ship-to & "Z" for every row with a Division
    sheet.Range('Z1').Value = 'KeyColumn'
    keys = [[(cell(grid, f"B{r}") + cell(grid, f"C{r}") + cell(grid, f"D{r}") + cell(grid, f"F{r}")
                + cell(grid, f"G{r}") + "Z" if cell(grid, f"B{r}") != "" else cell(grid, f"Z{r}", raw=True))
        ] for r in range(2, end_row + 3)]
    sheet.Range(f"Z2:Z{end_row + 2}").Value = keys
    if (
        workbook.ActiveSheet.Index == 1 and end_row >= 2
    ):  # the macro sorts the ACTIVE sheet (A360-KEPT[K10])
        sort = sheet.Sort
        sort.SortFields.Clear()
        sort.SortFields.Add(Key=sheet.Range(f"Z2:Z{end_row}"), SortOn=0, Order=1, DataOption=0)
        sort.SetRange(sheet.Range(f"A1:Z{end_row}"))
        sort.Header, sort.MatchCase, sort.Orientation, sort.SortMethod = (1, False, 1, 1)
        sort.Apply()
    grid = excel.read(sheet)  # number the groups 1, 2, 3 ... in column A
    previous_key, seq, column_a = (cell(grid, 'Z2'), 1, [])
    for r in range(2, end_row + 3):
        key, value = cell(grid, f"Z{r}"), cell(grid, f"A{r}", raw=True)
        if key != "":
            seq += 0 if key == previous_key else 1
            value = seq
        column_a.append([value])
        previous_key = key
    sheet.Range(f"A2:A{end_row + 2}").Value = column_a
    max_order = int(excel.app.WorksheetFunction.Max(sheet.Range('A1:A9000')) or 0)
    grid = excel.read(sheet)
    row, outputs, seq_value = (int(m['Material'][1:]), [], None)
    # like the macro's String variables: an Excel error cell keeps the previous value ('Resume Next')
    header_fields = {"F": "Distchannel", "G": "Division", "H": "Sold-To Party", "I": "Ship-To Party",
        "C": "PO Number", "CQ": "Usage Code",}
    header = dict.fromkeys(header_fields, '')
    material = quantity = price = rdd = ''
    for order_no in range(1, max_order + 1):
        in_order = int(excel.app.WorksheetFunction.CountIf(sheet.Range('A1:A9000'), order_no))
        for column, name in header_fields.items():
            header[column] = cell(grid, f"{m[name][0]}{row}", header[column])
        header.update(BK='yn01', E='4601', CR='Shop Order')
        items, count, out_row = ({}, 0, 2)
        for _ in range(in_order):
            seq_value, rdd = cell(grid, f"A{row}", raw=True), cell(
                grid, f"{m['Req. deliv.date'][0]}{row}", rdd)
            material = cell(grid, f"{m['Material'][0]}{row}", material)
            quantity = cell(grid, f"{m['Order Quantity'][0]}{row}", quantity)
            price = cell(grid, f"{m['Net price'][0]}{row}", price) or "0"
            if rdd != "":
                rdd, flag = fmt_rdd(rdd.replace('.', '/'))
                error_flag = error_flag or flag
            if material.strip(" ") and quantity.strip(" ") and price.strip(" "):
                items[out_row] = dict(header, M=rdd, J=material, K=quantity, CO=price)
                if quantity == "0":
                    items[out_row]['B'] = 'Zero Quantity'
                else:
                    count += 1
                out_row += 1
            row += 1
        seq_number = seq_value if isinstance(seq_value, float) else None
        if (count > 0 and seq_number is not None and order_no <= seq_number) or seq_number == 0:
            outputs.append((str(order_no), items, count))
    return (outputs, error_flag)

@business_operation("standardize", outcome=file_standardization_outcome)
@step
def standardize(file_name):
    """Task 01 step 5 'Run macro SEG_Type': open the customer file once, find its layout and build the standard
    order rows. Returns (layout, outputs, error_flag, date_error)."""
    source = Path(FOLDERS.INPUT) / file_name
    if set("[]") & set(file_name) or len(str(source)) > 200:
        # A360 step 5 renamed every file to 'Order File.xlsx' before Excel opened it (steps.txt:271). Excel cannot
        # open / save names with [ ] or very long paths, so such a file is opened through a short-named copy.
        source = Path(shutil.copy(source, Path(FOLDERS.INPUT) / 'Order File_tmp.xlsx'))
    workbook = RUN.excel.open(source)
    try:
        sheet = workbook.Sheets(1)
        try:  # SEG_Type: remove the AutoFilter, save the file
            if sheet.AutoFilterMode:
                sheet.AutoFilterMode = False
            workbook.Save()  # A360-KEPT[K07] (the macro saved the customer file)
        except Exception as ex:  # SEG_Type ignored this ('Resume Next')
            logging.warning(f"{file_name}: AutoFilter / Save skipped ({ex})")
        grid = RUN.excel.read(sheet)
        layout = detect_type(grid)
        logging.info(
            f"{file_name}: layout '{layout or 'UNKNOWN'}' (B1={cell(grid, 'B1')!r} A9={cell(grid, 'A9')!r} "
            f"Q9={cell(grid, 'Q9')!r} L7={cell(grid, 'L7')!r} M7={cell(grid, 'M7')!r} "
            f"A2={cell(grid, 'A2')!r} A1={cell(grid, 'A1')!r})")
        emit_event('order_type', layout=layout or 'Unknown', name=file_name)
        if not layout:
            return ('', [], False, False)
        # A360-FIX[B15] Task 01 step 5 -> macro funMapping (Macro.txt:1954-1982)
        #   Bug: a missing field in config.json TemplateMapping raised a bare KeyError deep in convert() with no hint
        #        which layout / field was wrong. Fix: a clear StandardizationError naming the layout and the field.
        try:
            if layout == "Shop Order":
                return (layout, *convert_shop(RUN.excel, workbook, sheet), False)
            return (layout, *convert(sheet, grid, layout))
        except KeyError as ex:
            raise StandardizationError(f"config.json TemplateMapping['{layout}'] has no field {ex}") from ex
    finally:
        workbook.Close(False)  # SEG_*: 'Workbooks(FileName).Close (False)'
        if source.name == "Order File_tmp.xlsx":
            source.unlink(missing_ok=True)

@business_operation("save_standard")
@step
def save_standard(items, count, name):
    """Write one 'Standard Order Sheet' (template from the project folder) and read it back, so the next steps use
    exactly what Excel stored (A360/VBA also read the saved file). Returns (path, rows).
    Like A360 (macro SaveAs 'Order File.xlsx' + rename, steps.txt:289-301) Excel saves a short name first and the
    file is renamed afterwards - Excel refuses some names Windows allows ([ ], long paths).
    """
    workbook, temp = (RUN.excel.open(STANDARD_TEMPLATE), Path(FOLDERS.TEMPLATE) / 'Order File_tmp.xlsx')
    try:
        sheet = workbook.Sheets(1)
        sheet.Columns('C:C').NumberFormat = '0;[Red]0'  # PO number without decimals / E+ notation
        block = [[None] * LAST_COLUMN for _ in range(2, max(list(items) + [2]) + 1)]
        for row, values in items.items():
            for column, value in values.items():
                block[row - 2][col_number(column) - 1] = value
        block[0][LAST_COLUMN - 1] = count  # CS2 = 'Order Item Line Count'
        sheet.Range('A2').Resize(len(block), LAST_COLUMN).Value = block  # one write instead of one per cell
        workbook.SaveAs(str(temp), 51)
        rows = RUN.excel.read(sheet)
    finally:
        workbook.Close(False)
    path = Path(FOLDERS.TEMPLATE) / name
    os.replace(temp, path)
    for row in rows[
        1:
    ]:  # column C (PO number) as Excel shows it with format '0' - long numbers without 'E+15'
        if isinstance(row[2], float) and row[2].is_integer():
            row[2] = f"{row[2]:.0f}"
    return (str(path), rows)

def save_state(std_orders):
    """Remember the standardized files so that Task 02 can also be started on its own."""
    state = {"order_id": RUN.order_id, "orders": [
            {"file_idx": o.file_idx, "orig_name": o.orig_name, "path": o.path} for o in std_orders],}
    (Path(FOLDERS.LOGS) / f"run_state_{RUN.order_id}.json").write_text(
        json.dumps(state, indent=2), encoding="utf-8")

@step
def run(downloaded):
    """Order Creation Task 01 (steps.txt:231-337). downloaded = [(file_idx, file_name)] from GetOrderFileByAPI.
    Returns (ok, std_orders). ok=False: every file was reported to the portal as 'Order File Standardization Error'.
    """
    portal_log('Start Sub1 Task')  # step 2
    message_card(235, file_ids=[item[0] for item in downloaded[:20]])
    ok, std_orders, finished = (True, [], set())  # finished = files that already got a final portal status
    RUN.excel = RUN.excel or ExcelSession()
    business_batch(('standardize',), len(downloaded))
    try:
        for file_number, (file_idx, file_name) in enumerate(
            sorted(downloaded, key=lambda item: item[1].upper()), start=1
        ):  # step 5: each file
            LOG_CONTEXT['file_idx'] = file_idx
            emit_event('progress', phase='Files', current=file_number, total=len(downloaded), name=file_name)
            # A360-FIX[B20] Task 01 step 5 'If vFileName does not include .xlsx' (steps.txt:247)
            #   Bug: the check was case-sensitive, 'ORDER.XLSX' was rejected as 'Not Found Excel File'. Fix: ignore case.
            if not file_name.lower().endswith(".xlsx"):
                business_event("standardize", "issue", f"{file_name}: not an Excel file")
                portal_api.result_status(file_idx, 'Fail', 'Fail', 'Not Found Excel File')
                finished.add(file_idx)
                portal_log(f"Standard Order({file_idx}_No Excel)")
                (Path(FOLDERS.INPUT) / file_name).unlink(missing_ok=True)
                emit_event("progress", phase="Files", current=file_number, total=len(downloaded),
                    name=file_name, complete=True,)
                continue
            layout, outputs, error_flag, date_error = standardize(file_name)
            if error_flag:
                # A360-KEPT[K01] Task 01 step 5 'Get cell O2 ... as vErrorHandlingFlag' (steps.txt:287)
                #   The macro sets Temp!O2 'Error Flag' for EVERY 'sofort'/'asap' and every text that is no date, and
                #   A360 never stopped on it. Kept: only a warning (failing here would reject orders A360 creates).
                logging.warning(
                    f"{file_name}: delivery date is not a date (sofort/asap/text) - SAP will propose one")
            if date_error:  # step 5 'If vDateCheck (Temp!Z2) not equals blank'
                portal_log('Error - Incorrect date format', error=True)
                portal_api.result_status(file_idx, "Validation", "Validation",
                    "Incorrect date format in input excel file",)
                finished.add(file_idx)
                send_mail(f"[Error] - Date Format Incorrect - {RUN.order_id}",
                    f"Hi Team, <br><br>the order ID - {RUN.order_id} could not processed due to incorrect date "
                    f"format provided in the input excel file. <br><br>Thanks, <br>RPA Bot",
                    to=OTHERS.date_error_mail_receivers,)
                ok = False
                break  # 'Close the excel and Stop the current task'
            message_card(289, rename_text=','.join((token for token, _, _ in outputs)), count=len(outputs))
            if not outputs or ("adhoc" in layout and outputs[0][0] == ""):
                message_card(292, file_name=file_name)
                logging.error(
                    f"{file_name}: no standard order (layout '{layout or 'unknown'}' / delivery date blank)")
                ok = False  # step 5 'If vReNameTexts equals blank ... break'
                break
            names = [f"{token}_{file_name}" for token, _, _ in outputs]
            # A360-FIX[B26] Task 01 step 5 renames (steps.txt:296-301)
            #   Bug: two delivery-date columns with the same date, or a date with '/', gave equal / invalid file
            #   names; the A360 rename then failed half way. Fix: a clear error (same result: the order is stopped).
            #   A blank dispo date column with items is kept ('_<file>'), header validation reports 'RDD No Value'.
            if len({n.upper() for n in names}) != len(names) or any(
                BAD_NAME_CHARACTERS & set(t) for t, _, _ in outputs):
                business_event('standardize', 'issue', 'Duplicate or invalid output filename')
                raise StandardizationError(f"delivery dates give duplicate / invalid file names: {names}")
            # A360-FIX[B21] Task 01 step 6 (steps.txt:302-317)
            #   Bug: A360 found the file id of each standardized file again by 'file name includes original name';
            #   when one original name was part of another, a file got the wrong file id.
            #   Fix: every standardized order keeps its own file id (StdOrder.file_idx) - no searching by name.
            for (token, items, count), name in zip(outputs, names):
                path, rows = save_standard(items, count, name)
                std_orders.append(StdOrder(file_idx, file_name, path, rows))
                logging.info(f"Standard order saved: {name} ({count} item(s))")
            emit_event("progress", phase="Files", current=file_number, total=len(downloaded), name=file_name,
                complete=True,)
    except Exception as ex:  # Catch: portal log, screenshot, error mail
        message_card_error(318, ex)
        ok = False
        portal_log(f"Order Creation Task 01 error: {ex}", error=True)
        send_error_mail('Order Creation Task 01', ex, screenshot(Path(FOLDERS.SCREENSHOTS) / 'Error.png'))
    finally:
        with cleanup_mode():
            portal_log('End sub task 1')  # Finally step 1
            message_card(323, file_ids=[order.file_idx for order in std_orders[:20]], ok=ok)
            LOG_CONTEXT['file_idx'] = '-'
            if not ok:  # Finally step 3
                portal_log('Order File Standardization Error')
                for file_idx, _ in downloaded:
                    # A360-FIX[B06] Task 01 Finally step 3 (steps.txt:327-335)
                    #   Bug: files that already had their own final status (e.g. 'Incorrect date format', step 5) were
                    #   reported again and the specific message was overwritten. Fix: only files without a status.
                    if file_idx and file_idx not in finished:
                        portal_api.result_status(file_idx, "Validation", "Validation",
                            "Order File Standardization Error",)
                        portal_log(f"Standard Order({file_idx}_Fail)")
    # A360 Task 02 worked in Template-folder order (steps.txt:305-317, 502): sort by the standardized file name
    std_orders = sorted(std_orders, key=lambda order: Path(order.path).name.upper()) if ok else []
    save_state(std_orders)
    return (ok, std_orders)

if __name__ == "__main__":  # stand-alone run on the files in the Input folder
    arguments = [a for a in sys.argv[1:] if a != '--live']
    if len(arguments) < 2 or not all("=" in a for a in arguments[1:]):
        sys.exit(__doc__)
    RUN.order_id, RUN.dry_run = (arguments[0], '--live' not in sys.argv)
    setup_logging(RUN.order_id)
    Path(FOLDERS.TEMPLATE).mkdir(parents=True, exist_ok=True)
    result = False
    try:
        portal_start()  # --live: a real portal header (logHeaderId) like a normal run
        result, orders = run([tuple(a.split('=', 1)) for a in arguments[1:]])
        print('Task 01', 'OK' if result else 'FAILED', *[o.path for o in orders], sep='\n')
    except RunStopped:
        result = False
        logging.info('Task 01 stopped by the operator')
        sys.exit(130)
    finally:
        with cleanup_mode():
            if RUN.excel:
                RUN.excel.quit()
            portal_end(result)
        finish_run(0 if result else 130 if sys.exc_info()[0] is SystemExit else 1)
        shutdown()
