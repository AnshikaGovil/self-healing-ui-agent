"""Local cooperative execution controls. No GUI, automation or network calls."""

import contextlib
import json
import math
import os
import threading
import time
import uuid
from pathlib import Path

COMMANDS = {'pause', 'resume', 'step', 'stop'}
MAX_JSON_BYTES = 8192
LIVE_SECONDS = 5

class RunStopped(KeyboardInterrupt):
    """Operator requested a stop at an operation boundary."""

def control_paths(status_path):
    status = Path(status_path)
    stem = status.name.removesuffix('_status.json')
    return (status.with_name(stem + '_control.json'), status.with_name(stem + '_control_state.json'))

def read_object(path):
    try:
        with Path(path).open("r", encoding="utf-8") as stream:
            data = stream.read(MAX_JSON_BYTES + 1)
        if len(data) > MAX_JSON_BYTES:
            return None
        value = json.loads(data)
        return value if isinstance(value, dict) else None
    except (OSError, ValueError):
        return None

def write_object(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.' + uuid.uuid4().hex[:12] + '.tmp')
    try:
        temporary.write_text(json.dumps(value), encoding='utf-8')
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)

class ControlClient:
    """Write one command and await acknowledgement from the matching live run."""

    def __init__(self, status_path):
        self.command_path, self.state_path = control_paths(status_path)
        self.sequence = 0
        self.lock = threading.Lock()

    def read(self, run_id):
        state = read_object(self.state_path)
        if not state or state.get("run_id") != run_id:
            return None
        updated = state.get('updated_at')
        if (not isinstance(updated, (int, float)) or not math.isfinite(updated)
            or not 0 <= time.time() - updated <= LIVE_SECONDS):
            return None
        return state

    def send(self, command, run_id):
        if command not in COMMANDS:
            raise ValueError('Unknown control command')
        state = self.read(run_id)
        if (not state or not state.get("enabled") or state.get("mode") in {"stopping", "finished"}):
            raise RuntimeError('The run is no longer accepting commands')
        if command == "step" and not state.get("can_step"):
            raise RuntimeError('Next step is available only while execution is paused')
        # Some Windows clocks return the same tick for several rapid clicks.
        with self.lock:
            sequence = max(time.monotonic_ns(), self.sequence + 1, state.get('last_sequence', 0) + 1)
            write_object(self.command_path, {'run_id': run_id, 'sequence': sequence, 'command': command})
            self.sequence = sequence
        return sequence

class RunController:
    """The worker waits on a condition; its COM/SAP objects stay on its own thread."""

    def __init__(self, status_path, run_id, publish=None):
        self.command_path, self.state_path = control_paths(status_path)
        self.run_id = run_id
        self.publish = publish
        self.condition = threading.Condition()
        self.publish_lock = threading.Lock()
        self.local = threading.local()
        self.closed = threading.Event()
        self.paused = False
        self.stopped = False
        self.finished = False
        self.busy = False
        self.waiting = False
        self.credit = False
        self.stepping = False
        self.operation_name = ''
        self.last_completed = ''
        self.completed_operations = 0
        self.last_sequence = 0
        self.last_command = ''
        self.command_error = ''
        self.revision = 0
        self.published_revision = -1
        self.last_write = 0.0
        self._publish()
        self.thread = threading.Thread(target=self._watch, name='RPA controls', daemon=True)
        self.thread.start()

    def snapshot(self):
        with self.condition:
            mode = ("finished" if self.finished else ("stopping" if self.stopped else ("stepping"
                        if self.stepping or self.credit else ("paused" if self.paused and self.waiting
                            else "pause_requested" if self.paused else "running"))))
            return {"enabled": not self.finished, "run_id": self.run_id, "pid": os.getpid(), "mode": mode,
                "paused": self.paused, "busy": self.busy, "can_step": self.paused and self.waiting
                and not self.busy and not self.credit and not self.stopped, "operation": self.operation_name,
                "last_completed": self.last_completed, "completed_operations": self.completed_operations,
                "last_sequence": self.last_sequence, "last_command": self.last_command,
                "command_error": self.command_error, "updated_at": time.time(), "revision": self.revision,}

    def _publish(self):
        with self.publish_lock:
            state = self.snapshot()
            now = time.monotonic()
            if (state["revision"] == self.published_revision and now - self.last_write < 1):
                return
            try:
                write_object(self.state_path, state)
            except OSError:
                return
            self.last_write = now
            changed = state['revision'] != self.published_revision
            self.published_revision = state['revision']
            if self.publish and changed:
                try:
                    self.publish(state)
                except Exception:
                    pass

    def read_command(self):
        command = read_object(self.command_path)
        if not command or command.get("run_id") != self.run_id:
            return
        sequence = command.get('sequence')
        action = command.get('command')
        if (not isinstance(sequence, int) or isinstance(sequence, bool) or not 0 < sequence < 2**63
            or not isinstance(action, str) or action not in COMMANDS):
            return
        with self.condition:
            if sequence <= self.last_sequence or self.finished:
                return
            self.last_sequence, self.last_command = (sequence, action)
            self.command_error = ''
            if self.stopped:
                self.command_error = 'Stop has already been requested'
            elif action == "pause":
                self.paused = True
                self.credit = False
            elif action == "resume":
                self.paused = False
                self.credit = False
            elif action == "step":
                if self.paused and self.waiting and not self.busy and not self.credit:
                    self.credit = True
                else:
                    self.command_error = 'Pause at a boundary before using Next step'
            elif action == "stop":
                self.stopped = True
                self.paused = False
                self.credit = False
            self.revision += 1
            self.condition.notify_all()
        self._publish()

    def _watch(self):
        while not self.closed.wait(0.1):
            self.read_command()
            self._publish()

    def _wait(self, name, before):
        self.read_command()
        while True:
            with self.condition:
                if self.stopped or self.finished:
                    self.waiting = False
                    self.revision += 1
                    stopped = True
                    allowed = False
                else:
                    stopped = False
                    allowed = not self.paused or self.credit
                    if allowed:
                        was_waiting = self.waiting
                        step_pending = self.credit
                        self.waiting = False
                        if before:
                            self.busy = True
                            self.operation_name = name
                            self.stepping = self.paused
                            if self.credit:
                                self.credit = False
                        if before or was_waiting:
                            self.revision += 1
                    elif not self.waiting:
                        self.waiting = True
                        self.operation_name = name
                        self.revision += 1
            self._publish()
            if stopped:
                raise RunStopped('Stopped by the operator')
            if allowed:
                return step_pending
            with self.condition:
                self.condition.wait(timeout=0.2)
            self.read_command()

    def wait_boundary(self, name):
        """Observe pause/stop during idle waits without spending a step credit."""
        if not getattr(self.local, "cleanup_depth", 0) and not getattr(self.local, "operation_depth", 0):
            return self._wait(name, before=False)
        return False

    def preview_delay(self, seconds, name="Standardize files"):
        """Pause an optional demo delay; Next bypasses it without using its credit."""
        remaining = max(0, float(seconds))
        while remaining > 0:
            if self.wait_boundary(name):
                return True
            started = time.monotonic()
            self.closed.wait(min(0.1, remaining))
            remaining -= max(0, time.monotonic() - started)
        return self.wait_boundary(name)

    @contextlib.contextmanager
    def operation(self, name):
        if getattr(self.local, "cleanup_depth", 0) or getattr(self.local, "operation_depth", 0):
            yield
            return
        self._wait(name, before=True)
        self.local.operation_depth = 1
        failed = True
        try:
            yield
            failed = False
        finally:
            self.local.operation_depth = 0
            with self.condition:
                self.busy = False
                self.stepping = False
                if not failed:
                    self.last_completed = name
                    self.completed_operations += 1
                self.revision += 1
            self._publish()
            if not failed:
                self._wait(name, before=False)

    @contextlib.contextmanager
    def join_operation(self):
        """Join work whose parent owns the boundary and waits for this worker.

        Parallel startup is one operation for Pause/Next/Stop. Only its parent
        updates the shared control state; nested worker operations stay inside it.
        """
        depth = getattr(self.local, 'operation_depth', 0)
        self.local.operation_depth = depth + 1
        try:
            yield
        finally:
            self.local.operation_depth = depth

    @contextlib.contextmanager
    def cleanup_mode(self):
        depth = getattr(self.local, 'cleanup_depth', 0)
        self.local.cleanup_depth = depth + 1
        try:
            yield
        finally:
            self.local.cleanup_depth = depth

    def finish(self):
        with self.condition:
            self.finished = True
            self.paused = False
            self.credit = False
            self.revision += 1
            self.condition.notify_all()
        self.closed.set()
        self._publish()

    def close(self):
        self.finish()
        self.thread.join(timeout=1)

def button_options(state, pending=""):
    """Keep UI decisions testable without Tk."""
    active = bool(state and state.get('enabled') and (state.get('mode') not in {'stopping', 'finished'}))
    paused = bool(state and state.get('paused'))
    label = 'Resume' if paused or pending == 'pause' else 'Pause'
    if pending == "resume":
        label = 'Pause'
    return {"pause_text": label, "pause_enabled": active and not pending,
        "step_enabled": active and not pending and bool(state.get("can_step")),
        "stop_enabled": active and pending != "stop",}
