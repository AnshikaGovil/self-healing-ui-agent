"""Bounded business progress for the local monitor; no automation or network access."""

LABELS = {"download": "Download order files", "standardize": "Standardize files", "knox": "Knox sign-in",
    "sap": "SAP sign-in", "validate": "Check order details", "create": "Create SAP orders",
    "save_results": "Save result sheets", "report": "Report order results", "cleanup": "Close applications",
    "prepare": "Prepare sample file", "save_standard": "Save standard files", "verify": "Check saved output",
}
FULL_PLAN = ("knox", "download", "sap", "standardize", "validate", "create", "save_results", "report",
    "cleanup",)
TASK01_PLAN = ('prepare', 'standardize', 'save_standard', 'verify', 'cleanup')

def boolean_outcome(result, args, kwargs):
    return {'state': 'success' if result else 'failed'}

def standardization_outcome(result, args, kwargs):
    ok, orders = result
    return {"state": "failed" if not ok else "success" if orders else "skipped", "message": (
            "Standardization failed" if not ok else "" if orders else "No eligible orders"),}

def file_standardization_outcome(result, args, kwargs):
    """Record the conversion result before its separate workbook-save operation."""
    layout, outputs, error_flag, date_error = result
    if date_error:
        return {'state': 'failed', 'message': 'Incorrect date format'}
    if not outputs or ("adhoc" in layout and outputs[0][0] == ""):
        return {'state': 'failed', 'message': 'No eligible standard order'}
    return {'state': 'success'}

def validation_outcome(order):
    failed = order.system_error or order.business_error
    return {'state': 'failed' if failed else 'success', 'message': order.result_message if failed else ''}

def creation_outcome(order, dry_run=False):
    if order.system_error or (order.so_number and order.so_result != "Success"):
        return {'state': 'failed', 'message': order.result_message or order.so_result}
    if dry_run:
        return {'state': 'preview', 'message': 'Dry run: no SAP order was saved'}
    if order.business_error or not order.so_number:
        return {'state': 'failed', 'message': order.result_message or 'No SAP order was saved'}
    return {'state': 'success', 'message': 'SAP order ' + str(order.so_number)}

class BusinessProgress:
    """Keep one aggregate per planned step, rather than unbounded file history."""

    def __init__(self):
        self.configure(FULL_PLAN, 'Order creation')

    def configure(self, steps, scope):
        keys = list(dict.fromkeys((key for key in steps if key in LABELS)))
        self.scope = str(scope)[:80]
        self.rows = [{"key": key, "label": ("Close Excel"
                    if key == "cleanup" and str(scope).startswith("Task 01") else LABELS[key]),
                "state": "pending", "active": 0, "expected": 0, "done": 0, "failed": 0, "preview": 0,
                "skipped": 0, "unconfirmed": 0, "message": "",} for key in keys]
        self.by_key = {row['key']: row for row in self.rows}

    def apply(self, event):
        row = self.by_key.get(event.get('key'))
        if row is None:
            return
        state = event.get('state')
        if state == "running":
            row['active'] += 1
        elif state in {"success", "failed", "preview", "skipped", "unconfirmed"}:
            row['active'] = max(0, row['active'] - 1)
            counter = 'done' if state == 'success' else state
            row[counter] += 1
        elif state == "issue":
            row['failed'] += 1
        else:
            return
        message = event.get('message', '')
        if message and (state in {"failed", "issue", "unconfirmed"} or not row["failed"]):
            row['message'] = str(message)[:240]
        self._update_state(row)

    def expect(self, keys, total):
        for key in keys:
            row = self.by_key.get(key)
            if row is not None:
                row['expected'] = self.completed(row) + max(0, int(total))
                self._update_state(row)

    @staticmethod
    def completed(row):
        return sum((row[field] for field in ('done', 'failed', 'preview', 'skipped', 'unconfirmed')))

    @staticmethod
    def _update_state(row):
        if row["active"]:
            row['state'] = 'running'
        elif row["failed"]:
            row['state'] = 'failed'
        elif row["unconfirmed"]:
            row['state'] = 'unconfirmed'
        elif BusinessProgress.completed(row) < row["expected"]:
            row['state'] = 'waiting' if BusinessProgress.completed(row) else 'pending'
        elif row["done"]:
            row['state'] = 'success'
        elif row["preview"]:
            row['state'] = 'preview'
        elif row["skipped"]:
            row['state'] = 'skipped'
        else:
            row['state'] = 'pending'

    def finish(self):
        for row in self.rows:
            if row["active"]:
                row['active'] = 0
                row['unconfirmed'] += 1
                self._update_state(row)
            elif row["expected"] and self.completed(row) < row["expected"]:
                if self.completed(row):
                    row['unconfirmed'] += 1
                    row['message'] = 'Not all planned orders reached this step'
                    self._update_state(row)
                else:
                    row['state'] = 'not_run'
            elif row["state"] == "pending":
                row['state'] = 'not_run'

    def snapshot(self):
        return [dict(row) for row in self.rows]

def row_status(row):
    state = row.get('state', 'pending')
    failed, done = (row.get('failed', 0), row.get('done', 0))
    if state == "running":
        return 'Running / issue' if failed else 'Running'
    if failed:
        return f"{done} done / {failed} failed" if done else f"{failed} failed"
    if state == "waiting":
        return f"{done}/{row['expected']} done"
    if state == "success":
        return f"{done} done" if done > 1 else "Done"
    return {"pending": "Pending", "not_run": "Not run", "preview": "Preview", "skipped": "Skipped",
        "unconfirmed": "Unconfirmed",}.get(state, "Unconfirmed")

def run_caption(state):
    rows = state.get('business_steps', [])
    issues = any((row.get('failed') or row.get('unconfirmed') for row in rows))
    if state.get("state") != "finished":
        return ('Running', 'issue' if issues else 'running')
    if state.get("finish_reason") == "stopped":
        return ('Stopped', 'neutral')
    code = state.get('exit_code')
    if code is not None and code != 0:
        return ('Failed', 'failed')
    if issues:
        return ('Check results', 'issue')
    return ('Completed', 'success') if code == 0 else ('Finished', 'neutral')
