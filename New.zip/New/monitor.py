"""Optional progress and execution controls. Closing the window leaves the bot running."""

import argparse
import json
import math
import os
import time
from pathlib import Path

AUTO_CLOSE_SECONDS = 2.0
# Panel width: this share of the screen's usable width, kept between limits given
# in pixels at 100% Windows scaling (multiplied by the DPI scale).
PANEL_SHARE, PANEL_MIN_WIDTH, PANEL_MAX_WIDTH = (0.22, 320, 440)
TEXT_LIMIT_WIDTH = 320  # the one-line text limits below were chosen for this width

def read_status(path):
    try:
        state = json.loads(Path(path).read_text(encoding='utf-8'))
        return state if isinstance(state, dict) else None
    except (OSError, ValueError):
        return None

def status_details(state):
    """Interpret the existing status format without contacting the automation."""
    now = time.monotonic()
    step = state.get('active_step') or 'Between operations'
    elapsed = state.get('elapsed_seconds', max(0, now - state.get('run_started_monotonic', now)))
    progress = state.get('progress', {})
    current, total = (progress.get('current', 0), progress.get('total', 0))
    percent = None
    if isinstance(current, int) and isinstance(total, int) and total > 0:
        done = current if progress.get('complete') else current - 1
        percent = min(100, max(0, 100 * done / total))
    finished = state.get('state') == 'finished'
    badge = 'RUNNING'
    if finished:
        code = state.get('exit_code')
        step = 'Completed' if code == 0 else 'Failed' if code is not None else 'Finished'
        badge = step.upper()
        percent = 100 if code == 0 else 0
    operation = state.get('operation_started_monotonic')
    operation_seconds = max(0, now - operation) if operation and (not finished) else None
    return {"step": step, "elapsed": elapsed, "operation_seconds": operation_seconds, "progress": progress,
        "current": current, "total": total, "percent": percent, "finished": finished, "badge": badge,}

def display_status(state):
    """Return display text without importing Tk or contacting the bot."""
    details = status_details(state)
    progress = details['progress']
    text = (f"Order: {state.get('order_id', '-')}\n" f"File: {state.get('file_id', '-')}\n"
        f"Step: {details['step']}\n" f"Elapsed: {details['elapsed']:.0f} seconds")
    if details["total"]:
        text += f"\n{progress.get('phase', 'Progress')}: {details['current']}/{details['total']}"
    if progress.get("name"):
        text += f"\n{progress['name']}"
    if details["operation_seconds"] is not None:
        text += f"\nCurrent operation: {details['operation_seconds']:.0f} seconds"
    if state.get("last_error"):
        text += f"\nLast error: {state['last_error'][:240]}"
    return (text, details['percent'])

class CompletionTimer:
    """Close after a finished snapshot, even if later reads temporarily fail."""

    def __init__(self, delay=AUTO_CLOSE_SECONDS):
        self.delay = max(0, float(delay))
        self.deadline = None

    def remaining(self, state, now=None):
        now = time.monotonic() if now is None else now
        if self.deadline is None and state and state.get("state") == "finished":
            self.deadline = now + self.delay
        return None if self.deadline is None else max(0, self.deadline - now)

def update_bar(bar, percent):
    if percent is None:
        if str(bar["mode"]) != "indeterminate":
            bar.configure(mode='indeterminate', value=0)
            bar.start(50)
    else:
        bar.stop()
        bar.configure(mode='determinate', value=percent)

def clock_text(seconds):
    seconds = max(0, int(seconds))
    hours, seconds = divmod(seconds, 3600)
    minutes, seconds = divmod(seconds, 60)
    return (f"{hours:02}:{minutes:02}:{seconds:02}" if hours else f"{minutes:02}:{seconds:02}")

def short_text(value, limit=120):
    value = ' '.join(str(value).split())
    return value if len(value) <= limit else value[:limit - 1] + '…'

def enable_dpi_awareness():
    """Set only this monitor process's DPI behavior; leave system settings alone."""
    if os.name == "nt":
        import ctypes

        try:
            ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
        except (AttributeError, OSError):
            ctypes.windll.user32.SetProcessDPIAware()

def work_area(root):
    """Usable area (without the taskbar) of the screen that shows this widget."""
    if os.name == "nt":
        import ctypes
        from ctypes import wintypes

        class MonitorInfo(ctypes.Structure):
            _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", wintypes.RECT), ("rcWork", wintypes.RECT),
                ("dwFlags", wintypes.DWORD),]

        user32 = ctypes.windll.user32
        user32.MonitorFromWindow.argtypes = [ctypes.c_void_p, wintypes.DWORD]
        user32.MonitorFromWindow.restype = ctypes.c_void_p
        user32.GetMonitorInfoW.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
        info = MonitorInfo(cbSize=ctypes.sizeof(MonitorInfo))
        monitor = user32.MonitorFromWindow(root.winfo_id(), 2)  # nearest screen
        if monitor and user32.GetMonitorInfoW(monitor, ctypes.byref(info)):
            work = info.rcWork
            return (work.left, work.top, work.right, work.bottom)
        rect = wintypes.RECT()
        if ctypes.windll.user32.SystemParametersInfoW(0x0030, 0, ctypes.byref(rect), 0):
            return (rect.left, rect.top, rect.right, rect.bottom)
    return (0, 0, root.winfo_screenwidth(), root.winfo_screenheight())

def prevent_focus_stealing(root):
    if os.name == "nt":
        import ctypes

        user32 = ctypes.windll.user32
        user32.GetParent.argtypes = [ctypes.c_void_p]
        user32.GetParent.restype = ctypes.c_void_p
        user32.GetWindowLongW.argtypes = [ctypes.c_void_p, ctypes.c_int]
        user32.SetWindowLongW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_long]
        hwnd = user32.GetParent(root.winfo_id()) or root.winfo_id()
        # WS_EX_NOACTIVATE: progress refreshes must not steal SAP/Knox focus.
        style = user32.GetWindowLongW(hwnd, -20)
        user32.SetWindowLongW(hwnd, -20, style | 134217728 | 128)

class RunControls:
    """Icon buttons with hover labels and acknowledged local commands."""

    def __init__(self, parent, status_path, background, font, wrap):
        import tkinter as tk
        from run_control import ControlClient

        self.client = ControlClient(status_path)
        self.run_id = ''
        self.state = None
        self.pending = ''
        self.sequence = 0
        self.sent_at = 0
        self.error = ''
        self.pause_action = 'pause'
        self.tooltip = None
        self.tooltip_after = None
        self.font = font
        self.background = background
        self.frame = tk.Frame(parent, bg=background)
        self.frame.pack(fill='x', pady=(8, 0))
        line = tk.Frame(self.frame, bg=background)
        line.pack(fill='x')
        scale = self.scale = max(1, parent.winfo_fpixels('1i') / 96)
        self.icons = {(action, enabled): self.make_icon(parent, action, enabled, scale)
            for action in ("pause", "resume", "step", "stop") for enabled in (False, True)}
        self.buttons = {}
        for column, command in enumerate(("pause", "step", "stop")):
            line.columnconfigure(column, weight=1, uniform='controls')
            button = tk.Button(line, image=self.icons[(command, False)], text="",
                command=lambda action=command: self.send(action), bg="#1c2b43", activebackground="#314663",
                relief="flat", borderwidth=0, padx=5, pady=round(5 * scale), takefocus=False,
                state="disabled",)
            button.grid(row=0, column=column, sticky='ew', padx=(0, 4) if column < 2 else 0)
            button.bind('<Enter>', lambda event, action=command: self.show_hint(action))
            button.bind('<Leave>', lambda event: self.hide_hint())
            button.bind('<ButtonPress-1>', lambda event: self.hide_hint(), add='+')
            self.buttons[command] = button
        self.caption = tk.StringVar(value='Waiting for execution controls')
        tk.Label(self.frame, textvariable=self.caption, bg=background, fg="#bacbe7", font=font, anchor="w",
            justify="left", wraplength=wrap,).pack(fill="x", pady=(4, 0))

    @staticmethod
    def make_icon(parent, action, enabled, scale):
        from PIL import Image, ImageDraw, ImageTk

        size = max(16, round(18 * scale))
        factor = 4
        canvas = Image.new('RGBA', (size * factor, size * factor))
        draw = ImageDraw.Draw(canvas)
        colour = '#ffb2b2' if action == 'stop' else '#e3ebf8'
        if not enabled:
            colour = '#70819b'
        unit = size * factor / 18

        def box(coords):
            return tuple((round(value * unit) for value in coords))

        def triangle(coords):
            draw.polygon([box(point) for point in coords], fill=colour)

        if action == "pause":
            draw.rounded_rectangle(box((4, 3, 7, 15)), radius=unit, fill=colour)
            draw.rounded_rectangle(box((11, 3, 14, 15)), radius=unit, fill=colour)
        elif action == "resume":
            triangle(((5, 3), (15, 9), (5, 15)))
        elif action == "step":
            triangle(((3, 3), (12, 9), (3, 15)))
            draw.rectangle(box((13, 3, 15, 15)), fill=colour)
        elif action == "stop":
            draw.rounded_rectangle(box((4, 4, 14, 14)), radius=unit, fill=colour)
        return ImageTk.PhotoImage(canvas.resize((size, size), Image.Resampling.LANCZOS), master=parent)

    def hide_hint(self):
        if self.tooltip_after is not None:
            self.frame.after_cancel(self.tooltip_after)
            self.tooltip_after = None
        if self.tooltip is not None:
            self.tooltip.destroy()
            self.tooltip = None

    def show_hint(self, command):
        self.hide_hint()
        self.tooltip_after = self.frame.after(350, lambda: self.display_hint(command))

    def display_hint(self, command):
        import tkinter as tk

        self.tooltip_after = None
        action = self.pause_action if command == 'pause' else command
        text = {"pause": "Pause after the current operation", "resume": "Resume execution",
            "step": "Next step: run one operation, then pause",
            "stop": "Stop pending work and close applications",}[action]
        if command == "step" and self.buttons["step"].cget("state") == "disabled":
            text = ("Next step: wait for the current operation"
                if self.pending == "step" or (self.state or {}).get("paused")
                else "Next step: pause execution first")
        button = self.buttons[command]
        tip = tk.Toplevel(self.frame)
        tip.withdraw()
        tip.overrideredirect(True)
        tip.attributes('-topmost', True)
        tk.Label(tip, text=text, font=self.font, bg="#24334c", fg="#f2f7ff", padx=round(8 * self.scale),
            pady=round(4 * self.scale), wraplength=round(240 * self.scale), justify="left",).pack()
        tip.update_idletasks()
        left, top, right, bottom = work_area(button)
        x = max(left, min(button.winfo_rootx(), right - tip.winfo_reqwidth()))
        y = max(top, button.winfo_rooty() - tip.winfo_reqheight() - 5)
        tip.geometry(f"+{x}+{y}")
        prevent_focus_stealing(tip)
        tip.deiconify()
        self.tooltip = tip

    def send(self, command):
        self.hide_hint()
        if command == "pause":
            command = self.pause_action
        if self.pending and command != "stop":
            return
        try:
            self.sequence = self.client.send(command, self.run_id)
            self.pending = command
            self.sent_at = time.monotonic()
            self.error = ''
        except (OSError, RuntimeError, ValueError) as error:
            self.error = str(error)
        self.render()

    def refresh(self, run_id, finished=False):
        self.run_id = run_id
        self.state = self.client.read(run_id) if run_id and (not finished) else None
        if self.pending:
            if self.state and self.state.get("last_sequence", 0) >= self.sequence:
                self.pending = ''
                self.error = self.state.get('command_error', '')
            elif time.monotonic() - self.sent_at > 5:
                self.pending = ''
                self.error = 'Command not acknowledged; check the bot and try again'
        self.render(finished)

    def render(self, finished=False):
        from run_control import button_options

        options = button_options(self.state, self.pending)
        self.pause_action = 'resume' if options['pause_text'] == 'Resume' else 'pause'
        for key, option in (("pause", "pause_enabled"), ("step", "step_enabled"), ("stop", "stop_enabled"),):
            enabled = options[option]
            action = self.pause_action if key == 'pause' else key
            self.buttons[key].configure(image=self.icons[(action, bool(enabled))],
                state="normal" if enabled else "disabled",)
        mode = self.state.get('mode', '') if self.state else ''
        operation = short_text(self.state.get('operation', ''), 45) if self.state else ''
        if self.error:
            text = self.error
        elif finished:
            text = 'Execution finished'
        elif self.pending == "stop" or mode == "stopping":
            text = 'Stopping after the current operation; cleanup will follow'
        elif self.pending == "pause" or mode == "pause_requested":
            text = 'Pausing after the current operation'
        elif self.pending == "step":
            text = 'Starting the next operation'
        elif mode == "stepping":
            text = 'Running one step: ' + operation
        elif mode == "paused":
            last = self.state.get('last_completed', '')
            text = 'Paused after: ' + short_text(last, 45) if last else 'Paused before: ' + operation
        elif self.state:
            text = 'Next step runs one complete operation'
        else:
            text = 'Execution controls unavailable'
        self.caption.set(text)

def show_window(status_path, close_delay=AUTO_CLOSE_SECONDS):
    import tkinter as tk

    from business_progress import row_status, run_caption
    from message_cards import MessageCards, relative_width

    enable_dpi_awareness()
    root = tk.Tk()
    root.withdraw()
    root.title('Order creation progress')
    root.overrideredirect(True)
    root.attributes('-topmost', True)
    root.attributes('-alpha', 0.86)
    scale = max(1, root.winfo_fpixels('1i') / 96)
    pad = round(10 * scale)
    left, top, right, bottom = work_area(root)
    width = relative_width(right - left - 2 * pad, scale, PANEL_SHARE, PANEL_MIN_WIDTH, PANEL_MAX_WIDTH)

    def fit(limit):
        """Scale a one-line character limit with the panel width."""
        return max(10, round(limit * width / (TEXT_LIMIT_WIDTH * scale)))

    background = '#09142a'
    colours = {"running": "#8db0ff", "success": "#7be3b0", "failed": "#ff9a9a", "issue": "#ffd18a",
        "pending": "#bacbe7", "waiting": "#bacbe7", "not_run": "#bacbe7", "preview": "#ffd18a",
        "skipped": "#bacbe7", "unconfirmed": "#ffd18a", "neutral": "#bacbe7",}
    root.configure(bg=background)
    panel = tk.Frame(root, bg=background, padx=pad, pady=pad, highlightbackground="#516784",
        highlightthickness=1,)
    panel.pack(fill='both', expand=True)
    body_font, small_font = (('Segoe UI', 11), ('Segoe UI', 9))
    content_width = width - 2 * pad - 4

    def label(parent, text="", colour="#f2f7ff", font=body_font, variable=None, wrap=0):
        return tk.Label(parent, text=text, textvariable=variable, bg=background, fg=colour, font=font,
            anchor="w", justify="left", wraplength=wrap,)

    header = tk.Frame(panel, bg=background)
    header.pack(fill='x')
    close = label(header, '×', colour='#bacbe7', font=('Segoe UI', 12))
    close.pack(side='right', padx=(round(8 * scale), 0))
    close.bind('<Button-1>', lambda event: root.destroy())
    status = label(header, 'Waiting', colour=colours['running'], font=('Segoe UI', 9, 'bold'))
    status.pack(side='right')
    title = label(header, 'Order creation', font=('Segoe UI', 12, 'bold'))
    title.pack(side='left')

    scope_var = tk.StringVar(value='Waiting for the run')
    label(panel, colour="#bacbe7", font=small_font, variable=scope_var, wrap=content_width
    ).pack(fill="x", pady=(round(4 * scale), round(8 * scale)))
    tk.Frame(panel, bg='#344865', height=1).pack(fill='x')

    file_var = tk.StringVar()
    file_label = label(panel, colour='#e3ebf8', variable=file_var, font=small_font, wrap=content_width)
    file_label.pack(fill='x', pady=(round(8 * scale), round(6 * scale)))
    steps_frame = tk.Frame(panel, bg=background)
    steps_frame.pack(fill='x')
    step_widgets = {}
    step_keys = None

    def rebuild_steps(rows):
        nonlocal step_keys
        keys = tuple((row['key'] for row in rows))
        if keys == step_keys:
            return
        for widget in steps_frame.winfo_children():
            widget.destroy()
        step_widgets.clear()
        step_keys = keys
        if not rows:
            label(steps_frame, "Business step history is unavailable.", colour="#bacbe7", font=small_font,
                wrap=content_width,).pack(fill="x")
            return
        for row in rows:
            line = tk.Frame(steps_frame, bg=background)
            line.pack(fill='x', pady=round(1 * scale))
            icon = tk.Canvas(line, width=round(18 * scale), height=round(17 * scale), bg=background,
                highlightthickness=0,)
            icon.pack(side='left', padx=(0, round(6 * scale)))
            tag = label(line, colour='#bacbe7', font=small_font)
            tag.pack(side='right')
            name = label(line, row['label'], wrap=max(100, content_width - round(125 * scale)))
            name.pack(side='left', fill='x', expand=True)
            step_widgets[row['key']] = (icon, name, tag)

    notice_var = tk.StringVar()
    label(panel, colour="#ffd18a", variable=notice_var, font=small_font, wrap=content_width,
    ).pack(fill="x", pady=(round(6 * scale), 0))
    tk.Frame(panel, bg='#344865', height=1).pack(fill='x', pady=(round(8 * scale), 0))
    footer_var = tk.StringVar(value='Pending steps have not started')
    label(panel, colour="#bacbe7", font=small_font, variable=footer_var, wrap=content_width,
    ).pack(fill="x", pady=(round(6 * scale), 0))
    controls = RunControls(panel, status_path, background, small_font, content_width)
    drag = {}
    for handle in (header, title):
        handle.bind("<Button-1>", lambda event: drag.update(
                x=event.x_root - root.winfo_x(), y=event.y_root - root.winfo_y()),)
        handle.bind("<B1-Motion>", lambda event: root.geometry(
                f"+{event.x_root - drag.get('x', 0)}+{event.y_root - drag.get('y', 0)}"),)

    initial_position = True
    previous_height = None

    def position_window():
        nonlocal initial_position, previous_height
        root.update_idletasks()
        left, top, right, bottom = work_area(root)
        height = min(root.winfo_reqheight(), bottom - top - 2 * pad)
        if height != previous_height:
            x = right - width - pad if initial_position else root.winfo_x()
            y = bottom - height - pad if initial_position else min(root.winfo_y(), bottom - height - pad)
            root.geometry(f"{width}x{height}+{max(left, x)}+{max(top, y)}")
            initial_position, previous_height = (False, height)

    position_window()
    prevent_focus_stealing(root)
    completion = CompletionTimer(close_delay)
    cards = MessageCards(root, scale, work_area, prevent_focus_stealing)
    last_state = None

    def refresh():
        nonlocal last_state
        state = read_status(status_path)
        now = time.monotonic()
        remaining = completion.remaining(state, now)
        if state is not None:
            last_state = state
        if last_state is not None:
            state = last_state
            cards.feed(state)
            if remaining is not None:
                remaining = max(remaining, cards.timeline.remaining(now))
                if remaining <= 0:
                    root.destroy()
                    return
            rows = state.get('business_steps', [])
            rebuild_steps(rows)
            controls.refresh(state.get('run_id', ''), state.get('state') == 'finished')
            caption, tone = run_caption(state)
            mode = controls.state.get('mode') if controls.state else None
            if state.get("state") != "finished" and mode in {"paused", "pause_requested", "stepping",
                "stopping",}:
                caption = {"paused": "Paused", "pause_requested": "Pausing", "stepping": "One step",
                    "stopping": "Stopping",}[mode]
                tone = 'issue'
            status.configure(text=caption, fg=colours[tone])
            elapsed = status_details(state)['elapsed']
            scope = state.get('business_scope', 'Order creation')
            scope_var.set(f"{scope}  ·  {clock_text(elapsed)}")
            progress = state.get('progress', {})
            name = progress.get('name', '')
            phase = progress.get('phase', '')
            if phase in {"Files", "Orders"}:
                count = (f" ({progress.get('current', 0)}/{progress.get('total', 0)})"
                    if progress.get("total") else "")
                file_var.set(short_text(name, fit(36)) + count)
            elif not file_var.get():
                file_var.set('Order: ' + short_text(state.get('order_id', '—'), fit(38)))
            for row in rows:
                icon, name_label, tag = step_widgets[row['key']]
                step_state = row.get('state', 'pending')
                tone = 'issue' if step_state == 'running' and row.get('failed') else step_state
                colour = colours.get(tone, colours['neutral'])
                tag.configure(text=row_status(row), fg=colour)
                name_label.configure(fg='#f2f7ff' if step_state not in {'pending', 'not_run'} else '#bacbe7')
                icon.delete('all')
                c, r = (9 * scale, 6 * scale)
                icon.create_oval(c - r, c - r, c + r, c + r, outline=colour, fill=(colour
                        if step_state in {"success", "failed", "running"} else background),
                    width=max(1, round(scale)),)
                if step_state == "success":
                    icon.create_line((c - 3 * scale, c, c - scale, c + 2 * scale, c + 3 * scale,
                            c - 3 * scale,), fill=background, width=max(1, round(1.5 * scale)),)
                elif step_state == "failed":
                    for dy in (-1, 1):
                        icon.create_line(c - 2 * scale, c - 2 * scale * dy, c + 2 * scale,
                            c + 2 * scale * dy, fill=background, width=max(1, round(1.5 * scale)),)
                elif step_state == "running":
                    icon.create_oval(c - 2 * scale, c - 2 * scale, c + 2 * scale, c + 2 * scale,
                        fill=background, outline="",)
            failure = next((row.get("message") for row in rows if row.get("failed") and row.get("message")
                ), "",)
            notice_var.set(short_text(failure, fit(95)) if failure else '')
            if remaining is not None:
                footer_var.set(f"Closing automatically in {math.ceil(remaining)}s")
            else:
                done = sum((row.get('state') == 'success' for row in rows))
                pending = sum((row.get('state') in {'pending', 'waiting'} for row in rows))
                active = sum((bool(row.get('active')) for row in rows))
                failed = sum((bool(row.get('failed')) for row in rows))
                parts = [f"{done} done", f"{pending} pending"]
                if active:
                    parts.insert(1, f"{active} running")
                if failed:
                    parts.append(f"{failed} failed")
                footer_var.set(' · '.join(parts))
        position_window()
        root.after(250, refresh)

    root.deiconify()
    root.after(0, refresh)
    root.mainloop()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--status', required=True, help="Path to a run's *_status.json")
    parser.add_argument("--close-delay", type=float, default=AUTO_CLOSE_SECONDS,
        help="Seconds to show the final result before closing (0–60; default: 2)",)
    args = parser.parse_args()
    if not math.isfinite(args.close_delay) or not 0 <= args.close_delay <= 60:
        parser.error('--close-delay must be between 0 and 60 seconds')
    show_window(args.status, args.close_delay)

if __name__ == "__main__":
    main()
