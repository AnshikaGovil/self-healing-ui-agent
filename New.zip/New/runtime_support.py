"""Local diagnostics and cooperative controls; no SAP, Excel or portal calls."""

import atexit
import contextlib
from run_control import RunController, RunStopped
import functools
from itertools import islice
import threading

from business_progress import BusinessProgress, LABELS
from message_cards import MessageHistory
from a360_message_catalog import MESSAGES, SOURCE_GROUPS, API_RESPONSE_SOURCES
import copy
import json
import logging
import logging.handlers
import os
import queue
import subprocess
import sys
import tempfile
import time
import uuid
from pathlib import Path

_listener = None
_handlers = []
_producer = None
_sink = None
_finished = False
_controller = None
_warned = set()

def _warn_once(message):
    if message not in _warned:
        _warned.add(message)
        try:
            sys.stderr.write(message + '\n')
        except Exception:
            pass

def _redact(value, secrets):
    if isinstance(value, str):
        for secret in sorted(secrets, key=len, reverse=True):
            value = value.replace(secret, '***')
        return value
    if isinstance(value, dict):
        return {key: _redact(item, secrets) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_redact(item, secrets) for item in value]
    return value

class _QueuedHandler(logging.handlers.QueueHandler):
    def __init__(self, pending, secrets):
        super().__init__(pending)
        self.secrets = secrets

    def prepare(self, record):
        record = copy.copy(record)
        record.msg = _redact(record.getMessage(), self.secrets)
        record.args = None
        if record.exc_info:
            record.exc_text = _redact(logging.Formatter().formatException(record.exc_info), self.secrets)
        record.exc_info = None
        if record.stack_info:
            record.stack_info = _redact(record.stack_info, self.secrets)
        for field in ("order", "file_idx", "rpa_event"):
            if hasattr(record, field):
                setattr(record, field, _redact(getattr(record, field), self.secrets))
        return record

    def enqueue(self, record):
        # New visual observations never wait for space or affect business records.
        event = getattr(record, 'rpa_event', None)
        if isinstance(event, dict) and event.get("event") in {"api_response", "order_type",
            "monitor_message", "a360_message",}:
            try:
                self.queue.put_nowait(record)
            except queue.Full:
                pass
        else:
            # Preserve the existing FIFO/backpressure policy for ordinary records.
            self.queue.put(record)

class _Listener(logging.handlers.QueueListener):
    def enqueue_sentinel(self):
        self.queue.put(self._sentinel)

    def handle(self, record):
        for handler in self.handlers:
            if record.levelno >= handler.level:
                try:
                    handler.handle(record)
                except Exception:
                    _warn_once('A local logging output failed; automation continues.')

class _EventSink(logging.Handler):
    def __init__(self, folder, name):
        super().__init__(logging.DEBUG)
        run_id = f"{os.getpid()}-{uuid.uuid4().hex[:12]}"
        stem = f"{name}_{run_id}"
        self.status_path = folder / f"{stem}_status.json"
        self.events_path = folder / f"{stem}_events.jsonl"
        self.stream = self.events_path.open('a', encoding='utf-8')
        self.last_snapshot = 0.0
        self.sequence = 0
        self.business = BusinessProgress()
        self.messages = MessageHistory()
        self.state = {"run_id": run_id, "pid": os.getpid(), "state": "running",
            "run_started_monotonic": time.monotonic(), "active_step": "", "step_metrics": {},
            "business_scope": self.business.scope, "business_steps": self.business.snapshot(),
            "message_cards": [],}

    def emit(self, record):
        try:
            payload = getattr(record, 'rpa_event', None)
            if payload is None and record.levelno < logging.WARNING:
                return
            payload = dict(payload or {'event': 'message', 'monotonic': time.monotonic()})
            self.sequence += 1
            event = {**payload, "sequence": self.sequence, "run_id": self.state["run_id"],
                "timestamp": record.created, "order_id": getattr(record, "order", "-"),
                "file_id": getattr(record, "file_idx", "-"),}
            if event["event"] == "api_response":
                source_line = API_RESPONSE_SOURCES.get(event.get('resource'))
                if source_line is not None:
                    event['source_lines'] = [source_line]
            self.stream.write(json.dumps(event, ensure_ascii=False) + '\n')
            self.stream.flush()
            self.state.update(sequence=self.sequence, updated_at=record.created, order_id=event["order_id"],
                file_id=event["file_id"], last_event=event,)
            kind = event['event']
            if kind == "control_status":
                self.state['control'] = event['control']
            if kind == "business_plan":
                self.business.configure(event['steps'], event.get('scope', 'Order creation'))
            elif kind == "business_batch":
                self.business.expect(event['keys'], event['total'])
            elif kind == "business_step":
                self.business.apply(event)
            elif kind == "run_finished":
                self.business.finish()
            self.state['business_scope'] = self.business.scope
            self.state['business_steps'] = self.business.snapshot()
            if "active_step" in event:
                self.state['active_step'] = event['active_step']
            if kind == "progress":
                self.state['progress'] = payload
            if kind in ("step_started", "progress"):
                self.state['operation_started_monotonic'] = event['monotonic']
            if record.levelno >= logging.WARNING or kind == "notification":
                self.state["notification"] = {"sequence": self.sequence,
                    "text": payload.get("message", record.getMessage()), "timestamp": record.created,}
            if record.levelno >= logging.ERROR:
                self.state['last_error'] = record.getMessage()
            if kind == "step_finished":
                metrics = self.state["step_metrics"].setdefault(
                    event["step"], {"calls": 0, "raised": 0, "seconds": 0.0})
                metrics['calls'] += 1
                metrics['raised'] += event['outcome'] == 'raised'
                metrics['seconds'] += event['seconds']
            if kind == "run_finished":
                self.state['state'] = 'finished'
                self.state['exit_code'] = payload.get('exit_code')
                self.state['finish_reason'] = payload.get('reason', '')
                self.state['elapsed_seconds'] = time.monotonic() - self.state['run_started_monotonic']
            card_added = False
            try:
                card_added = self.messages.add(event, record.levelno, record.getMessage())
                if card_added:
                    self.state['message_cards'] = self.messages.snapshot()
            except Exception:
                _warn_once('A local message card could not be recorded; monitoring continues.')
            now = time.monotonic()
            force = (bool(card_added) or kind in ("run_started", "run_finished", "control_status")
                or record.levelno >= logging.ERROR)
            if force or now - self.last_snapshot >= 0.25:
                self._snapshot()
                self.last_snapshot = now
        except Exception:
            _warn_once('Local progress files could not be updated; automation continues.')

    def _snapshot(self):
        temporary = self.status_path.with_suffix('.tmp')
        try:
            temporary.write_text(json.dumps(self.state, indent=2, ensure_ascii=False), encoding='utf-8')
            for attempt in range(3):
                try:
                    os.replace(temporary, self.status_path)
                    break
                except PermissionError:
                    if attempt == 2:
                        raise
                    # Windows readers can briefly prevent atomic replacement.
                    time.sleep(0.01)
        finally:
            temporary.unlink(missing_ok=True)

    def close(self):
        try:
            self.stream.close()
        finally:
            super().close()

def configure_logging(handlers, context_filter, secrets, folder, name, monitor_window=False):
    """Queue local writes; capture/redact context on the calling thread."""
    global _listener, _handlers, _producer, _sink, _finished, _controller
    shutdown()
    root = logging.getLogger()
    for handler in list(root.handlers):
        root.removeHandler(handler)
    _finished = False
    _handlers = list(handlers)
    _sink = None
    try:
        _sink = _EventSink(Path(folder), name)
        _handlers.append(_sink)
    except Exception:
        _warn_once('Local progress files are unavailable; normal logging continues.')
    pending = queue.Queue(maxsize=4096)
    _producer = _QueuedHandler(pending, tuple((secret for secret in secrets if secret)))
    _producer.addFilter(context_filter)
    _listener = _Listener(pending, *_handlers, respect_handler_level=True)
    _listener.start()
    root.addHandler(_producer)
    emit_event('run_started')
    status_path = _sink.status_path if _sink else None
    if status_path is not None:
        try:
            _controller = RunController(status_path, _sink.state["run_id"],
                publish=lambda state: emit_event("control_status", control=state),)
        except Exception:
            _warn_once('Execution controls are unavailable; automation continues.')
    if monitor_window and status_path is not None:
        try:
            subprocess.Popen([sys.executable, "-B", str(Path(__file__).with_name("monitor.py")), "--status",
                    str(status_path),], creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,)
        except Exception:
            logging.warning('The monitor window could not start; automation continues.')
    return status_path

def emit_event(kind, **fields):
    """Best-effort observation; fields never decide business outcomes."""
    if _listener is not None:
        try:
            logging.getLogger("rpa.events").info("%s", kind.replace("_", " "), extra={"rpa_event": {
                        "event": kind, "monotonic": time.monotonic(), **fields,}},)
        except Exception:
            _warn_once('A local progress event could not be recorded.')

def _card_value(value, depth=0):
    """Bound diagnostic copies; never change the business object's data."""
    if isinstance(value, str):
        return value[:4096]
    if value is None or isinstance(value, (bool, int, float)):
        return value
    if depth >= 3:
        return str(value)[:256]
    if isinstance(value, dict):
        return {str(key)[:80]: _card_value(item, depth + 1) for key, item in islice(value.items(), 24)}
    if isinstance(value, (list, tuple)):
        return [_card_value(item, depth + 1) for item in value[:20]]
    return str(value)[:4096]

def message_card(source_line, **values):
    """Observe an A360 message box without waiting, controlling work or doing I/O."""
    try:
        if source_line in MESSAGES:
            emit_event("a360_message", source_lines=list(SOURCE_GROUPS.get(source_line, (source_line,))),
                source_line=source_line, values=_card_value(values),)
    except Exception:
        _warn_once('An A360 message card could not be recorded; automation continues.')

def message_card_error(source_line, error):
    """Include the original Python error location without replacing its exception."""
    try:
        frame = getattr(error, '__traceback__', None)
        while frame is not None and frame.tb_next is not None:
            frame = frame.tb_next
        location = (f"{Path(frame.tb_frame.f_code.co_filename).name}:{frame.tb_lineno}" if frame is not None
            else "No Python traceback available")
        message_card(source_line, error=f"{type(error).__name__}: {error}", location=location)
    except Exception:
        _warn_once('An A360 error card could not be recorded; automation continues.')

def card_errors(source_line):
    """Observe errors in functions that already propagate them."""

    def decorate(function):
        @functools.wraps(function)
        def observed(*args, **kwargs):
            try:
                return function(*args, **kwargs)
            except Exception as error:
                try:
                    message_card_error(source_line, error)
                except Exception:
                    pass
                raise

        return observed

    return decorate

def outlook_summary_card(orders):
    """Expose existing Outlook batch results; do not send an additional email."""
    try:
        if not any(order.file_idx == "outlook" for order in orders):
            return
        summaries = [{"file": Path(order.path).name, "result": order.so_result,
                "so_number": order.so_number, "creation_date": order.so_creation_date,
                "message": order.result_message,} for order in orders[:20]]
        content = "Existing results; no Outlook reply sent\n" + "\n".join(
            f"{item['file']} | {item['result']} | SO {item['so_number'] or '-'} | "
            f"Date {item['creation_date'] or '-'} | {item['message']}" for item in summaries)
        message_card(730, content=content, results=summaries, count=len(orders), email_sent=False)
    except Exception:
        _warn_once('The local Outlook result summary could not be recorded.')

def control_operation(name):
    return _controller.operation(name) if _controller is not None else contextlib.nullcontext()

def wait_for_controls(name="Between operations"):
    if _controller is not None:
        return _controller.wait_boundary(name)
    return False

def join_control_operation():
    """Worker context for an operation whose parent joins it before cleanup."""
    return _controller.join_operation() if _controller is not None else contextlib.nullcontext()

def wait_preview_delay(seconds):
    if _controller is not None:
        return _controller.preview_delay(seconds)
    time.sleep(seconds)
    return False

def cleanup_mode():
    return _controller.cleanup_mode() if _controller is not None else contextlib.nullcontext()

def controlled_step(name):
    def decorate(function):
        @functools.wraps(function)
        def controlled(*args, **kwargs):
            with control_operation(name):
                return function(*args, **kwargs)

        return controlled

    return decorate

_BUSINESS_CONTEXT = threading.local()

def set_business_plan(steps, scope="Order creation"):
    try:
        emit_event('business_plan', steps=list(steps), scope=scope)
    except Exception:
        _warn_once('Business progress could not be recorded; automation continues.')

def business_batch(keys, total):
    try:
        emit_event('business_batch', keys=list(keys), total=total)
    except Exception:
        _warn_once('Business progress could not be recorded; automation continues.')

def business_event(key, state, message=""):
    try:
        emit_event('business_step', key=key, state=state, message=message)
    except Exception:
        _warn_once('Business progress could not be recorded; automation continues.')

def business_operation(key, *, outcome=None, controlled=True):
    """Observe results and optionally wait between complete operations."""

    def decorate(function):
        @functools.wraps(function)
        def observed(*args, **kwargs):
            active = getattr(_BUSINESS_CONTEXT, 'active', ())
            if key in active:
                return function(*args, **kwargs)
            gate = control_operation(LABELS.get(key, key)) if controlled else contextlib.nullcontext()
            with gate:
                _BUSINESS_CONTEXT.active = (*active, key)
                business_event(key, 'running')
                try:
                    result = function(*args, **kwargs)
                except RunStopped:
                    business_event(key, 'unconfirmed', 'Stopped by the operator')
                    raise
                except BaseException:
                    business_event(key, 'failed', 'The operation raised an error; see the log')
                    raise
                else:
                    try:
                        details = outcome(result, args, kwargs) if outcome else {'state': 'success'}
                        business_event(key, **details)
                    except Exception:
                        business_event(key, 'unconfirmed', 'The result could not be confirmed')
                    return result
                finally:
                    _BUSINESS_CONTEXT.active = active

        return observed

    return decorate

def finish_run(exit_code=None):
    global _finished
    if _listener is not None and not _finished:
        stopped = bool(_controller and _controller.stopped)
        if _controller is not None:
            _controller.finish()
        emit_event('run_finished', exit_code=exit_code, reason='stopped' if stopped else '')
        _finished = True

def shutdown():
    """Drain queued records before closing files; safe to call repeatedly."""
    global _listener, _handlers, _producer, _sink, _controller
    if _listener is None:
        if _controller is not None:
            _controller.close()
            _controller = None
        return
    finish_run()
    if _controller is not None:
        _controller.close()
        _controller = None
    logging.getLogger().removeHandler(_producer)
    try:
        _listener.stop()
    except Exception:
        _warn_once('Some local log records could not be flushed.')
    _listener = None
    for handler in _handlers:
        try:
            handler.flush()
            handler.close()
        except Exception:
            _warn_once('A local logging output could not be closed.')
    _handlers = []
    _producer = None
    _sink = None

def download_file(session, url, destination, *, create_parent=False, **request_options):
    """Stream identical response bytes, then publish the complete destination."""
    destination = Path(destination)
    temporary = None
    count = 0
    try:
        with session.get(url, stream=True, **request_options) as response:
            response.raise_for_status()
            if create_parent:
                destination.parent.mkdir(parents=True, exist_ok=True)
            with tempfile.NamedTemporaryFile(mode="wb", prefix="rpa-download-", suffix=".part",
                dir=destination.parent, delete=False,) as output:
                temporary = Path(output.name)
                for chunk in response.iter_content(chunk_size=1024 * 1024):
                    if chunk:
                        output.write(chunk)
                        count += len(chunk)
            os.replace(temporary, destination)
            return count
    finally:
        if temporary is not None:
            try:
                temporary.unlink(missing_ok=True)
            except OSError:
                logging.warning('An incomplete download could not be removed: %s', temporary)

def template_path(module_file, filename):
    """Prefer the legacy root layout; support the supplied Templates layout."""
    root = Path(module_file).resolve().parent
    legacy = root / filename
    return legacy if legacy.exists() else root / 'Templates' / filename

atexit.register(shutdown)
