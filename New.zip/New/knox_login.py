"""Knox portal login, including the native SSO / Knox Portal dialogs."""

import logging
import time

from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from helpers import close_application, wait_for_element_to_be_clickable
from knox_logout import click_dialog_button
from rpa_core import step
from knox_browser import create_knox_webdriver, quit_knox_webdriver

KNOX_URL = 'https://w1.samsung.net'
COOKIE_BUTTON = "//button[contains(@class, 'lg primary')]/span[text()='OK']"
LOGIN_BUTTON = "//button[contains(@class, 'primary md')]/span[text()='Login']"
PROFILE_BUTTON = '//div[@class="profile"]/button[@class="user-profile"]'
ERROR_POPUP = "//div[@class='popup-container popup--massege ']//div[@class='popup-body scroll-show']"
BAD_CREDENTIALS = 'ID or password has been entered incorrectly.'

MAX_ATTEMPTS = 3

class Knox_Login:

    def __init__(self, driver):
        self.driver = driver

    @step
    def login(self, knoxID, knoxPW):
        """Log in to the Knox portal. Returns True on success."""
        for attempt in range(1, MAX_ATTEMPTS + 1):
            try:
                logging.info(f"Knox login attempt {attempt}/{MAX_ATTEMPTS}.")
                self._restart_browser()
                self.driver.get(KNOX_URL)
                self._dismiss_cookie_popup()

                user_field = wait_for_element_to_be_clickable(self.driver, By.ID, 'id', 15)
                user_field.clear()
                user_field.send_keys(knoxID)

                password_field = wait_for_element_to_be_clickable(self.driver, By.ID, 'password', 15)
                password_field.clear()
                password_field.send_keys(knoxPW)

                self.driver.find_element(By.XPATH, LOGIN_BUTTON).click()
                # PY-CHANGE: wait only until the profile button or an error popup shows (was a fixed time.sleep(10)).
                # A360: Order Creation Main Task step 17 'Knox Login with ID and PW'.
                try:
                    WebDriverWait(self.driver, 20).until(EC.any_of(
                            EC.element_to_be_clickable((By.XPATH, PROFILE_BUTTON)),
                            EC.visibility_of_element_located((By.XPATH, ERROR_POPUP)),))
                except TimeoutException:
                    logging.info('Neither the Knox profile nor an error popup appeared within 20 s.')

                if self._credentials_rejected():
                    logging.error('Knox login failed: incorrect credentials.')
                    return False

                wait_for_element_to_be_clickable(self.driver, By.XPATH, PROFILE_BUTTON, 20)
                logging.info('Knox login successful.')

                self._quit_driver()
                time.sleep(2)
                click_dialog_button('Knox Portal', ('No',))
                # if not click_dialog_button("SSO", ("No",)):
                #     close_application("EpTray.exe")
                return True

            except Exception as ex:
                logging.warning(f"Knox login attempt {attempt} failed: {ex}")

        logging.error('Knox login failed after the maximum number of attempts.')
        return False

    @step(portal=False)
    def _restart_browser(self):
        """Start from a clean browser session for every attempt."""
        self._quit_driver()
        time.sleep(2)
        self.driver = create_knox_webdriver()

    def _quit_driver(self):
        driver, self.driver = (self.driver, None)
        quit_knox_webdriver(driver, log_closed=True)

    @step(portal=False)
    def _dismiss_cookie_popup(self):
        """Accept the cookie banner when it is displayed."""
        try:  # PY-CHANGE: 2 s instead of 5 s (a fresh profile shows the banner at once)
            popup = wait_for_element_to_be_clickable(self.driver, By.XPATH, COOKIE_BUTTON, 2)
            if popup:
                popup.click()
        except Exception:
            logging.info('No cookie popup displayed.')

    @step(portal=False)
    def _credentials_rejected(self):
        """True when Knox reports wrong credentials (checked without waiting - the login wait is already over).
        PY-CHANGE: get_attribute("text") of a <div> is always None, so wrong credentials were never recognised and the
        wrong password was tried 3 times (risk of an account lock). Now the visible text is read, without a 5 s wait.
        """
        try:
            popups = self.driver.find_elements(By.XPATH, ERROR_POPUP)
            if not popups:
                return False
            text = (popups[0].text or popups[0].get_attribute('textContent') or '').strip()
            if BAD_CREDENTIALS in text:
                return True
            logging.info(f"Knox popup: {text}")
            close_application('EpTray.exe')
        except Exception:
            logging.info('No Knox error popup displayed.')
        return False
