"""Order Creation Task 02 - create the sales orders of the standardized files and report the results.

A360 tasks converted here ('Order Creation A360 steps.txt'):
  * Order Creation Task 02           (steps.txt:422-769)
  * CheckOrderHeaderValidation       (steps.txt:1008-1079)  -> header_validation()
  * ExcelDataRead.vbs (Result sheet) (steps.txt:599-683)    -> write_result()
The SAP part (Order_Creation_Sales_Create) is in sales_create.py.

Run on its own (after Task 01; SAP must be logged on with exactly one session; without --live nothing is saved in
SAP and nothing is sent to the portal):
    python task02_create.py <ORDER_ID> [--live]
"""

import json
import logging
import os
import sys
from pathlib import Path

import portal_api
from runtime_support import (RunStopped, cleanup_mode, controlled_step, finish_run, shutdown, business_batch,
    business_event, business_operation, emit_event, message_card, message_card_error, template_path,
    outlook_summary_card,)
from business_progress import creation_outcome, validation_outcome
import sales_create
from config import FOLDERS, OTHERS
from exceptions import BotError, SapSessionLost
from rpa_core import (LOG_CONTEXT, RUN, ExcelSession, StdOrder, cell, portal_end, portal_log, portal_start,
    screenshot, send_error_mail, send_mail, setup_logging, step, vba_cstr,)

RESULT_TEMPLATE = template_path(__file__, 'Result Order Sheet.xlsx')
# A360-FIX[B02] CheckOrderHeaderValidation step 10 (steps.txt:1031-1034)
#   Bug: the message was "Wrong Distribution Channel on Excel Sheet", but SetOrderResultStatusAPI step 2 (steps.txt:389)
#        only knows "Wrong Distribution Channel Value on Excel Sheet" -> the portal got status 90 instead of 104.
#   Fix: the message of the status table is used (portal_api.VALIDATION_STATUS) -> status 104.
HEADER_CHECKS = (("E2", 4, "No Sales organization on Excel Sheet",
        "Wrong Sales Organization Value on Excel Sheet",), ("F2", 2,
        "No Distribution Channel on Excel Sheet", "Wrong Distribution Channel Value on Excel Sheet",), (
        "G2", 2, "No Division Field in Excel on Excel Sheet", "Wrong Division Value on Excel Sheet",),)

@business_operation("validate", outcome=lambda result, args, kwargs: validation_outcome(
        args[0] if args else kwargs["order"]),)
@step
def header_validation(order):
    """CheckOrderHeaderValidation (steps.txt:1008-1079): check sales org (4 characters), distribution channel and
    division (2 characters), PO number and delivery date of the standardized file."""
    portal_log('Start OrderHeaderValidation')  # step 1
    try:
        for ref, length, missing, wrong in HEADER_CHECKS:  # steps 2-14
            value = cell(order.rows, ref)
            # A360-KEPT[K08]: the A360 test 'equals Not Excel Sheet' can never be true - kept as it was
            message = missing if value == 'Not Excel Sheet' else wrong if len(value) != length else ''
            if message:
                order.result_message, order.business_error = (message, True)
                portal_log(message)
        if cell(order.rows, "G2") == "":  # step 15
            order.business_error = True
        for ref, message in (("C2", "Validation Error PO Number No Value"),
            ("M2", "Validation Error RDD No Value"),):
            if cell(order.rows, ref) == "":  # steps 16-17
                order.result_message, order.business_error = (message, True)
                portal_log(message)
    except Exception as ex:  # Catch
        message_card_error(1058, ex)
        order.system_error = True
        portal_log(f"CheckOrderHeaderValidation error: {ex}", error=True)
        screenshot(
            Path(FOLDERS.OUTPUT)
            / f"{Path(order.path).name}_Validation System Error.png"
        )  # step 18
        send_error_mail('CheckOrderHeaderValidation', ex, screenshot(Path(FOLDERS.SCREENSHOTS) / 'Error.png'))
    finally:
        portal_log('End HeaderValidation')  # Finally
        if order.system_error:
            order.so_result = order.so_status = 'SYSTEM'
            portal_log('End OrderFileValidation System Error')
        elif order.business_error:
            order.validation_flag, order.so_result, order.so_status = (True, 'Validation', 'Validation')

@controlled_step("Save result sheets")
@step
@step
def write_result(order):
    """Task 02 step 13 (steps.txt:599-683) + ExcelDataRead.vbs: write the 'Result Order Sheet' of one order into
    Output\\<standardized file>_Result.xlsx and collect the values for the portal (order.report).
    A360-FIX[B01] Task 02 step 13 (steps.txt:633,643,646)
      Bug: the A360 column numbers took Material from column T and 'Processed' from column K, so the item result
           count was always 0. Fix: the column map of ExcelDataRead.vbs (Material = J, Processed = A).
    """
    business_event('save_results', 'running')
    report, lines, done = ({}, [], 0)
    message_card(609, row_index=1, sales_org='')
    for row in order.rows[1:]:
        message_card(609, row_index=len(lines) + 2, sales_org=report.get('sales_org', ''))  # 'If vRowIndex not equals 1'
        text = [vba_cstr(value) for value in row]
        if not report.get("sales_org"):  # 'If vSalesOrg equals blanks'
            report = {"sales_org": text[4], "dist_chan": text[5], "division": text[6], "sold_to": text[7],
                "customer_name": text[36], "ship_to": text[8], "rdd": text[12], "item_count": text[96],}
        processed, remark = ('Fail', order.result_message) if order.validation_flag else (row[0], row[1])
        lines.append([order.so_creation_date, row[2], row[4], row[5], row[6], row[7], row[36], row[8],
                row[15], order.so_number, row[9], row[10], row[92], row[93], row[11], row[12], processed,
                remark,])
        done += 1 if order.so_number and text[0] == 'Yes' else 0
    order.report = dict(report, item_result_count=str(done))
    target = Path(FOLDERS.OUTPUT) / f"{Path(order.path).stem}_Result.xlsx"
    for attempt in (1, 2):
        # A360-FIX[B14] Task 02 step 13 (steps.txt:653-683)
        #   Bug: when ship-to or RDD was blank, A360 ran ExcelDataRead.vbs which wrote the same Result again (25 s of
        #        waiting) and could overwrite a good Result. Fix: one writer; a 2nd try only after an Excel error.
        try:
            workbook, temp = (RUN.excel.open(RESULT_TEMPLATE),
                Path(FOLDERS.OUTPUT) / "Result Order Sheet_tmp.xlsx",)
            try:
                if lines:
                    workbook.Sheets(1).Range('A2').Resize(len(lines), 18).Value = lines
                workbook.SaveAs(str(temp), 51)  # short name first, like A360 step 649 (copy) - Excel refuses [ ]
            finally:
                workbook.Close(False)
            os.replace(temp, target)
            business_event('save_results', 'success')
            logging.info(f"Result sheet saved: {target}")
            break
        except (
            Exception
        ) as ex:  # A360 Catch: screenshot Error_Bot.png, the task goes on (steps.txt:650-652)
            message_card_error(653, ex)
            message_card(679, report=order.report, so_number=order.so_number, address='')
            screenshot(Path(FOLDERS.SCREENSHOTS) / 'Error_Bot.png')
            portal_log(f"Result Order Sheet error: {ex}", error=True)
            RUN.excel.quit(force=True)
            if (
                attempt == 2
            ):  # the order is still reported to the portal (with its SO number)
                logging.error(f"Result sheet NOT saved: {target}")
                business_event("save_results", "failed", f"Result sheet not saved: {target.name}")
    if not report.get("ship_to") or not report.get("rdd"):
        message_card(653, error='Ship-to or delivery date is blank', location='Result sheet checks')
        message_card(679, report=order.report, so_number=order.so_number, address='')
        logging.warning(
            f"Ship-to '{report.get('ship_to')}' / RDD '{report.get('rdd')}' is blank in {target.name}")

@business_operation("create", outcome=lambda result, args, kwargs: creation_outcome(
        args[0] if args else kwargs["order"], RUN.dry_run),)
def create_with_relogin(order):
    """SalesCreate step 2: when SAP logged out, log on again ONCE (still one session) and try the order again."""
    try:
        sales_create.create_order(RUN.session, order)
    except SapSessionLost:
        logging.warning('SAP logged out - logging on again once')
        sales_create.sap_logout()
        sales_create.sap_login()
        sales_create.create_order(RUN.session, order)

def preserve_saved_results(std_orders):
    """Finish local output and original reporting only for already saved orders."""
    with cleanup_mode():
        for order in std_orders:
            if not order.so_number or order.status_sent:
                continue
            LOG_CONTEXT['file_idx'] = order.file_idx
            try:
                order.so_creation_date = order.so_creation_date.replace('.', '')
                if not order.report:
                    write_result(order)
                report = order.report
                report['rdd'] = cell(order.rows, 'M2').replace('.', '')
                report["ship_to"] = f"{cell(order.rows, 'I2')}_{report['rdd']}".strip()
                if report["ship_to"] != "_":
                    portal_api.result_status(order.file_idx, order.so_result, order.so_status,
                        order.result_message, order,)
            except Exception:
                logging.exception('Could not finalize saved order %s after stop', order.so_number)

@step
def run(std_orders):
    """Order Creation Task 02 (steps.txt:422-769). Returns False when the task itself crashed (A360 Catch)."""
    ok, error_text, failed = (True, '', [])
    stopped = False
    portal_log('Start Sub 2 Task')  # step 1
    message_card(426, count=len(std_orders))
    message_card(427, file_ids=[order.file_idx for order in std_orders[:20]])
    message_card(429, file_names=[Path(order.path).name for order in std_orders[:20]])
    RUN.excel = RUN.excel or ExcelSession()
    try:
        for order in std_orders:  # step 9: ResultStart for all
            LOG_CONTEXT['file_idx'] = order.file_idx
            message_card(434, file_id=order.file_idx)
            ship_to_rdd = f"{cell(order.rows, 'I2')}_{cell(order.rows, 'M2').replace('.', '')}".strip()
            portal_log(f"ShipToParty - {ship_to_rdd}")
            message_card(453, ship_to_rdd=ship_to_rdd)
            if ship_to_rdd != "_":
                if portal_api.result_start(order, ship_to_rdd):
                    message_card(465, retry_flag=order.retry_flag, result_id=order.result_idx)
                    portal_log(f"Order Create({order.file_idx}_ResultStart)")
                else:
                    # A360-FIX[B18] Task 02 step 9 -> SetOrderResultStartByAPI (steps.txt:349-366, 492-495)
                    #   Bug: when orderResultStart never answered 200, A360 still created the SAP order and the result
                    #        id lists could shift to the wrong files. Fix: this order gets SYSTEM and no SAP work.
                    message_card(465, retry_flag=order.retry_flag, result_id=order.result_idx)
                    order.so_result = order.so_status = 'SYSTEM'
                    order.result_message = 'Order Result Start Error'
                    if not portal_api.result_status(
                        order.file_idx, "SYSTEM", "SYSTEM", order.result_message, order):
                        failed.append(order.file_idx)
                    portal_log(f"Order Create({order.file_idx}_System)")
            else:
                # A360-FIX[B13] Task 02 step 9 (steps.txt:468-491)
                #   Bug: a file without ship-to and RDD stopped the whole task, the next files never got a status.
                #   Fix: only this file gets 'Validation', the others go on.
                order.so_result = order.so_status = 'Validation'
                portal_api.result_status(order.file_idx, "Validation", "Validation",
                    "Order File Standardization Error",)
                order.status_sent = True
                portal_log(f"Standard Order({order.file_idx}_Fail)")
        business_batch(("validate", "create", "save_results", "report"),
            sum(not order.status_sent for order in std_orders),)
        for order_number, order in enumerate(
            std_orders, start=1
        ):  # step 13: each order
            if order.status_sent:
                continue
            LOG_CONTEXT['file_idx'] = order.file_idx
            std_name = Path(order.path).name
            emit_event('progress', phase='Orders', current=order_number, total=len(std_orders), name=std_name)
            info = f"Excel File : {std_name}<br>vFileName : {std_name}<br>vFileID : {order.file_idx}<br>"
            send_mail(
                f"Order Cr Info  - {RUN.order_id} - File Name found - {std_name}",
                info,  # A360 developer mails
                to=OTHERS.debug_mail_receivers_file_found,
                sender=OTHERS.debug_mail_sender_file_found,
                debug=True,
            )
            if order.retry_flag == "Y":
                send_mail(f"Order Creation Info - {RUN.order_id} - {std_name}", info,
                    to=OTHERS.debug_mail_receivers_retry, sender=OTHERS.debug_mail_sender_retry, debug=True,)
            header_validation(order)
            # A360-FIX[B11] Task 02 step 13 (steps.txt:580)
            #   Bug: 'If vBusinessErrorHandlingFlag not equal True and vErrorHandlingFlag not equal True' also
            #   started the SAP order after a system error. Fix: SAP only when there is no business and no system error.
            if not order.business_error and not order.system_error:
                create_with_relogin(order)
            else:
                business_event('create', 'skipped', 'Order validation failed')
            order.so_creation_date = order.so_creation_date.replace('.', '')
            write_result(order)
            if not order.so_result:  # steps 684-688
                order.so_result = ("SYSTEM" if order.system_error else ("Fail"
                        if order.business_error and not order.so_number else ("Validation"
                            if order.validation_flag else "Fail" if not order.so_number else "")))
            report = order.report
            report['rdd'] = report.get('rdd', '').replace('.', '')
            report["ship_to"] = f"{report.get('ship_to', '')}_{report['rdd']}".strip()
            portal_log(
                f"OrderIdx: {RUN.order_id} | fileIdx: {order.file_idx} | ResultIdx: {order.result_idx} | "
                f"SalesOrg: {report.get('sales_org', '')} | SoldToParty: {report.get('sold_to', '')} | "
                f"ShipToParty: {report['ship_to']} | SO N:o: {order.so_number} | SO Result: {order.so_result} | "
                f"ResultMessage: {order.result_message} | RDD: {report['rdd']}")
            message_card(691, result_id=order.result_idx, so_number=order.so_number,
                so_result=order.so_result, message=order.result_message, report=report,)
            if report["ship_to"] != "_":
                if not portal_api.result_status(order.file_idx, order.so_result, order.so_status,
                    order.result_message, order,):
                    failed.append(order.file_idx)
                portal_log(f"Order Create({order.file_idx}_ResultStatus)")
            else:
                business_event('report', 'skipped', 'Blank ship-to or delivery date')
                portal_log(
                    f"Order Creation Values Blank- ShipTOParty : {report['ship_to']}, RDD Mass : {report['rdd']}, "
                    f"SO Number : {order.so_number}, Order Id : {RUN.order_id}")
            emit_event("progress", phase="Orders", current=order_number, total=len(std_orders),
                name=std_name, complete=True,)
    except RunStopped:
        stopped = True
        preserve_saved_results(std_orders)
        raise
    except Exception as ex:  # Catch
        message_card_error(732, ex)
        ok, error_text = (False, str(ex))
        logging.exception('Task 02 failed')
        portal_log(f"Order Creation Task 02 error: {ex}", error=True)
        send_error_mail('Order Creation Task 02', ex, screenshot(Path(FOLDERS.SCREENSHOTS) / 'Error.png'))
    finally:
        with cleanup_mode():
            outlook_summary_card(std_orders)
            portal_log('End Sub2 Task')  # Finally
            LOG_CONTEXT['file_idx'] = '-'
            for order in std_orders if not ok else []:
                # A360-FIX[B19] Task 02 Finally step 2 (steps.txt:739-768)
                #   Bug: a stale 'vFileIdx not blank' check marked all files - or none - as SYSTEM.
                #   Fix: exactly the files that have no final status yet get SYSTEM.
                if (
                    not order.status_sent
                ):  # with 'order' so a saved SO number is reported too
                    if not portal_api.result_status(order.file_idx, "SYSTEM", "SYSTEM",
                        f"System Error - {error_text}", order,):
                        failed.append(order.file_idx)
                    portal_log(f"Order Create({order.file_idx}_System)")
            missing = [order.file_idx for order in std_orders if not order.status_sent]
            if not stopped and (
                missing or failed
            ):  # plan step 31: every order must end with one final portal status
                logging.error(
                    f"No final portal status for fileIdx {missing} / status call failed for {failed}")
                portal_log(f"No final portal status for fileIdx: {missing} / status call failed: {failed}",
                    error=True,)
    return ok

def load_state(order_id):
    """Stand-alone run: read the list of standardized files written by Task 01 and read each file again."""
    state = json.loads((Path(FOLDERS.LOGS) / f"run_state_{order_id}.json").read_text(encoding="utf-8"))
    orders = []
    for item in state["orders"]:
        workbook = RUN.excel.open(item['path'], read_only=True)
        rows = RUN.excel.read(workbook.Sheets(1))
        workbook.Close(False)
        if any(
            vba_cstr(row[0]) in ("Yes", "No") for row in rows[1:]
        ):  # Task 01 never fills column A
            raise BotError(f"{item['path']} was already processed by SalesCreate - run Task 01 again first")
        orders.append(StdOrder(item['file_idx'], item['orig_name'], item['path'], rows))
    return orders

if (
    __name__ == "__main__"
):  # stand-alone: Task 02 for the files standardized by Task 01, in the open SAP session
    arguments = [a for a in sys.argv[1:] if a != '--live']
    if len(arguments) != 1:
        sys.exit(__doc__)
    RUN.order_id, RUN.dry_run = (arguments[0], '--live' not in sys.argv)
    setup_logging(RUN.order_id)
    RUN.excel, result = (ExcelSession(), False)
    try:
        portal_start()  # --live: a real portal header (logHeaderId) like a normal run
        RUN.session = sales_create.attach_session()
        result = run(load_state(RUN.order_id))
        print('Task 02', 'OK' if result else 'FAILED')
    except RunStopped:
        result = False
        logging.info('Task 02 stopped by the operator')
        sys.exit(130)
    finally:
        with cleanup_mode():
            RUN.excel.quit()
            portal_end(result)
        finish_run(0 if result else 130 if sys.exc_info()[0] is SystemExit else 1)
        shutdown()
