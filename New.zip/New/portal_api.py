"""RPA portal API tasks of the Order Creation bot.

A360 tasks converted here ('Order Creation A360 steps.txt'):
  * Common API Task              (steps.txt:140-175)  -> common_api()
  * GetOrderFileByAPI            (steps.txt:179-228)  -> get_order_files()
  * SetOrderResultStartByAPI     (steps.txt:339-366)  -> result_start()
  * SetOrderResultStatusAPI      (steps.txt:368-420)  -> result_status()

Run on its own (downloads the files and the e-mail of one order, nothing is sent to the portal):
    python portal_api.py <ORDER_ID>
"""

import json
import logging
import re
import shutil
import sys
import time
from datetime import datetime
from pathlib import Path

import requests

from config import FOLDERS, OTHERS
from exceptions import BotError
from rpa_core import RUN, portal_log, setup_logging, step
from runtime_support import (business_operation, download_file, emit_event, message_card, message_card_error,
    controlled_step, card_errors, RunStopped, finish_run, shutdown,)
from business_progress import boolean_outcome

API = requests.Session()  # one connection for all calls (keep-alive)
BASE = OTHERS.api_base_url

# SetOrderResultStatusAPI step 2: portal status code of a 'Validation' result, chosen by the message text
VALIDATION_STATUS = {"No Sales organization on Excel Sheet": "100",
    "No Distribution Channel on Excel Sheet": "101", "No Division Field in Excel on Excel Sheet": "102",
    "Wrong Sales Organization Value on Excel Sheet": "103",
    "Wrong Distribution Channel Value on Excel Sheet": "104", "Wrong Division Value on Excel Sheet": "105",}

def _find(data, key):
    """Return the first value stored under 'key' anywhere inside the JSON answer (A360 cut the text by hand)."""
    if isinstance(data, dict):
        if key in data:
            return data[key]
        data = list(data.values())
    for item in data if isinstance(data, list) else []:
        found = _find(item, key)
        if found is not None:
            return found
    return None

@step
def _post_until_200(resource, payload, debug_file=False):
    """SetOrderResult*API 'Loop 10 times': POST until the answer contains status 200, wait 15 s between tries.
    Returns (ok, json_answer, text_answer). debug_file=True writes failures to API.txt like A360.
    """
    # A360-FIX[B17] Common API step 1 / ResultStart step 1 / ResultStatus step 2 (steps.txt:142,345,397)
    #   Bug: A360 built the JSON by gluing texts together, so a quote or backslash in a message or name broke it.
    #   Fix: requests builds the JSON (json=payload) - same keys, same order, all values as text.
    body, text = ({}, '')
    for attempt in range(1, OTHERS.api_retry_count + 1):
        emit_event('api_attempt', resource=resource, attempt=attempt, total=OTHERS.api_retry_count)
        observed_answer, observed_error = (None, '')
        try:
            answer = API.post(f"{BASE}/rpa/aa/order/v1/{resource}", json=payload,
                timeout=OTHERS.api_post_timeout,)
            observed_answer = answer
            text = answer.text
            body = answer.json() if text.strip().startswith('{') else {}
        except (requests.RequestException, ValueError) as ex:
            text = f"{type(ex).__name__}: {ex}"
            observed_error = text
        logging.debug(f"[api] {resource} try {attempt}: {payload} -> {text[:1000]}")
        # Observe this attempt only; never repeat a request to populate the UI.
        try:
            message = body.get('message', '') if not observed_error else ''
            emit_event("api_response", resource=resource, attempt=attempt,
                http_status=getattr(observed_answer, "status_code", None),
                status=body.get("status", "") if not observed_error else "",
                response=getattr(observed_answer, "text", text)[:4096], summary=observed_error[:160]
                or (message[:160] if isinstance(message, str) else ""),
                acknowledged=str(body.get("status", "")).strip() == "200" or '"status":"200"' in text,)
        except Exception:
            pass
        if str(body.get("status", "")).strip() == "200" or '"status":"200"' in text:
            return (True, body, text)
        if debug_file:
            try:
                Path(OTHERS.api_debug_file).parent.mkdir(parents=True, exist_ok=True)
                with open(OTHERS.api_debug_file, "a", encoding="utf-8") as file:
                    file.write(
                        f"{datetime.now():%Y-%m-%d %H:%M:%S} {RUN.order_id} - SetOrderResultStatus Failed - {text}\n"
                    )
            except OSError as ex:
                logging.warning(f"API.txt not written: {ex}")
        if attempt < OTHERS.api_retry_count:  # no useless wait after the last try
            emit_event('api_retry', resource=resource, attempt=attempt, message=text)
            time.sleep(OTHERS.api_retry_wait)
    logging.error(
        f"[api] {resource} did not answer status 200 after {OTHERS.api_retry_count} tries: {text[:500]}")
    return (False, body, text)

def _observe_response(resource, answer=None, body=None, *, acknowledged=False, error=""):
    """Describe an existing response only; do not parse JSON or make a request."""
    try:
        details = body if isinstance(body, dict) else {}
        summary = error or details.get('message') or getattr(answer, 'text', '')
        emit_event("api_response", resource=resource, attempt=1,
            http_status=getattr(answer, "status_code", None),
            status=details.get("status", details.get("code", "")),
            summary=summary[:160] if isinstance(summary, str) else "",
            response=getattr(answer, "text", "")[:4096] if answer is not None else "",
            acknowledged=acknowledged,)
    except Exception:
        pass

@step
def common_api(step_no, parameter_ids, parameter_values):
    """Common API Task (steps.txt:140-175): send a step to the portal (4 = bot started, 7 = end status).
    Returns True when the call went through (A360 output vErrorHandlingFlag)."""
    # steps 1-9: {"refId":"..","step":"..","datas":[{..}]} - a parameter id equal to the first id starts a new {}
    ids, values = (parameter_ids.split(';'), parameter_values.split(';'))
    datas = []
    for number, key in enumerate(ids):
        if key:
            if number == 0 or key == ids[0]:
                datas.append({})
            datas[-1][key] = values[number] if number < len(values) else ''
    payload = {'refId': RUN.order_id, 'step': str(step_no), 'datas': datas if parameter_ids else None}
    if RUN.dry_run:
        logging.info(f"[api] DRY RUN - exec/order not sent: {payload}")
        return True
    try:  # steps 10-11: POST, A360 'Capture failure response' -> only a broken connection counts as error
        answer = API.post(f"{BASE}/rpa/api/v1/exec/order/", json=payload, timeout=OTHERS.api_post_timeout,)
        logging.info(f"[api] exec/order step {step_no} -> HTTP {answer.status_code} {answer.text[:300]}")
        _observe_response('exec/order', answer, acknowledged=True)
        return True
    except requests.RequestException as ex:  # Catch: vErrorHandlingFlag = False
        logging.error(f"[api] exec/order step {step_no} failed: {ex}")
        _observe_response("exec/order", error=f"{type(ex).__name__}: {ex}")
        return False

@step
def _download(url, destination, **options):
    return download_file(API, url, destination, **options)

@business_operation("download")
@card_errors(227)
@step
def get_order_files():
    """GetOrderFileByAPI (steps.txt:179-228): download every order file into the Input folder and the order
    e-mail into eml_dir. Returns [(file_idx, file_name), ...]. Raises an error on any problem
    (A360 Catch: 'Order File Download Error')."""
    order_id = RUN.order_id
    if (
        RUN.dry_run
    ):  # steps 1-3: tell the portal that the order is being processed (skipped in a dry run)
        logging.info('[api] DRY RUN - orderStart not sent')
    else:
        answer = API.post(f"{BASE}/rpa/aa/order/v1/orderStart", json={"orderId": order_id},
            timeout=OTHERS.api_post_timeout,)
        logging.info(f"[api] orderStart -> HTTP {answer.status_code} {answer.text[:300]}")
        _observe_response('orderStart', answer, acknowledged=True)
    message_card(193, order_id=order_id)
    # steps 6-15: order information, "code" must be 0
    answer = API.get(f"{BASE}/rpa/aa/order/v1/orderInfo/{order_id}",
        headers={"Content-Type": "application/json"}, timeout=OTHERS.api_get_timeout,)
    logging.debug(f"[api] orderInfo -> HTTP {answer.status_code} {answer.text[:3000]}")
    message_card(202, response=answer.text[:4096], http_status=answer.status_code)
    body = answer.json()
    _observe_response('orderInfo', answer, body, acknowledged=str(body.get('code', '')).strip() == '0')
    if str(body.get("code", "")).strip() != "0":
        raise BotError(f"orderInfo answered code '{body.get('code')}' (expected 0)")
    # step 16: download each file that has a fileId
    message_card(210, count=sum(bool(str(item.get("fileId") or "").strip())
            for item in (_find(body, "orderFile") or [])),)
    files, used_names = ([], set())
    for item in _find(body, "orderFile") or []:
        file_idx, name = (str(item.get("fileId") or "").strip(),
            Path(str(item.get("originalName") or "")).name.strip(),)
        if not file_idx:
            continue
        if name.lower() in used_names:
            # A360-FIX[B10] GetOrderFileByAPI step 16 (steps.txt:220)
            #   Bug: two attachments with the same name were saved under the same name -> the first one was lost.
            #   Fix: the second one gets the file id in its name ('<name>__<fileId>.xlsx').
            name = f"{Path(name).stem}__{file_idx}{Path(name).suffix}"
            logging.warning(f"Duplicate attachment name - saved as {name}")
        used_names.add(name.lower())
        size = _download(f"{BASE}/rpa/aa/order/v1/orderFile/{order_id}/{file_idx}",
            Path(FOLDERS.INPUT) / name, headers={"Content-Transfer-Encoding": "binary"},
            timeout=OTHERS.api_get_timeout,)
        emit_event('download_complete', name=name, bytes=size, attachment_id=file_idx)
        files.append((file_idx, name))
        logging.info(f"Downloaded file {file_idx}: {name} ({size} bytes)")
    logging.info(f"File Count - {len(files)}")
    # steps 223-225: the order e-mail (attached to the sales order in SAP later)
    # A360-FIX[B07] GetOrderFileByAPI step 16 (steps.txt:224-225)
    #   Bug: the folder was created under 'C:\RPA\Brity RPA\..' but the e-mail was saved under 'C:\RPA\A360\..'.
    #   Fix: one folder for both, config.json 'eml_dir'.
    _download(f"{BASE}/rpa/aa/order/v1/orderEmlFile/{order_id}",
        Path(OTHERS.eml_dir) / f"{order_id}_Email.eml", create_parent=True, timeout=OTHERS.api_get_timeout,)
    return files

@controlled_step("Register order processing")
@card_errors(363)
@step
def result_start(order, ship_to_rdd):
    """SetOrderResultStartByAPI (steps.txt:339-366): register the start of one standardized order.
    Stores resultId and processableYn on the order (vResultIdx / vRetryFlag). Returns True on status 200.
    """
    if order.file_idx == "outlook":
        return False
    payload = {"orderId": RUN.order_id, "fileId": order.file_idx, "shipToParty": ship_to_rdd,
        "logHeaderId": RUN.inf_idx,}
    message_card(344, payload=payload, dry_run=RUN.dry_run)
    if RUN.dry_run:
        logging.info(f"[api] DRY RUN - orderResultStart not sent: {payload}")
        return True
    ok, body, text = _post_until_200('orderResultStart', payload)
    for key, attribute in (("processableYn", "retry_flag"), ("resultId", "result_idx")):
        value = _find(body, key)
        if value is None:  # fallback = the A360 way: text between '"key":"' and '","'
            match = re.search(rf'"{key}":"(.*?)","', text)
            value = match.group(1) if match else ''
        setattr(order, attribute, str(value).strip())
    logging.info(f"RetryFlag - {order.retry_flag} ResultIdx - {order.result_idx}")
    return ok

@business_operation("report", outcome=lambda result, args, kwargs: ({"state": "skipped"}
        if RUN.dry_run or (args[0] if args else kwargs["file_idx"]) == "outlook"
        else boolean_outcome(result, args, kwargs)),)
@step
def result_status(file_idx, so_result, so_status="", message="", order=None):
    """SetOrderResultStatusAPI (steps.txt:368-420): report the result of one file / standardized order.
    'order' (StdOrder) fills the sales order fields; without it they stay blank like in A360.
    Returns True when the portal answered status 200. Never stops the bot (A360 Catch, steps.txt:417-419).
    """
    try:
        portal_log('Start Set Order Result Status by API')  # step 1
        if file_idx == "outlook":  # step 2
            return True
        message_card(374, header_id=RUN.inf_idx)
        status = (VALIDATION_STATUS.get(message, "90") if so_result == "Validation"
            else {"Success": "40", "Fail": "90", "SYSTEM": "99"}.get(so_result, ""))
        report = order.report if order else {}
        payload = {"orderId": RUN.order_id, "fileId": file_idx,
            "resultId": order.result_idx if order else "", "logHeaderId": RUN.inf_idx, "vdiId": RUN.user,
            "status": status, "soldToParty": report.get("sold_to", ""),
            "customerName": report.get("customer_name", ""), "shipToParty": report.get("ship_to") or "-1",
            "address": "", "soResult": so_result, "soNumber": order.so_number if order else "",
            "soCreationDate": order.so_creation_date if order else "", "message": message,
            "soStatus": so_status, "salesOrg": report.get("sales_org", ""),
            "distChan": report.get("dist_chan", ""), "division": report.get("division", ""),
            "rdd": report.get("rdd", ""), "itemCount": report.get("item_count", ""),
            "resultItemCount": report.get("item_result_count", ""),}
        message_card(397, payload=payload, dry_run=RUN.dry_run)
        if order:
            order.status_sent = True  # a final status was attempted (B19 must not overwrite it with SYSTEM)
        if RUN.dry_run:
            logging.info(f"[api] DRY RUN - orderResult not sent: {json.dumps(payload, ensure_ascii=False)}")
            return True
        ok = _post_until_200('orderResult', payload, debug_file=True)[0]
        emit_event("portal_result", acknowledged=ok, result_id=payload["resultId"],
            so_number=payload["soNumber"], status=payload["soResult"],)
        try:  # last step: copy API.txt to the Output folder (ignore errors)
            shutil.copy(OTHERS.api_debug_file, FOLDERS.OUTPUT)
        except OSError:
            pass
        return ok
    except Exception as ex:  # Catch
        message_card_error(417, ex)
        logging.exception(f"SetOrderResultStatusAPI failed: {ex}")
        portal_log('Error in Set Order Result Status by API', error=True)
        return False

if (
    __name__ == "__main__"
):  # stand-alone: download the files of one order (dry run - nothing is sent)
    if len(sys.argv) != 2:
        sys.exit('Usage: python portal_api.py <ORDER_ID>')
    RUN.order_id, RUN.dry_run = (sys.argv[1], True)
    setup_logging(RUN.order_id)
    Path(FOLDERS.INPUT).mkdir(parents=True, exist_ok=True)
    exit_code = 0
    try:
        for downloaded in get_order_files():
            print(downloaded)
    except RunStopped:
        exit_code = 130
        logging.info('Download stopped by the operator')
    except BaseException:
        exit_code = 1
        raise
    finally:
        finish_run(exit_code)
        shutdown()
    sys.exit(exit_code)
